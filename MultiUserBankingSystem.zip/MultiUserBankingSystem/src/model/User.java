package model;

public class User {
    private int accountNo;
    private String name;
    private String password;
    private Account account;

    public User(int accountNo, String name, String password, Account account) {
        this.accountNo = accountNo;
        this.name = name;
        this.password = password;
        this.account = account;
    }

    public int getAccountNo() {
        return accountNo;
    }

    public String getPassword() {
        return password;
    }

    public Account getAccount() {
        return account;
    }

    public String getName() {
        return name;
    }
}
