package model;

public abstract class Account {

    protected int accountNo;
    protected double balance;

    public Account(int accountNo, double balance) {
        this.accountNo = accountNo;
        this.balance = balance;
    }

    public double getBalance() {
        return balance;
    }

    public void deposit(double amount) {
        balance += amount;
    }

    public void withdraw(double amount) {
        balance -= amount;
    }
    public int getAccountNo() {
        return accountNo;
    }

    public abstract void applyInterest();
}
