package model;

public class LoanAccount extends Account {
    private double interestRate; // Variable rate (10-15%)
    private double borrowedAmount;
    private double totalPayable;
    private int loanDurationMonths;

    public LoanAccount(int accountNo, double borrowedAmount,  double interestRate, int loanDurationMonths) 
    {
        super(accountNo, -borrowedAmount); // Negative balance (you owe money)
        this.borrowedAmount = borrowedAmount;
        this.interestRate = interestRate;
        this.loanDurationMonths = loanDurationMonths;
        calculateTotalPayable();
    }

    private void calculateTotalPayable() {
        // Simple interest for now
        double interest = borrowedAmount * interestRate * (loanDurationMonths / 12.0);
        totalPayable = borrowedAmount + interest;
    }

    @Override
    public void applyInterest() {
        // Loan account ka interest increase karta hai monthly
        double monthlyInterest = (borrowedAmount * interestRate) / 12;
        balance -= monthlyInterest; // Negative balance more negative
    }
    
    public void makePayment(double amount) {
        // Payment karo to balance kam negative ho
        balance += amount; // Negative mein addition = kam qarza
    }
    
    // Getters methods
    public double getBorrowedAmount() { return borrowedAmount; }
    public double getInterestRate() { return interestRate; }
    public double getTotalPayable() { return totalPayable; }
    public double getRemainingBalance() { return -balance; } // Positive mein
    public int getLoanDurationMonths() { return loanDurationMonths; }
}