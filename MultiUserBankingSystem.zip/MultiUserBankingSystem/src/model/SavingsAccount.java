package model;

public class SavingsAccount extends Account {

    private final double interestRate = 0.05; // 5%

    public SavingsAccount(int accountNo, double balance) {
        super(accountNo, balance);
    }

    @Override
    public void applyInterest() {
        balance += balance * interestRate;
    }
}
