package model;

public class CurrentAccount extends Account {

    public CurrentAccount(int accountNo, double balance) {
        super(accountNo, balance);
    }

    @Override
    public void applyInterest() {
        // No interest for current account
    }
}
