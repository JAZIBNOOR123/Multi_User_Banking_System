package model;

import java.util.Date;

public class Transaction {
    private int transactionId;
    private int accountNo;
    private String type; // "DEPOSIT", "WITHDRAW", "TRANSFER"
    private double amount;
    private Date timestamp;
    private String description;

    public Transaction(int transactionId, int accountNo, String type, 
                      double amount, String description) {
        this.transactionId = transactionId;
        this.accountNo = accountNo;
        this.type = type;
        this.amount = amount;
        this.timestamp = new Date();
        this.description = description;
    }

    // Getters
    public int getTransactionId() { return transactionId; }
    public int getAccountNo() { return accountNo; }
    public String getType() { return type; }
    public double getAmount() { return amount; }
    public Date getTimestamp() { return timestamp; }
    public String getDescription() { return description; }

    @Override
    public String toString() {
        return String.format("[%s] %s: $%.2f - %s", 
                timestamp, type, amount, description);
    }
}