package util;

import javax.swing.*;
import java.awt.*;
import java.util.Map;

public class TextChartUtils {
    
    // Create colored progress bar
    public static JProgressBar createProgressBar(double value, double max, 
                                                Color color, String text) {
        JProgressBar progressBar = new JProgressBar(0, 100);
        int percentage = max > 0 ? (int) ((value / max) * 100) : 0;
        progressBar.setValue(percentage);
        progressBar.setString(text + " (" + percentage + "%)");
        progressBar.setStringPainted(true);
        progressBar.setForeground(color);
        progressBar.setBackground(new Color(240, 240, 240));
        progressBar.setBorder(BorderFactory.createEmptyBorder(5, 10, 5, 10));
        
        return progressBar;
    }
    
    // Create metric card
    public static JPanel createMetricCard(String title, String value, 
                                         Color color, String icon) {
        JPanel card = new JPanel(new BorderLayout());
        card.setBackground(Color.WHITE);
        card.setBorder(BorderFactory.createCompoundBorder(
            BorderFactory.createLineBorder(new Color(220, 220, 220)),
            BorderFactory.createEmptyBorder(15, 15, 15, 15)
        ));
        
        JLabel iconLabel = new JLabel(icon);
        iconLabel.setFont(new Font("Segoe UI Emoji", Font.PLAIN, 24));
        
        JLabel titleLabel = new JLabel(title);
        titleLabel.setFont(new Font("Segoe UI", Font.PLAIN, 12));
        titleLabel.setForeground(Color.DARK_GRAY);
        
        JLabel valueLabel = new JLabel(value);
        valueLabel.setFont(new Font("Segoe UI", Font.BOLD, 20));
        valueLabel.setForeground(color);
        
        JPanel topPanel = new JPanel(new FlowLayout(FlowLayout.LEFT));
        topPanel.setBackground(Color.WHITE);
        topPanel.add(iconLabel);
        topPanel.add(titleLabel);
        
        card.add(topPanel, BorderLayout.NORTH);
        card.add(valueLabel, BorderLayout.CENTER);
        
        return card;
    }
    
 // Create simple bar chart
    public static JPanel createBarChart(String title, String[] labels, 
                                       double[] values, Color barColor) {
        JPanel panel = new JPanel(new BorderLayout());
        panel.setBackground(Color.WHITE);
        panel.setBorder(BorderFactory.createTitledBorder(title));
        
        JPanel chartPanel = new JPanel(new GridLayout(labels.length, 1, 5, 5));
        chartPanel.setBackground(Color.WHITE);
        chartPanel.setBorder(BorderFactory.createEmptyBorder(10, 20, 10, 20));
        
        // Find max value for scaling
        double maxValue = 0;
        for (double val : values) {
            if (val > maxValue) maxValue = val;
        }
        if (maxValue == 0) maxValue = 1;
        
        // ✅ FINAL COPY
        final double finalMaxValue = maxValue;
        
        for (int i = 0; i < labels.length; i++) {
            // ✅ FINAL COPY OF INDEX
            final int currentIndex = i;
            
            JPanel barContainer = new JPanel(new BorderLayout());
            barContainer.setBackground(Color.WHITE);
            
            JLabel label = new JLabel(labels[currentIndex]);
            label.setPreferredSize(new Dimension(80, 20));
            
            JPanel barPanel = new JPanel() {
                @Override
                protected void paintComponent(Graphics g) {
                    super.paintComponent(g);
                    int width = (int) ((values[currentIndex] / finalMaxValue) * 200);
                    g.setColor(barColor);
                    g.fillRect(0, 0, width, 20);
                    g.setColor(Color.BLACK);
                    g.drawRect(0, 0, 200, 20);
                    
                    // Draw value text
                    g.setColor(Color.BLACK);
                    g.setFont(new Font("Arial", Font.BOLD, 11));
                    g.drawString(String.format("$%.0f", values[currentIndex]), width + 5, 15);
                }
                
                @Override
                public Dimension getPreferredSize() {
                    return new Dimension(250, 22);
                }
            };
            barPanel.setBackground(Color.WHITE);
            
            barContainer.add(label, BorderLayout.WEST);
            barContainer.add(barPanel, BorderLayout.CENTER);
            chartPanel.add(barContainer);
        }
        
        panel.add(chartPanel, BorderLayout.CENTER);
        return panel;
    }
    // Create pie chart visualization
    public static JPanel createPieChartVisual(String title, Map<String, Double> data) {
        JPanel panel = new JPanel(new BorderLayout());
        panel.setBackground(Color.WHITE);
        panel.setBorder(BorderFactory.createTitledBorder(title));
        
        JPanel chartPanel = new JPanel() {
            @Override
            protected void paintComponent(Graphics g) {
                super.paintComponent(g);
                
                int centerX = getWidth() / 2;
                int centerY = getHeight() / 2;
                int radius = Math.min(centerX, centerY) - 20;
                
                // Calculate total
                double total = 0;
                for (Double value : data.values()) {
                    total += value;
                }
                
                if (total == 0) {
                    g.setColor(Color.LIGHT_GRAY);
                    g.drawString("No Data", centerX - 20, centerY);
                    return;
                }
                
                // Draw pie chart
                double startAngle = 0;
                int colorIndex = 0;
                Color[] colors = {
                    new Color(65, 105, 225),   // Royal Blue
                    new Color(50, 205, 50),     // Lime Green
                    new Color(255, 69, 0),      // Red Orange
                    new Color(255, 215, 0),     // Gold
                    new Color(148, 0, 211),     // Dark Violet
                    new Color(255, 140, 0),     // Dark Orange
                    new Color(0, 191, 255),     // Deep Sky Blue
                    new Color(199, 21, 133)     // Medium Violet Red
                };
                
                for (Map.Entry<String, Double> entry : data.entrySet()) {
                    double percentage = (entry.getValue() / total) * 100;
                    double arcAngle = (entry.getValue() / total) * 360;
                    
                    // Draw arc
                    g.setColor(colors[colorIndex % colors.length]);
                    g.fillArc(centerX - radius, centerY - radius, 
                              radius * 2, radius * 2, 
                              (int) startAngle, (int) arcAngle);
                    
                    // Draw label
                    int labelX = (int) (centerX + (radius + 20) * 
                              Math.cos(Math.toRadians(startAngle + arcAngle / 2)));
                    int labelY = (int) (centerY + (radius + 20) * 
                              Math.sin(Math.toRadians(startAngle + arcAngle / 2)));
                    
                    g.setColor(Color.BLACK);
                    g.drawString(String.format("%.1f%%", percentage), labelX, labelY);
                    
                    startAngle += arcAngle;
                    colorIndex++;
                }
            }
            
            @Override
            public Dimension getPreferredSize() {
                return new Dimension(300, 300);
            }
        };
        
        chartPanel.setBackground(Color.WHITE);
        
        // Legend panel
        JPanel legendPanel = new JPanel(new GridLayout(data.size(), 2, 5, 5));
        legendPanel.setBackground(Color.WHITE);
        legendPanel.setBorder(BorderFactory.createEmptyBorder(10, 10, 10, 10));
        
        Color[] colors = {
            new Color(65, 105, 225),
            new Color(50, 205, 50),
            new Color(255, 69, 0),
            new Color(255, 215, 0),
            new Color(148, 0, 211),
            new Color(255, 140, 0),
            new Color(0, 191, 255),
            new Color(199, 21, 133)
        };
        
        int colorIndex = 0;
        for (Map.Entry<String, Double> entry : data.entrySet()) {
            JPanel colorBox = new JPanel();
            colorBox.setBackground(colors[colorIndex % colors.length]);
            colorBox.setPreferredSize(new Dimension(15, 15));
            colorBox.setBorder(BorderFactory.createLineBorder(Color.BLACK));
            
            JLabel label = new JLabel(String.format("%s: $%.2f", 
                entry.getKey(), entry.getValue()));
            label.setFont(new Font("Arial", Font.PLAIN, 11));
            
            legendPanel.add(colorBox);
            legendPanel.add(label);
            colorIndex++;
        }
        
        panel.add(chartPanel, BorderLayout.CENTER);
        panel.add(legendPanel, BorderLayout.SOUTH);
        
        return panel;
    }
    
    // Create trend line chart
    public static JPanel createTrendChart(String title, String[] labels, 
                                         double[] values, Color lineColor) {
        JPanel panel = new JPanel(new BorderLayout());
        panel.setBackground(Color.WHITE);
        panel.setBorder(BorderFactory.createTitledBorder(title));
        
        JPanel chartPanel = new JPanel() {
            @Override
            protected void paintComponent(Graphics g) {
                super.paintComponent(g);
                
                int padding = 40;
                int chartWidth = getWidth() - padding * 2;
                int chartHeight = getHeight() - padding * 2;
                
                // Draw grid
                g.setColor(new Color(240, 240, 240));
                for (int i = 0; i <= 10; i++) {
                    int y = padding + (chartHeight * i / 10);
                    g.drawLine(padding, y, getWidth() - padding, y);
                }
                
                // Draw axes
                g.setColor(Color.BLACK);
                g.drawLine(padding, padding, padding, getHeight() - padding); // Y-axis
                g.drawLine(padding, getHeight() - padding, 
                          getWidth() - padding, getHeight() - padding); // X-axis
                
                // Find min and max values
                double minValue = Double.MAX_VALUE;
                double maxValue = Double.MIN_VALUE;
                for (double val : values) {
                    if (val < minValue) minValue = val;
                    if (val > maxValue) maxValue = val;
                }
                double range = maxValue - minValue;
                if (range == 0) range = 1;
                
                // Draw data points and lines
                g.setColor(lineColor);
                int pointRadius = 4;
                
                int[] xPoints = new int[values.length];
                int[] yPoints = new int[values.length];
                
                for (int i = 0; i < values.length; i++) {
                    int x = padding + (i * chartWidth / (values.length - 1));
                    int y = padding + chartHeight - 
                           (int) (((values[i] - minValue) / range) * chartHeight);
                    
                    xPoints[i] = x;
                    yPoints[i] = y;
                    
                    // Draw point
                    g.fillOval(x - pointRadius, y - pointRadius, 
                              pointRadius * 2, pointRadius * 2);
                    
                    // Draw value label
                    g.setColor(Color.BLACK);
                    g.setFont(new Font("Arial", Font.PLAIN, 10));
                    g.drawString(String.format("$%.0f", values[i]), x - 15, y - 10);
                    g.setColor(lineColor);
                    
                    // Draw month label
                    if (i < labels.length) {
                        g.setColor(Color.BLACK);
                        g.drawString(labels[i], x - 10, getHeight() - padding + 15);
                        g.setColor(lineColor);
                    }
                }
                
                // Draw connecting lines
                g.setColor(lineColor);
                for (int i = 0; i < values.length - 1; i++) {
                    g.drawLine(xPoints[i], yPoints[i], xPoints[i + 1], yPoints[i + 1]);
                }
                
                // Draw title
                g.setColor(Color.BLACK);
                g.setFont(new Font("Arial", Font.BOLD, 12));
                g.drawString(title, getWidth() / 2 - 50, padding - 10);
            }
            
            @Override
            public Dimension getPreferredSize() {
                return new Dimension(400, 300);
            }
        };
        
        chartPanel.setBackground(Color.WHITE);
        panel.add(chartPanel, BorderLayout.CENTER);
        
        return panel;
    }
}