package util;

import java.util.concurrent.locks.ReentrantLock;

public class AccountLock {
    public static ReentrantLock lock = new ReentrantLock();
}
