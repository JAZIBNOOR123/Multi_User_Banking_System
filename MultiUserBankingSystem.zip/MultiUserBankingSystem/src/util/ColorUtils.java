package util;

import java.awt.Color;

public class ColorUtils {
    
    // Calculate contrast ratio (WCAG 2.1 requires at least 4.5:1 for normal text)
    public static double getContrastRatio(Color color1, Color color2) {
        double luminance1 = getRelativeLuminance(color1);
        double luminance2 = getRelativeLuminance(color2);
        
        double lighter = Math.max(luminance1, luminance2);
        double darker = Math.min(luminance1, luminance2);
        
        return (lighter + 0.05) / (darker + 0.05);
    }
    
    private static double getRelativeLuminance(Color color) {
        double r = getColorComponent(color.getRed());
        double g = getColorComponent(color.getGreen());
        double b = getColorComponent(color.getBlue());
        
        return 0.2126 * r + 0.7152 * g + 0.0722 * b;
    }
    
    private static double getColorComponent(int component) {
        double c = component / 255.0;
        return (c <= 0.03928) ? c / 12.92 : Math.pow((c + 0.055) / 1.055, 2.4);
    }
    
    // Get a contrasting text color for a given background
    public static Color getContrastingTextColor(Color backgroundColor) {
        double luminance = getRelativeLuminance(backgroundColor);
        return luminance > 0.5 ? Color.BLACK : Color.WHITE;
    }
}