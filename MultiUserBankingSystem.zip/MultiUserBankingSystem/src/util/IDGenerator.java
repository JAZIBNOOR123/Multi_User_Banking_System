package util;

import java.util.concurrent.atomic.AtomicInteger;

public class IDGenerator {
    private static final AtomicInteger counter = new AtomicInteger(1001);

    public static int generateAccountNo() {
        return counter.getAndIncrement();
    }
}
