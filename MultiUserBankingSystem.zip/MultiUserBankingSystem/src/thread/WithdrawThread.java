package thread;

import exception.InsufficientBalanceException;
import model.Account;
import service.BankService;

public class WithdrawThread extends Thread {

    private Account account;
    private double amount;

    public WithdrawThread(Account account, double amount) {
        this.account = account;
        this.amount = amount;
    }

    @Override
    public void run() {
        try {
            BankService.withdraw(account, amount);
        } catch (InsufficientBalanceException e) {
            System.out.println(e.getMessage());
        }
    }
}
