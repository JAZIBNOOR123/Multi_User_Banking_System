package thread;

import model.Account;
import java.text.SimpleDateFormat;
import java.util.Date;

public class InterestThread extends Thread {
    private Account account;
    private String accountHolder;
    private SimpleDateFormat sdf = new SimpleDateFormat("HH:mm:ss");
    
    public InterestThread(Account account, String accountHolder) {
        this.account = account;
        this.accountHolder = accountHolder;
        this.setName("InterestThread-" + accountHolder);
    }
    
    @Override
    public void run() {
        System.out.println("[" + sdf.format(new Date()) + "] Interest thread started for: " + accountHolder);
        
        try {
            while (!isInterrupted()) {
                // Apply interest every 30 seconds for demo
                // In real app, this would be daily/monthly
                Thread.sleep(30000); 
                
                double oldBalance = account.getBalance();
                account.applyInterest();
                double newBalance = account.getBalance();
                
                if (oldBalance != newBalance) {
                    System.out.println("[" + sdf.format(new Date()) + "] " +
                            "Interest applied to " + accountHolder + 
                            " | Old: $" + String.format("%.2f", oldBalance) + 
                            " | New: $" + String.format("%.2f", newBalance));
                }
            }
        } catch (InterruptedException e) {
            System.out.println("[" + sdf.format(new Date()) + "] " +
                    "Interest thread stopped for: " + accountHolder);
        }
    }
    
    public void stopInterest() {
        this.interrupt();
        System.out.println("[" + sdf.format(new Date()) + "] " +
                "Stopping interest thread for: " + accountHolder);
    }
}