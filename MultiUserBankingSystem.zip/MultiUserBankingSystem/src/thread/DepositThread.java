package thread;

import model.Account;
import service.BankService;

public class DepositThread extends Thread {

    private Account account;
    private double amount;

    public DepositThread(Account acc, double amt) {
        this.account = acc;
        this.amount = amt;
    }

    public void run() {
        BankService.deposit(account, amount);
    }
}
