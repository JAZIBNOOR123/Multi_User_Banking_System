// SimpleStatementFrame.java - Create new file
package ui;

import javax.swing.*;
import java.util.List;
import javax.swing.table.*;
import java.awt.*;
import java.text.SimpleDateFormat;
import java.util.*;
import service.StatementService;
import service.TransactionService;

public class SimpleStatementFrame extends JFrame {
    
    private int accountNo;
    private String userName;
    
    public SimpleStatementFrame(int accountNo, String userName) {
        this.accountNo = accountNo;
        this.userName = userName;
        
        setTitle("Bank Statement - " + userName);
        setSize(800, 600);
        setLocationRelativeTo(null);
        setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        
        initUI();
    }
    
    private void initUI() {
        JPanel mainPanel = new JPanel(new BorderLayout());
        mainPanel.setBackground(Color.WHITE);
        
        // Header
        JPanel headerPanel = createHeaderPanel();
        
        // Statement content
        JPanel statementPanel = createStatementPanel();
        
        mainPanel.add(headerPanel, BorderLayout.NORTH);
        mainPanel.add(statementPanel, BorderLayout.CENTER);
        
        add(mainPanel);
    }
    
    private JPanel createHeaderPanel() {
        JPanel header = new JPanel(new BorderLayout());
        header.setBackground(new Color(240, 245, 250));
        header.setBorder(BorderFactory.createEmptyBorder(15, 20, 15, 20));
        
        // User info
        JLabel welcomeLabel = new JLabel("Bank Statement");
        welcomeLabel.setFont(new Font("Segoe UI", Font.BOLD, 20));
        welcomeLabel.setForeground(new Color(0, 100, 200));
        
        JLabel accountLabel = new JLabel("Account #" + accountNo + " | " + 
            new SimpleDateFormat("dd MMM yyyy, hh:mm a").format(new Date()));
        accountLabel.setFont(new Font("Segoe UI", Font.PLAIN, 12));
        accountLabel.setForeground(Color.DARK_GRAY);
        
        JPanel userPanel = new JPanel(new BorderLayout());
        userPanel.setBackground(new Color(240, 245, 250));
        userPanel.add(welcomeLabel, BorderLayout.NORTH);
        userPanel.add(accountLabel, BorderLayout.SOUTH);
        
        // Balance info
        Calendar cal = Calendar.getInstance();
        Map<String, Object> currentData = StatementService.getMonthlySummary(
            accountNo, cal.get(Calendar.YEAR), cal.get(Calendar.MONTH) + 1);
        
        double balance = (double) currentData.get("CLOSING_BALANCE");
        double savingsRate = (double) currentData.get("SAVINGS_RATE");
        
        JLabel balanceLabel = new JLabel(String.format("Balance: $%.2f", balance));
        balanceLabel.setFont(new Font("Segoe UI", Font.BOLD, 16));
        balanceLabel.setForeground(new Color(0, 100, 0));
        
        JLabel savingsLabel = new JLabel(String.format("Savings: %.1f%%", savingsRate));
        savingsLabel.setFont(new Font("Segoe UI", Font.BOLD, 16));
        savingsLabel.setForeground(savingsRate >= 20 ? 
            new Color(0, 150, 0) : new Color(255, 140, 0));
        
        JPanel statsPanel = new JPanel(new FlowLayout(FlowLayout.RIGHT, 20, 0));
        statsPanel.setBackground(new Color(240, 245, 250));
        statsPanel.add(balanceLabel);
        statsPanel.add(savingsLabel);
        
        header.add(userPanel, BorderLayout.WEST);
        header.add(statsPanel, BorderLayout.EAST);
        
        return header;
    }
    
    private JPanel createStatementPanel() {
        JPanel panel = new JPanel(new BorderLayout());
        panel.setBackground(Color.WHITE);
        panel.setBorder(BorderFactory.createEmptyBorder(20, 20, 20, 20));
        
        // Month selector
        JPanel controlPanel = new JPanel(new FlowLayout(FlowLayout.LEFT));
        controlPanel.setBackground(Color.WHITE);
        
        Calendar cal = Calendar.getInstance();
        int currentYear = cal.get(Calendar.YEAR);
        
        JLabel yearLabel = new JLabel("Year:");
        JComboBox<Integer> yearCombo = new JComboBox<>();
        for (int year = currentYear - 2; year <= currentYear; year++) {
            yearCombo.addItem(year);
        }
        yearCombo.setSelectedItem(currentYear);
        
        JLabel monthLabel = new JLabel("Month:");
        JComboBox<String> monthCombo = new JComboBox<>();
        String[] monthNames = {"January", "February", "March", "April", "May", "June",
                              "July", "August", "September", "October", "November", "December"};
        for (String month : monthNames) {
            monthCombo.addItem(month);
        }
        monthCombo.setSelectedIndex(cal.get(Calendar.MONTH));
        
        JButton loadBtn = new JButton("📄 Load Statement");
        JButton printBtn = new JButton("🖨️ Print Preview");
        
        controlPanel.add(yearLabel);
        controlPanel.add(yearCombo);
        controlPanel.add(monthLabel);
        controlPanel.add(monthCombo);
        controlPanel.add(loadBtn);
        controlPanel.add(printBtn);
        
        // Statement display
        JTextArea statementArea = new JTextArea();
        statementArea.setFont(new Font("Monospaced", Font.PLAIN, 12));
        statementArea.setEditable(false);
        statementArea.setBackground(new Color(248, 248, 255));
        
        loadBtn.addActionListener(e -> {
            int selectedYear = (int) yearCombo.getSelectedItem();
            int selectedMonth = monthCombo.getSelectedIndex() + 1;
            
            Map<String, Object> monthlyData = 
                StatementService.getMonthlySummary(accountNo, selectedYear, selectedMonth);
            
            statementArea.setText(generateStatementText(monthlyData, selectedYear, selectedMonth));
        });
        
        printBtn.addActionListener(e -> {
            JOptionPane.showMessageDialog(this,
                "Print feature will be available in the next update.",
                "Coming Soon",
                JOptionPane.INFORMATION_MESSAGE);
        });
        
        // Load initial data
        loadBtn.doClick();
        
        panel.add(controlPanel, BorderLayout.NORTH);
        panel.add(new JScrollPane(statementArea), BorderLayout.CENTER);
        
        return panel;
    }
    
    private String generateStatementText(Map<String, Object> data, int year, int month) {
        StringBuilder sb = new StringBuilder();
        
        String monthName = new String[]{"January", "February", "March", "April", "May", "June",
                                       "July", "August", "September", "October", "November", "December"}[month-1];
        
        sb.append("╔══════════════════════════════════════════════════════════════╗\n");
        sb.append("║                    MONTHLY BANK STATEMENT                    ║\n");
        sb.append("╚══════════════════════════════════════════════════════════════╝\n\n");
        
        sb.append("  Account Holder: ").append(userName).append("\n");
        sb.append("  Account Number: ").append(accountNo).append("\n");
        sb.append("  Statement Period: ").append(monthName).append(" ").append(year).append("\n");
        sb.append("  Generated: ").append(new Date()).append("\n\n");
        
        sb.append("  ┌────────────────────────────────────────────────────────────┐\n");
        sb.append("  │                       SUMMARY                             │\n");
        sb.append("  ├────────────────────────────────────────────────────────────┤\n");
        
        String[] labels = {"Opening Balance", "Total Deposits", "Total Withdrawals", 
                          "Net Flow", "Closing Balance", "Savings Rate", "Transactions"};
        Object[] values = {
            String.format("$%.2f", (double)data.get("OPENING_BALANCE")),
            String.format("$%.2f", (double)data.get("TOTAL_DEPOSITS")),
            String.format("$%.2f", (double)data.get("TOTAL_WITHDRAWALS")),
            String.format("$%.2f", (double)data.get("NET_FLOW")),
            String.format("$%.2f", (double)data.get("CLOSING_BALANCE")),
            String.format("%.1f%%", (double)data.get("SAVINGS_RATE")),
            data.get("TRANSACTION_COUNT")
        };
        
        for (int i = 0; i < labels.length; i++) {
            sb.append(String.format("  │ %-25s %25s │\n", labels[i] + ":", values[i]));
        }
        
        sb.append("  └────────────────────────────────────────────────────────────┘\n\n");
        
        // Transactions list
        sb.append("  TRANSACTIONS:\n");
        sb.append("  ┌─────┬────────────────────┬──────────┬────────────┬─────────────────────────────┐\n");
        sb.append("  │ No. │ Date & Time        │ Type     │ Amount     │ Description                 │\n");
        sb.append("  ├─────┼────────────────────┼──────────┼────────────┼─────────────────────────────┤\n");
        
        @SuppressWarnings("unchecked")
        List<String[]> transactions = (List<String[]>) data.get("TRANSACTIONS");
        
        if (transactions != null && !transactions.isEmpty()) {
            int count = 1;
            for (String[] txn : transactions) {
                if (txn.length >= 4) {
                    sb.append(String.format("  │ %-3d │ %-18s │ %-8s │ %-10s │ %-27s │\n",
                        count++,
                        txn[1].length() > 18 ? txn[1].substring(0, 15) + "..." : txn[1],
                        txn[2],
                        txn[3],
                        txn.length > 4 ? (txn[4].length() > 27 ? txn[4].substring(0, 24) + "..." : txn[4]) : ""
                    ));
                }
            }
        } else {
            sb.append("  │                         NO TRANSACTIONS FOUND                         │\n");
        }
        
        sb.append("  └─────┴────────────────────┴──────────┴────────────┴─────────────────────────────┘\n");
        
        sb.append("\n╔══════════════════════════════════════════════════════════════╗\n");
        sb.append("║                    END OF STATEMENT                         ║\n");
        sb.append("╚══════════════════════════════════════════════════════════════╝\n");
        
        return sb.toString();
    }
}