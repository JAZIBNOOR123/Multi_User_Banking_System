package ui;

import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import model.User;
import service.AuthService;

public class SignupFrame extends JFrame {
    
    public SignupFrame() {
        setTitle("Banking System - Sign Up");
        setSize(400, 500);
        setLocationRelativeTo(null);
        setResizable(false);
        
        initUI();
    }
    
    private void initUI() {
        // Main panel with gradient
        JPanel mainPanel = new JPanel(new BorderLayout()) {
            @Override
            protected void paintComponent(Graphics g) {
                super.paintComponent(g);
                Graphics2D g2d = (Graphics2D) g;
                GradientPaint gradient = new GradientPaint(
                    0, 0, new Color(60, 179, 113),
                    0, getHeight(), new Color(30, 60, 114)
                );
                g2d.setPaint(gradient);
                g2d.fillRect(0, 0, getWidth(), getHeight());
            }
        };
        
        JPanel formPanel = new JPanel();
        formPanel.setLayout(null);
        formPanel.setOpaque(false);
        
        // Title
        JLabel titleLabel = new JLabel("📝 Create Account");
        titleLabel.setFont(new Font("Segoe UI", Font.BOLD, 28));
        titleLabel.setForeground(Color.WHITE);
        titleLabel.setBounds(0, 30, 400, 40);
        titleLabel.setHorizontalAlignment(SwingConstants.CENTER);
        
        // Name field
        JLabel nameLabel = new JLabel("Full Name");
        nameLabel.setFont(new Font("Segoe UI", Font.BOLD, 12));
        nameLabel.setForeground(Color.WHITE);
        nameLabel.setBounds(50, 90, 300, 20);
        
        JTextField nameField = new JTextField();
        nameField.setBounds(50, 115, 300, 40);
        nameField.setFont(new Font("Segoe UI", Font.PLAIN, 14));
        nameField.setBorder(BorderFactory.createCompoundBorder(
            BorderFactory.createLineBorder(new Color(180, 200, 255), 1),
            BorderFactory.createEmptyBorder(0, 10, 0, 10)
        ));
        
        // Password field
        JLabel passLabel = new JLabel("Password");
        passLabel.setFont(new Font("Segoe UI", Font.BOLD, 12));
        passLabel.setForeground(Color.WHITE);
        passLabel.setBounds(50, 170, 300, 20);
        
        JPasswordField passField = new JPasswordField();
        passField.setBounds(50, 195, 300, 40);
        passField.setFont(new Font("Segoe UI", Font.PLAIN, 14));
        passField.setBorder(BorderFactory.createCompoundBorder(
            BorderFactory.createLineBorder(new Color(180, 200, 255), 1),
            BorderFactory.createEmptyBorder(0, 10, 0, 10)
        ));
        
        // Account type
        JLabel typeLabel = new JLabel("Account Type");
        typeLabel.setFont(new Font("Segoe UI", Font.BOLD, 12));
        typeLabel.setForeground(Color.WHITE);
        typeLabel.setBounds(50, 250, 300, 20);
        
        JComboBox<String> typeCombo = new JComboBox<>(new String[]{"Savings Account", "Current Account"});
        typeCombo.setBounds(50, 275, 300, 40);
        typeCombo.setFont(new Font("Segoe UI", Font.PLAIN, 14));
        typeCombo.setBackground(Color.WHITE);
        typeCombo.setFocusable(false);
        
        // Signup button
        JButton signupBtn = new JButton("Create Account");
        signupBtn.setBounds(50, 340, 300, 45);
        signupBtn.setFont(new Font("Segoe UI", Font.BOLD, 14));
        signupBtn.setBackground(new Color(255, 255, 255));
        signupBtn.setForeground(new Color(30, 60, 114));
        signupBtn.setFocusPainted(false);
        signupBtn.setBorder(BorderFactory.createEmptyBorder(10, 0, 10, 0));
        signupBtn.setCursor(new Cursor(Cursor.HAND_CURSOR));
        
        // Rounded button
        signupBtn.setUI(new javax.swing.plaf.basic.BasicButtonUI() {
            @Override
            public void paint(Graphics g, JComponent c) {
                Graphics2D g2d = (Graphics2D) g;
                g2d.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
                
                AbstractButton b = (AbstractButton) c;
                ButtonModel model = b.getModel();
                
                if (model.isPressed()) {
                    g2d.setColor(new Color(240, 240, 240));
                } else if (model.isRollover()) {
                    g2d.setColor(new Color(255, 255, 255));
                } else {
                    g2d.setColor(new Color(255, 255, 255));
                }
                
                g2d.fillRoundRect(0, 0, c.getWidth(), c.getHeight(), 25, 25);
                super.paint(g, c);
            }
        });
        
        // Login link
        JLabel loginLabel = new JLabel("Already have an account? Login");
        loginLabel.setFont(new Font("Segoe UI", Font.PLAIN, 12));
        loginLabel.setForeground(Color.WHITE);
        loginLabel.setBounds(0, 400, 400, 20);
        loginLabel.setHorizontalAlignment(SwingConstants.CENTER);
        loginLabel.setCursor(new Cursor(Cursor.HAND_CURSOR));
        
        formPanel.add(titleLabel);
        formPanel.add(nameLabel);
        formPanel.add(nameField);
        formPanel.add(passLabel);
        formPanel.add(passField);
        formPanel.add(typeLabel);
        formPanel.add(typeCombo);
        formPanel.add(signupBtn);
        formPanel.add(loginLabel);
        
        signupBtn.addActionListener(e -> {
            if (nameField.getText().trim().isEmpty()) {
                JOptionPane.showMessageDialog(this, "Please enter your name");
                return;
            }
            
            if (new String(passField.getPassword()).isEmpty()) {
                JOptionPane.showMessageDialog(this, "Please enter password");
                return;
            }
            
            String accountType = typeCombo.getSelectedItem().toString();
            String typeCode = accountType.contains("Savings") ? "Savings" : "Current";
            
            User user = AuthService.signup(
                nameField.getText().trim(),
                new String(passField.getPassword()),
                typeCode
            );

            JOptionPane.showMessageDialog(this,
                "<html><center><b>Account Created Successfully!</b><br><br>" +
                "Account Number: <b>" + user.getAccountNo() + "</b><br>" +
                "Account Type: " + accountType + "<br><br>" +
                "Please remember your account number for login.</center></html>",
                "Registration Complete",
                JOptionPane.INFORMATION_MESSAGE);

            new LoginFrame().setVisible(true);
            dispose();
        });
        
        loginLabel.addMouseListener(new MouseAdapter() {
            @Override
            public void mouseClicked(MouseEvent e) {
                new LoginFrame().setVisible(true);
                dispose();
            }
            
            @Override
            public void mouseEntered(MouseEvent e) {
                loginLabel.setForeground(new Color(144, 238, 144));
            }
            
            @Override
            public void mouseExited(MouseEvent e) {
                loginLabel.setForeground(Color.WHITE);
            }
        });
        
        mainPanel.add(formPanel, BorderLayout.CENTER);
        add(mainPanel);
    }
}