package ui;

import javax.swing.JFrame;

public class TestSwing {
    public static void main(String[] args) {
        JFrame frame = new JFrame("Swing Test");
        frame.setSize(300, 200);
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.setVisible(true);
    }
}
