package ui;

import javax.swing.*;
import model.User;
import service.LoanService;
import exception.InsufficientBalanceException;
import java.awt.*;

public class LoanFrame extends JFrame {
    
    private User user;
    private DashboardFrame dashboard;
    
    public LoanFrame(User user, DashboardFrame dashboard) {
        this.user = user;
        this.dashboard = dashboard;
        
        setTitle("Loan Management - Nexus Bank");
        setSize(500, 600);
        setLayout(null);
        setLocationRelativeTo(null);
        setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        getContentPane().setBackground(Color.WHITE);
        
        // TABS for Loan features
        JTabbedPane tabbedPane = new JTabbedPane();
        tabbedPane.setBounds(10, 10, 465, 540);
        tabbedPane.setFont(new Font("Segoe UI", Font.BOLD, 12));
        
        // TAB 1: Apply for Loan
        JPanel applyPanel = createApplyPanel();
        
        // TAB 2: Pay Loan
        JPanel payPanel = createPayPanel();
        
        // TAB 3: Loan Status
        JPanel statusPanel = createStatusPanel();
        
        tabbedPane.addTab("🏦 Apply Loan", applyPanel);
        tabbedPane.addTab("💳 Pay Installment", payPanel);
        tabbedPane.addTab("📜 Loan History", statusPanel);
        
        add(tabbedPane);
        
        // Set icon
        setIconImage(new ImageIcon("icons/loan.png").getImage());
    }
    
    private JPanel createApplyPanel() {
        JPanel panel = new JPanel(null);
        panel.setBackground(new Color(240, 248, 255));
        
        // Title
        JLabel titleLabel = new JLabel("🏦 Apply for Loan");
        titleLabel.setFont(new Font("Segoe UI", Font.BOLD, 18));
        titleLabel.setForeground(new Color(0, 100, 200));
        titleLabel.setBounds(150, 20, 200, 30);
        
        // Loan Amount
        JLabel amountLabel = new JLabel("Loan Amount ($):");
        amountLabel.setFont(new Font("Segoe UI", Font.BOLD, 12));
        amountLabel.setBounds(20, 70, 150, 25);
        
        JTextField amountField = new JTextField();
        amountField.setBounds(180, 70, 200, 30);
        amountField.setFont(new Font("Segoe UI", Font.PLAIN, 14));
        amountField.setBorder(BorderFactory.createCompoundBorder(
            BorderFactory.createLineBorder(new Color(180, 200, 220), 1),
            BorderFactory.createEmptyBorder(5, 10, 5, 10)
        ));
        
        // Loan Type (NEW - REPLACED SLIDER)
        JLabel typeLabel = new JLabel("Loan Type:");
        typeLabel.setFont(new Font("Segoe UI", Font.BOLD, 12));
        typeLabel.setBounds(20, 115, 150, 25);
        
        JComboBox<String> typeCombo = new JComboBox<>(new String[]{
            "🏠 Home Loan (8.5%)",
            "🚗 Car Loan (9.5%)", 
            "💰 Personal Loan (12.5%)",
            "🎓 Education Loan (7.5%)"
        });
        typeCombo.setBounds(180, 115, 200, 30);
        typeCombo.setFont(new Font("Segoe UI", Font.PLAIN, 12));
        typeCombo.setBackground(Color.WHITE);
        
        // Duration
        JLabel monthsLabel = new JLabel("Duration (months):");
        monthsLabel.setFont(new Font("Segoe UI", Font.BOLD, 12));
        monthsLabel.setBounds(20, 160, 150, 25);
        
        JSpinner monthsSpinner = new JSpinner(
            new SpinnerNumberModel(12, 6, 360, 12));
        monthsSpinner.setBounds(180, 160, 100, 30);
        ((JSpinner.DefaultEditor) monthsSpinner.getEditor()).getTextField().setFont(new Font("Segoe UI", Font.PLAIN, 14));
        
        // Bank Policy Rate Display (NEW)
        JLabel policyLabel = new JLabel("📋 Bank Policy Applied:");
        policyLabel.setFont(new Font("Segoe UI", Font.BOLD, 12));
        policyLabel.setForeground(new Color(0, 100, 0));
        policyLabel.setBounds(20, 205, 200, 25);
        
        JLabel rateDisplayLabel = new JLabel("Interest Rate: 8.5% (Fixed by Bank)");
        rateDisplayLabel.setFont(new Font("Segoe UI", Font.BOLD, 12));
        rateDisplayLabel.setForeground(Color.RED);
        rateDisplayLabel.setBounds(180, 205, 250, 25);
        
        // EMI Calculator
        JLabel emiLabel = new JLabel("Monthly EMI: $0.00");
        emiLabel.setFont(new Font("Segoe UI", Font.BOLD, 14));
        emiLabel.setForeground(new Color(0, 150, 0));
        emiLabel.setBounds(180, 250, 200, 30);
        
        JButton calculateBtn = new JButton("Calculate EMI");
        calculateBtn.setBounds(50, 250, 120, 30);
        calculateBtn.setFont(new Font("Segoe UI", Font.BOLD, 12));
        calculateBtn.setBackground(new Color(70, 130, 180));
        calculateBtn.setForeground(Color.BLACK);
        calculateBtn.setFocusPainted(false);
        calculateBtn.setCursor(new Cursor(Cursor.HAND_CURSOR));
        
        // Apply Button
        JButton applyBtn = new JButton("✅ Apply for Loan");
        applyBtn.setBounds(50, 300, 300, 40);
        applyBtn.setFont(new Font("Segoe UI", Font.BOLD, 14));
        applyBtn.setBackground(new Color(60, 179, 113));
        applyBtn.setForeground(Color.BLACK);
        applyBtn.setFocusPainted(false);
        applyBtn.setCursor(new Cursor(Cursor.HAND_CURSOR));
        
        // Information Panel
        JTextArea infoArea = new JTextArea();
        infoArea.setText("📋 Bank Loan Policy:\n" +
                        "• Rates are fixed by bank\n" +
                        "• No negotiation allowed\n" +
                        "• Minimum loan: $1,000\n" +
                        "• Maximum loan: $100,000\n" +
                        "• Processing fee: 1% of loan amount");
        infoArea.setFont(new Font("Segoe UI", Font.PLAIN, 11));
        infoArea.setEditable(false);
        infoArea.setBackground(new Color(245, 245, 245));
        infoArea.setBounds(50, 350, 300, 120);
        infoArea.setBorder(BorderFactory.createCompoundBorder(
            BorderFactory.createLineBorder(new Color(200, 200, 200), 1),
            BorderFactory.createEmptyBorder(10, 10, 10, 10)
        ));
        
        // Add components
        panel.add(titleLabel);
        panel.add(amountLabel);
        panel.add(amountField);
        panel.add(typeLabel);
        panel.add(typeCombo);
        panel.add(monthsLabel);
        panel.add(monthsSpinner);
        panel.add(policyLabel);
        panel.add(rateDisplayLabel);
        panel.add(calculateBtn);
        panel.add(emiLabel);
        panel.add(applyBtn);
        panel.add(infoArea);
        
        // Update rate when type changes
        typeCombo.addActionListener(e -> updateRateDisplay(typeCombo, rateDisplayLabel));
        
        // Calculate EMI
        calculateBtn.addActionListener(e -> {
            try {
                String amountText = amountField.getText().trim();
                if (amountText.isEmpty()) {
                    JOptionPane.showMessageDialog(this, "❌ Please enter loan amount");
                    return;
                }
                
                double amount = Double.parseDouble(amountText);
                int months = (int) monthsSpinner.getValue();
                double rate = getRateForType((String) typeCombo.getSelectedItem());
                
                if (amount < 1000) {
                    JOptionPane.showMessageDialog(this, "❌ Minimum loan amount is $1,000");
                    return;
                }
                
                if (amount > 100000) {
                    JOptionPane.showMessageDialog(this, "❌ Maximum loan amount is $100,000");
                    return;
                }
                
                double emi = LoanService.calculateEMI(amount, rate, months);
                emiLabel.setText(String.format("Monthly EMI: $%.2f", emi));
                emiLabel.setForeground(new Color(0, 150, 0));
                
            } catch (NumberFormatException ex) {
                JOptionPane.showMessageDialog(this, "❌ Please enter valid amount");
            } catch (Exception ex) {
                JOptionPane.showMessageDialog(this, "❌ Error: " + ex.getMessage());
            }
        });
        
        // Apply for Loan
        applyBtn.addActionListener(e -> {
            try {
                String amountText = amountField.getText().trim();
                if (amountText.isEmpty()) {
                    JOptionPane.showMessageDialog(this, "❌ Please enter loan amount");
                    return;
                }
                
                double amount = Double.parseDouble(amountText);
                int months = (int) monthsSpinner.getValue();
                double rate = getRateForType((String) typeCombo.getSelectedItem());
                
                // Validation
                if (amount < 1000) {
                    JOptionPane.showMessageDialog(this, "❌ Minimum loan amount is $1,000");
                    return;
                }
                
                if (amount > 100000) {
                    JOptionPane.showMessageDialog(this, "❌ Maximum loan amount is $100,000");
                    return;
                }
                
                if (months < 6) {
                    JOptionPane.showMessageDialog(this, "❌ Minimum duration is 6 months");
                    return;
                }
                
                // Apply for loan
                LoanService.applyForLoan(user, amount, months, rate);
                
                // Refresh dashboard
                dashboard.refreshData();
                
                double emi = LoanService.calculateEMI(amount, rate, months);
                double totalPayable = amount + (amount * rate * (months/12.0));
                
                // Success message
                JOptionPane.showMessageDialog(this,
                    String.format(
                        "<html><div style='text-align:center;width:300px;'>" +
                        "<h3 style='color:green;'>✅ Loan Approved!</h3>" +
                        "<hr>" +
                        "<p><b>Loan Details:</b></p>" +
                        "<p>Amount: <b style='color:blue;'>$%.2f</b></p>" +
                        "<p>Type: <b>%s</b></p>" +
                        "<p>Interest Rate: <b>%.1f%%</b></p>" +
                        "<p>Duration: <b>%d months</b></p>" +
                        "<p>Monthly EMI: <b style='color:green;'>$%.2f</b></p>" +
                        "<p>Total Payable: <b>$%.2f</b></p>" +
                        "<hr>" +
                        "<p><small>Loan amount will be credited to your account.</small></p>" +
                        "</div></html>",
                        amount, 
                        getLoanTypeName((String) typeCombo.getSelectedItem()),
                        rate*100, 
                        months, 
                        emi, 
                        totalPayable
                    ),
                    "Loan Application Approved",
                    JOptionPane.INFORMATION_MESSAGE);
                
                dispose();
                
            } catch (Exception ex) {
                JOptionPane.showMessageDialog(this, 
                    "❌ Error: " + ex.getMessage(),
                    "Application Failed",
                    JOptionPane.ERROR_MESSAGE);
            }
        });
        
        // Initial rate display
        updateRateDisplay(typeCombo, rateDisplayLabel);
        
        return panel;
    }
    
    private JPanel createPayPanel() {
        JPanel panel = new JPanel(null);
        panel.setBackground(new Color(255, 248, 240));
        
        // Title
        JLabel titleLabel = new JLabel("💳 Pay Loan Installment");
        titleLabel.setFont(new Font("Segoe UI", Font.BOLD, 18));
        titleLabel.setForeground(new Color(200, 100, 0));
        titleLabel.setBounds(120, 20, 250, 30);
        
        // Info
        JLabel infoLabel = new JLabel("Enter payment amount:");
        infoLabel.setFont(new Font("Segoe UI", Font.BOLD, 12));
        infoLabel.setBounds(20, 60, 300, 25);
        
        // Amount
        JLabel amountLabel = new JLabel("Payment Amount ($):");
        amountLabel.setFont(new Font("Segoe UI", Font.BOLD, 12));
        amountLabel.setBounds(20, 100, 150, 25);
        
        JTextField amountField = new JTextField();
        amountField.setBounds(180, 100, 200, 30);
        amountField.setFont(new Font("Segoe UI", Font.PLAIN, 14));
        
        // Buttons
        JButton checkBtn = new JButton("🔍 Check Loan Status");
        checkBtn.setBounds(50, 150, 150, 35);
        checkBtn.setFont(new Font("Segoe UI", Font.BOLD, 12));
        checkBtn.setBackground(new Color(70, 130, 180));
        checkBtn.setForeground(Color.BLACK);
        checkBtn.setFocusPainted(false);
        
        JButton payBtn = new JButton("✅ Make Payment");
        payBtn.setBounds(210, 150, 150, 35);
        payBtn.setFont(new Font("Segoe UI", Font.BOLD, 12));
        payBtn.setBackground(new Color(60, 179, 113));
        payBtn.setForeground(Color.BLACK);
        payBtn.setFocusPainted(false);
        
        // Loan Info Area
        JTextArea loanInfo = new JTextArea();
        loanInfo.setEditable(false);
        loanInfo.setFont(new Font("Monospaced", Font.PLAIN, 12));
        loanInfo.setBounds(20, 200, 420, 250);
        loanInfo.setBorder(BorderFactory.createTitledBorder(
            BorderFactory.createLineBorder(new Color(180, 180, 180), 1),
            "Loan Details"
        ));
        loanInfo.setBackground(new Color(248, 248, 255));
        
        // Add components
        panel.add(titleLabel);
        panel.add(infoLabel);
        panel.add(amountLabel);
        panel.add(amountField);
        panel.add(checkBtn);
        panel.add(payBtn);
        panel.add(loanInfo);
        
        // Check Loan Status
        checkBtn.addActionListener(e -> {
            try {
                model.LoanAccount loan = LoanService.getActiveLoan(user.getAccountNo());
                if (loan != null) {
                    loanInfo.setText(
                        String.format(
                            "✅ ACTIVE LOAN FOUND\n" +
                            "════════════════════════════════════\n" +
                            "Loan Type:        %s\n" +
                            "Borrowed Amount:  $%.2f\n" +
                            "Interest Rate:    %.1f%%\n" +
                            "Remaining Balance: $%.2f\n" +
                            "Loan Duration:    %d months\n" +
                            "Months Passed:    %d months\n" +
                            "Next EMI Due:     $%.2f\n" +
                            "════════════════════════════════════\n" +
                            "💡 Tip: Pay more than EMI to reduce interest.",
                            getLoanTypeFromRate(loan.getInterestRate()),
                            loan.getBorrowedAmount(),
                            loan.getInterestRate() * 100,
                            loan.getRemainingBalance(),
                            loan.getLoanDurationMonths(),
                            estimateMonthsPassed(loan),
                            LoanService.calculateEMI(
                                loan.getBorrowedAmount(),
                                loan.getInterestRate(),
                                loan.getLoanDurationMonths()
                            )
                        )
                    );
                } else {
                    loanInfo.setText(
                        "❌ NO ACTIVE LOAN FOUND\n" +
                        "════════════════════════════════════\n" +
                        "You don't have any active loans.\n" +
                        "You can apply for a new loan from the 'Apply Loan' tab.\n\n" +
                        "Loan Options:\n" +
                        "• Home Loan: 8.5%\n" +
                        "• Car Loan: 9.5%\n" +
                        "• Personal Loan: 12.5%\n" +
                        "• Education Loan: 7.5%"
                    );
                }
            } catch (Exception ex) {
                loanInfo.setText("Error: " + ex.getMessage());
            }
        });
        
        // Make Payment
        payBtn.addActionListener(e -> {
            try {
                String amountText = amountField.getText().trim();
                if (amountText.isEmpty()) {
                    JOptionPane.showMessageDialog(this, "❌ Please enter payment amount");
                    return;
                }
                
                double amount = Double.parseDouble(amountText);
                
                if (amount <= 0) {
                    JOptionPane.showMessageDialog(this, "❌ Please enter positive amount");
                    return;
                }
                
                if (amount > user.getAccount().getBalance()) {
                    JOptionPane.showMessageDialog(this, "❌ Insufficient balance to pay loan");
                    return;
                }
                
                // Confirm payment
                int confirm = JOptionPane.showConfirmDialog(this,
                    String.format("Confirm payment of $%.2f towards loan?", amount),
                    "Confirm Payment",
                    JOptionPane.YES_NO_OPTION);
                
                if (confirm != JOptionPane.YES_OPTION) {
                    return;
                }
                
                LoanService.payLoanInstallment(user, amount);
                
                // Refresh dashboard
                dashboard.refreshData();
                
                JOptionPane.showMessageDialog(this, 
                    String.format("✅ Payment of $%.2f successful!", amount),
                    "Payment Complete",
                    JOptionPane.INFORMATION_MESSAGE);
                
                // Refresh loan info
                checkBtn.doClick();
                amountField.setText("");
                
            } catch (Exception ex) {
                JOptionPane.showMessageDialog(this, 
                    "❌ Error: " + ex.getMessage(),
                    "Payment Failed",
                    JOptionPane.ERROR_MESSAGE);
            }
        });
        
        return panel;
    }
    
    private JPanel createStatusPanel() {
        JPanel panel = new JPanel(new BorderLayout());
        panel.setBackground(Color.WHITE);
        
        // Title
        JLabel titleLabel = new JLabel("📜 Loan History", JLabel.CENTER);
        titleLabel.setFont(new Font("Segoe UI", Font.BOLD, 16));
        titleLabel.setForeground(new Color(0, 100, 200));
        titleLabel.setBorder(BorderFactory.createEmptyBorder(10, 0, 10, 0));
        
        // History Area
        JTextArea historyArea = new JTextArea();
        historyArea.setEditable(false);
        historyArea.setFont(new Font("Monospaced", Font.PLAIN, 12));
        historyArea.setBackground(new Color(248, 248, 255));
        
        JScrollPane scrollPane = new JScrollPane(historyArea);
        scrollPane.setBorder(BorderFactory.createEmptyBorder(10, 10, 10, 10));
        
        // Refresh Button
        JButton refreshBtn = new JButton("🔄 Refresh History");
        refreshBtn.setFont(new Font("Segoe UI", Font.BOLD, 12));
        refreshBtn.setBackground(new Color(70, 130, 180));
        refreshBtn.setForeground(Color.WHITE);
        refreshBtn.setFocusPainted(false);
        
        JPanel buttonPanel = new JPanel();
        buttonPanel.setBackground(Color.WHITE);
        buttonPanel.add(refreshBtn);
        
        panel.add(titleLabel, BorderLayout.NORTH);
        panel.add(scrollPane, BorderLayout.CENTER);
        panel.add(buttonPanel, BorderLayout.SOUTH);
        
        // Load loan history
        refreshBtn.addActionListener(e -> {
            java.util.List<model.LoanAccount> history = 
                LoanService.getLoanHistory(user.getAccountNo());
            
            StringBuilder sb = new StringBuilder();
            if (history.isEmpty()) {
                sb.append("📭 NO LOAN HISTORY FOUND\n");
                sb.append("════════════════════════════════════\n");
                sb.append("You haven't taken any loans yet.\n");
                sb.append("Apply for your first loan from the 'Apply Loan' tab.\n\n");
                sb.append("Why take a loan?\n");
                sb.append("• Home purchase/renovation\n");
                sb.append("• Car/bike purchase\n");
                sb.append("• Education expenses\n");
                sb.append("• Medical emergencies\n");
                sb.append("• Business investment\n");
            } else {
                sb.append("📋 LOAN HISTORY\n");
                sb.append("════════════════════════════════════\n");
                int count = 1;
                for (model.LoanAccount loan : history) {
                    sb.append(String.format(
                        "Loan #%d\n" +
                        "Type:          %s\n" +
                        "Amount:        $%.2f\n" +
                        "Interest Rate: %.1f%%\n" +
                        "Duration:      %d months\n" +
                        "Status:        %s\n" +
                        "════════════════════════════════════\n",
                        count++,
                        getLoanTypeFromRate(loan.getInterestRate()),
                        loan.getBorrowedAmount(),
                        loan.getInterestRate() * 100,
                        loan.getLoanDurationMonths(),
                        loan.getRemainingBalance() > 0 ? "Active" : "Paid Off"
                    ));
                }
                sb.append(String.format("\nTotal Loans: %d", history.size()));
            }
            historyArea.setText(sb.toString());
        });
        
        // Load initial data
        refreshBtn.doClick();
        
        return panel;
    }
    
    // Helper Methods
    
    private void updateRateDisplay(JComboBox<String> typeCombo, JLabel rateLabel) {
        String selected = (String) typeCombo.getSelectedItem();
        double rate = getRateForType(selected) * 100;
        rateLabel.setText(String.format("Interest Rate: %.1f%% (Fixed by Bank)", rate));
    }
    
    private double getRateForType(String loanType) {
        if (loanType.contains("Home")) return 0.085;
        if (loanType.contains("Car")) return 0.095;
        if (loanType.contains("Personal")) return 0.125;
        if (loanType.contains("Education")) return 0.075;
        return 0.100; // Default
    }
    
    private String getLoanTypeName(String loanType) {
        if (loanType.contains("Home")) return "Home Loan";
        if (loanType.contains("Car")) return "Car Loan";
        if (loanType.contains("Personal")) return "Personal Loan";
        if (loanType.contains("Education")) return "Education Loan";
        return "Personal Loan";
    }
    
    private String getLoanTypeFromRate(double rate) {
        if (Math.abs(rate - 0.085) < 0.001) return "Home Loan";
        if (Math.abs(rate - 0.095) < 0.001) return "Car Loan";
        if (Math.abs(rate - 0.125) < 0.001) return "Personal Loan";
        if (Math.abs(rate - 0.075) < 0.001) return "Education Loan";
        return "Personal Loan";
    }
    
    private int estimateMonthsPassed(model.LoanAccount loan) {
        // Simplified: estimate based on remaining balance
        double borrowed = loan.getBorrowedAmount();
        double remaining = loan.getRemainingBalance();
        double paid = borrowed - remaining;
        double emi = LoanService.calculateEMI(borrowed, loan.getInterestRate(), 
                                            loan.getLoanDurationMonths());
        return (int) Math.ceil(paid / emi);
    }
}