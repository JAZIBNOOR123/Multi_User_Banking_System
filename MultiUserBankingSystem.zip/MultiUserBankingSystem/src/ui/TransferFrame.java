package ui;

import javax.swing.*;
import javax.swing.border.*;
import java.awt.*;
import java.awt.event.*;
import java.awt.geom.RoundRectangle2D;
import model.User;
import service.BankService;
import exception.InsufficientBalanceException;

public class TransferFrame extends JFrame {
    
    private User sender;
    private DashboardFrame dashboard;
    private Point mouseDownCompCoords = null; // Moved to class level
    
    public TransferFrame(User sender, DashboardFrame dashboard) {
        this.sender = sender;
        this.dashboard = dashboard;
        
        setTitle("Transfer Money - Nexus Bank");
        setSize(550, 650);
        setLocationRelativeTo(null);
        setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        setResizable(false);
        
        // Modern look with rounded corners
        setUndecorated(true);
        setShape(new RoundRectangle2D.Double(0, 0, 550, 650, 20, 20));
        
        initUI();
    }
    
    private void initUI() {
        // Main panel with modern gradient
        JPanel mainPanel = new JPanel(new BorderLayout()) {
            @Override
            protected void paintComponent(Graphics g) {
                super.paintComponent(g);
                Graphics2D g2d = (Graphics2D) g;
                g2d.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
                
                // Modern gradient background
                GradientPaint gradient = new GradientPaint(
                    0, 0, new Color(248, 249, 252),
                    getWidth(), getHeight(), new Color(240, 242, 245)
                );
                g2d.setPaint(gradient);
                g2d.fillRect(0, 0, getWidth(), getHeight());
            }
        };
        mainPanel.setBorder(BorderFactory.createEmptyBorder(20, 20, 20, 20));
        
        // Header Panel
        JPanel headerPanel = new JPanel(new BorderLayout());
        headerPanel.setOpaque(false);
        
        // Title with icon
        JLabel titleLabel = new JLabel("Transfer Money");
        titleLabel.setFont(new Font("Segoe UI", Font.BOLD, 28));
        titleLabel.setForeground(new Color(26, 35, 126));
        // Note: You'll need to add your own icon file
        // titleLabel.setIcon(new ImageIcon(getClass().getResource("/icons/transfer.png")));
        titleLabel.setHorizontalAlignment(SwingConstants.LEFT);
        
        // Close button
        JButton closeBtn = new JButton("✕");
        closeBtn.setFont(new Font("Segoe UI", Font.BOLD, 18));
        closeBtn.setForeground(new Color(108, 117, 125));
        closeBtn.setContentAreaFilled(false);
        closeBtn.setBorderPainted(false);
        closeBtn.setFocusPainted(false);
        closeBtn.setCursor(new Cursor(Cursor.HAND_CURSOR));
        closeBtn.addActionListener(e -> dispose());
        closeBtn.addMouseListener(new MouseAdapter() {
            @Override
            public void mouseEntered(MouseEvent e) {
                closeBtn.setForeground(Color.RED);
            }
            @Override
            public void mouseExited(MouseEvent e) {
                closeBtn.setForeground(new Color(108, 117, 125));
            }
        });
        
        headerPanel.add(titleLabel, BorderLayout.WEST);
        headerPanel.add(closeBtn, BorderLayout.EAST);
        
        // Main Form Panel
        JPanel formPanel = new JPanel();
        formPanel.setLayout(new GridBagLayout());
        formPanel.setOpaque(false);
        
        GridBagConstraints gbc = new GridBagConstraints();
        gbc.fill = GridBagConstraints.HORIZONTAL;
        gbc.insets = new Insets(12, 0, 12, 0);
        
        // Account Info Card
        JPanel accountCard = createStyledPanel();
        accountCard.setLayout(new BorderLayout());
        accountCard.setPreferredSize(new Dimension(500, 80));
        
        JPanel accountLeft = new JPanel(new GridLayout(2, 1));
        accountLeft.setOpaque(false);
        
        JLabel accountLabel = new JLabel("Your Account");
        accountLabel.setFont(new Font("Segoe UI", Font.PLAIN, 12));
        accountLabel.setForeground(new Color(108, 117, 125));
        
        JLabel accountNumber = new JLabel("#" + sender.getAccountNo());
        accountNumber.setFont(new Font("Segoe UI", Font.BOLD, 16));
        accountNumber.setForeground(new Color(33, 37, 41));
        
        accountLeft.add(accountLabel);
        accountLeft.add(accountNumber);
        
        JPanel accountRight = new JPanel(new GridLayout(2, 1));
        accountRight.setOpaque(false);
        
        JLabel balanceLabel = new JLabel("Available Balance");
        balanceLabel.setFont(new Font("Segoe UI", Font.PLAIN, 12));
        balanceLabel.setForeground(new Color(108, 117, 125));
        balanceLabel.setHorizontalAlignment(SwingConstants.RIGHT);
        
        JLabel balanceAmount = new JLabel(String.format("$%.2f", sender.getAccount().getBalance()));
        balanceAmount.setFont(new Font("Segoe UI", Font.BOLD, 20));
        balanceAmount.setForeground(new Color(40, 167, 69));
        balanceAmount.setHorizontalAlignment(SwingConstants.RIGHT);
        
        accountRight.add(balanceLabel);
        accountRight.add(balanceAmount);
        
        accountCard.add(accountLeft, BorderLayout.WEST);
        accountCard.add(accountRight, BorderLayout.EAST);
        
        gbc.gridx = 0;
        gbc.gridy = 0;
        gbc.gridwidth = 2;
        formPanel.add(accountCard, gbc);
        
        // Recipient Account
        JLabel recipientLabel = new JLabel("Recipient Account Number");
        recipientLabel.setFont(new Font("Segoe UI", Font.BOLD, 14));
        recipientLabel.setForeground(new Color(73, 80, 87));
        gbc.gridx = 0;
        gbc.gridy = 1;
        gbc.gridwidth = 2;
        formPanel.add(recipientLabel, gbc);
        
        JTextField toAccountField = new JTextField();
        toAccountField.setFont(new Font("Segoe UI", Font.PLAIN, 16));
        toAccountField.setBorder(createInputBorder());
        toAccountField.setPreferredSize(new Dimension(500, 48));
        gbc.gridx = 0;
        gbc.gridy = 2;
        gbc.gridwidth = 2;
        formPanel.add(toAccountField, gbc);
        
        // Amount
        JLabel amountLabel = new JLabel("Amount ($)");
        amountLabel.setFont(new Font("Segoe UI", Font.BOLD, 14));
        amountLabel.setForeground(new Color(73, 80, 87));
        gbc.gridx = 0;
        gbc.gridy = 3;
        gbc.gridwidth = 2;
        formPanel.add(amountLabel, gbc);
        
        JTextField amountField = new JTextField();
        amountField.setFont(new Font("Segoe UI", Font.PLAIN, 16));
        amountField.setBorder(createInputBorder());
        amountField.setPreferredSize(new Dimension(500, 48));
        gbc.gridx = 0;
        gbc.gridy = 4;
        gbc.gridwidth = 2;
        formPanel.add(amountField, gbc);
        
        // Quick Amounts Section
        JLabel quickLabel = new JLabel("Quick Amounts");
        quickLabel.setFont(new Font("Segoe UI", Font.BOLD, 14));
        quickLabel.setForeground(new Color(73, 80, 87));
        gbc.gridx = 0;
        gbc.gridy = 5;
        gbc.gridwidth = 2;
        gbc.insets = new Insets(20, 0, 10, 0);
        formPanel.add(quickLabel, gbc);
        
        // Quick Amount Buttons
        double[] amounts = {100, 500, 1000, 2000, 5000, 10000, 20000, 50000};
        JPanel quickPanel = new JPanel(new GridLayout(2, 4, 10, 10));
        quickPanel.setOpaque(false);
        
        for (double amt : amounts) {
            JButton amountBtn = createAmountButton(amt);
            amountBtn.addActionListener(e -> {
                amountField.setText(String.valueOf(amt));
                amountField.requestFocus();
            });
            quickPanel.add(amountBtn);
        }
        
        gbc.gridx = 0;
        gbc.gridy = 6;
        gbc.gridwidth = 2;
        gbc.insets = new Insets(0, 0, 20, 0);
        formPanel.add(quickPanel, gbc);
        
        // Transfer Button
        JButton transferBtn = new JButton("Transfer Now") {
            @Override
            protected void paintComponent(Graphics g) {
                Graphics2D g2 = (Graphics2D) g.create();
                g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
                
                // Gradient background
                GradientPaint gradient = new GradientPaint(
                    0, 0, new Color(76, 175, 80),
                    0, getHeight(), new Color(56, 142, 60)
                );
                g2.setPaint(gradient);
                g2.fillRoundRect(0, 0, getWidth(), getHeight(), 10, 10);
                
                super.paintComponent(g2);
                g2.dispose();
            }
        };
        transferBtn.setFont(new Font("Segoe UI", Font.BOLD, 18));
        transferBtn.setForeground(Color.WHITE);
        transferBtn.setContentAreaFilled(false);
        transferBtn.setBorderPainted(false);
        transferBtn.setFocusPainted(false);
        transferBtn.setCursor(new Cursor(Cursor.HAND_CURSOR));
        transferBtn.setPreferredSize(new Dimension(500, 50));
        
        // Transfer Action
        transferBtn.addActionListener(e -> processTransfer(toAccountField, amountField));
        
        gbc.gridx = 0;
        gbc.gridy = 7;
        gbc.gridwidth = 2;
        gbc.insets = new Insets(20, 0, 0, 0);
        formPanel.add(transferBtn, gbc);
        
        // Add all panels to main
        mainPanel.add(headerPanel, BorderLayout.NORTH);
        mainPanel.add(formPanel, BorderLayout.CENTER);
        
        // Add drag functionality to move window - FIXED VERSION
        MouseAdapter dragAdapter = new MouseAdapter() {
            @Override
            public void mouseDragged(MouseEvent e) {
                if (mouseDownCompCoords != null) {
                    Point currCoords = e.getLocationOnScreen();
                    setLocation(currCoords.x - mouseDownCompCoords.x, 
                               currCoords.y - mouseDownCompCoords.y);
                }
            }
            
            @Override
            public void mousePressed(MouseEvent e) {
                mouseDownCompCoords = e.getPoint();
            }
            
            @Override
            public void mouseReleased(MouseEvent e) {
                mouseDownCompCoords = null;
            }
        };
        
        // Apply the mouse adapter to the main panel for dragging
        mainPanel.addMouseListener(dragAdapter);
        mainPanel.addMouseMotionListener(dragAdapter);
        
        // Also apply to header panel
        headerPanel.addMouseListener(dragAdapter);
        headerPanel.addMouseMotionListener(dragAdapter);
        
        add(mainPanel);
        
        // Set focus
        toAccountField.requestFocus();
        
        // Add Enter key listener
        amountField.addKeyListener(new KeyAdapter() {
            @Override
            public void keyPressed(KeyEvent e) {
                if (e.getKeyCode() == KeyEvent.VK_ENTER) {
                    transferBtn.doClick();
                }
            }
        });
    }
    
    private JPanel createStyledPanel() {
        JPanel panel = new JPanel() {
            @Override
            protected void paintComponent(Graphics g) {
                super.paintComponent(g);
                Graphics2D g2d = (Graphics2D) g;
                g2d.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
                g2d.setColor(Color.WHITE);
                g2d.fillRoundRect(0, 0, getWidth(), getHeight(), 15, 15);
                
                // Add subtle shadow
                g2d.setColor(new Color(0, 0, 0, 5));
                g2d.drawRoundRect(0, 0, getWidth() - 1, getHeight() - 1, 15, 15);
            }
        };
        panel.setBorder(BorderFactory.createEmptyBorder(15, 20, 15, 20));
        return panel;
    }
    
    private Border createInputBorder() {
        return BorderFactory.createCompoundBorder(
            BorderFactory.createLineBorder(new Color(206, 212, 218), 1),
            BorderFactory.createEmptyBorder(12, 15, 12, 15)
        );
    }
    
    private JButton createAmountButton(double amount) {
        JButton button = new JButton(String.format("$%,.0f", amount)) {
            @Override
            protected void paintComponent(Graphics g) {
                Graphics2D g2d = (Graphics2D) g;
                g2d.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
                
                if (getModel().isPressed()) {
                    g2d.setColor(new Color(233, 236, 239));
                } else if (getModel().isRollover()) {
                    g2d.setColor(new Color(248, 249, 250));
                } else {
                    g2d.setColor(Color.WHITE);
                }
                
                g2d.fillRoundRect(0, 0, getWidth(), getHeight(), 10, 10);
                
                super.paintComponent(g2d);
                
                // Border
                g2d.setColor(new Color(222, 226, 230));
                g2d.drawRoundRect(0, 0, getWidth() - 1, getHeight() - 1, 10, 10);
            }
        };
        
        button.setFont(new Font("Segoe UI", Font.BOLD, 14));
        button.setForeground(new Color(33, 37, 41));
        button.setContentAreaFilled(false);
        button.setBorderPainted(false);
        button.setFocusPainted(false);
        button.setCursor(new Cursor(Cursor.HAND_CURSOR));
        button.setPreferredSize(new Dimension(80, 40));
        
        return button;
    }
    
    private void processTransfer(JTextField toAccountField, JTextField amountField) {
        try {
            String toAccountText = toAccountField.getText().trim();
            String amountText = amountField.getText().trim();
            
            // Validation
            if (toAccountText.isEmpty()) {
                showError("Please enter recipient account number");
                toAccountField.requestFocus();
                return;
            }
            
            if (amountText.isEmpty()) {
                showError("Please enter amount");
                amountField.requestFocus();
                return;
            }
            
            int toAccountNo = Integer.parseInt(toAccountText);
            double amount = Double.parseDouble(amountText);
            
            if (amount <= 0) {
                showError("Amount must be greater than 0");
                amountField.requestFocus();
                return;
            }
            
            if (amount > 50000) {
                showError("Maximum transfer limit is $50,000");
                amountField.setText("");
                amountField.requestFocus();
                return;
            }
            
            // Check balance
            if (sender.getAccount().getBalance() < amount) {
                throw new InsufficientBalanceException("Insufficient Balance");
            }
            
            // Confirm dialog
            int confirm = JOptionPane.showConfirmDialog(this,
                String.format("<html><div style='width:250px;text-align:center;'>"
                    + "<h3 style='color:#1a237e;'>Confirm Transfer</h3>"
                    + "<p>Amount: <b style='color:#4caf50;font-size:18px;'>$%.2f</b></p>"
                    + "<p>To Account: <b>#%d</b></p>"
                    + "<br><p>Proceed with transfer?</p></div></html>",
                    amount, toAccountNo),
                "Confirm Transfer",
                JOptionPane.YES_NO_OPTION,
                JOptionPane.QUESTION_MESSAGE);
            
            if (confirm != JOptionPane.YES_OPTION) {
                return;
            }
            
            // Perform transfer
            BankService.withdraw(sender.getAccount(), amount);
            
            // Add transaction record
            String description = String.format("Transfer to account: %d", toAccountNo);
            
            service.TransactionService.addTransaction(
                sender.getAccountNo(), 
                "TRANSFER", 
                -amount, 
                description
            );
            
            // Refresh dashboard
            dashboard.refreshData();
            
            // Success message
            showSuccess(String.format("<html><div style='width:250px;text-align:center;'>"
                + "<h3 style='color:#4caf50;'>✓ Transfer Successful</h3>"
                + "<p>Amount: <b>$%.2f</b></p>"
                + "<p>To Account: <b>#%d</b></p>"
                + "<p>Transaction completed successfully</p></div></html>",
                amount, toAccountNo));
            
            dispose();
            
        } catch (NumberFormatException ex) {
            showError("Please enter valid numbers");
            amountField.requestFocus();
        } catch (InsufficientBalanceException ex) {
            showError("Insufficient balance for this transfer");
            amountField.requestFocus();
        } catch (Exception ex) {
            showError("Error: " + ex.getMessage());
        }
    }
    
    private void showError(String message) {
        JOptionPane.showMessageDialog(this, 
            "<html><div style='text-align:center;color:#dc3545;font-weight:bold;'>"
            + "✗ " + message + "</div></html>",
            "Transfer Failed",
            JOptionPane.ERROR_MESSAGE);
    }
    
    private void showSuccess(String message) {
        JOptionPane.showMessageDialog(this, 
            message,
            "Transfer Complete",
            JOptionPane.INFORMATION_MESSAGE);
    }
}