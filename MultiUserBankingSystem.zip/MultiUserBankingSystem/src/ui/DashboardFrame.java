package ui;

import javax.swing.*;
import javax.swing.border.*;
import javax.swing.table.DefaultTableCellRenderer;
import javax.swing.table.DefaultTableModel;
import javax.swing.table.JTableHeader;

import java.awt.Graphics2D;
import java.awt.RenderingHints;
import java.awt.FontMetrics;
import java.awt.BasicStroke;
import java.util.Collections;
import java.util.ArrayList;
import java.awt.*;
import java.awt.event.*;
import java.util.Map;
import java.util.List;
import java.util.Calendar;
import java.util.Date;
import java.text.SimpleDateFormat;
import model.User;
import service.StatementService;
import service.TransactionService;

public class DashboardFrame extends JFrame {

    private User user;
    private JLabel balanceLabel;
    private JLabel accountInfoLabel;
    private CardLayout cardLayout;
    private JPanel mainContentPanel;
    
    // IMPROVED COLOR SCHEME for better visibility
    private final Color PRIMARY_COLOR = new Color(30, 60, 114); // Dark Blue
    private final Color SECONDARY_COLOR = new Color(40, 100, 200); // Light Blue
    private final Color SUCCESS_COLOR = new Color(60, 179, 113); // Green
    private final Color DANGER_COLOR = new Color(220, 20, 60); // Red
    private final Color WARNING_COLOR = new Color(255, 140, 0); // Orange
    
    // IMPROVED: Darker background for better contrast
    private final Color BACKGROUND_COLOR = new Color(235, 240, 245); // Light Gray-Blue 235, 240, 245
    
    // IMPROVED: Better text colors
    private final Color TEXT_DARK = new Color(51, 51, 51); // Dark gray for text
    private final Color TEXT_MEDIUM = new Color(85, 85, 85); // Medium gray
    private final Color TEXT_LIGHT = new Color(119, 119, 119); // Light gray
    
    // NEW: Button text colors for better visibility
    private final Color BUTTON_TEXT_LIGHT = new Color(240, 240, 240); // Light text for dark buttons
    private final Color BUTTON_TEXT_DARK = new Color(30, 30, 30); // Dark text for light buttons
    private final Color CARD_BORDER_COLOR = new Color(222, 226, 230);
    private final Color CARD_BACKGROUND = new Color(180, 200, 255);
    
    public DashboardFrame(User user) {
        this.user = user;
        
        setBetterDefaultColors();
        
        setTitle("Nexus Bank - Dashboard");
        setSize(1000, 700);
        setLocationRelativeTo(null);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLayout(new BorderLayout());
        
        initUI();
        
        // ✅ FIX BUTTON COLORS AFTER UI IS CREATED
        fixAllButtonColors();
    }
    
    // NEW METHOD: Set better default colors for all UI components
    private void setBetterDefaultColors() {
        // Force better contrast for all Swing components
        UIManager.put("Label.foreground", TEXT_DARK);
        UIManager.put("Panel.background", BACKGROUND_COLOR);
        UIManager.put("Button.foreground", TEXT_DARK);  // ✅ Button text dark by default
        UIManager.put("TextField.foreground", TEXT_DARK);
        UIManager.put("TextArea.foreground", TEXT_DARK);
        UIManager.put("Table.foreground", TEXT_DARK);
        UIManager.put("TableHeader.foreground", TEXT_DARK);
        UIManager.put("ComboBox.foreground", TEXT_DARK);
        UIManager.put("TitledBorder.titleColor", TEXT_DARK);
    }
    
    private void initUI() {
        // Main container
        JPanel mainPanel = new JPanel(new BorderLayout());
        mainPanel.setBackground(BACKGROUND_COLOR);
        
        // ========== TOP HEADER ==========
        JPanel headerPanel = createHeaderPanel();
        
        // ========== SIDEBAR ==========
        JPanel sidebarPanel = createSidebarPanel();
        
        // ========== MAIN CONTENT ==========
        mainContentPanel = new JPanel();
        cardLayout = new CardLayout();
        mainContentPanel.setLayout(cardLayout);
        mainContentPanel.setBackground(BACKGROUND_COLOR);
        
        // Create content panels
        mainContentPanel.add(createOverviewPanel(), "OVERVIEW");
        mainContentPanel.add(createAccountsPanel(), "ACCOUNTS");
        mainContentPanel.add(createTransactionsPanel(), "TRANSACTIONS");
        mainContentPanel.add(createStatementsPanel(), "STATEMENTS");
        mainContentPanel.add(createTransferPanel(), "TRANSFER");
        
        // Initially show overview
        cardLayout.show(mainContentPanel, "OVERVIEW");
        
        // Assemble main panel
        mainPanel.add(headerPanel, BorderLayout.NORTH);
        mainPanel.add(sidebarPanel, BorderLayout.WEST);
        mainPanel.add(mainContentPanel, BorderLayout.CENTER);
        
        add(mainPanel);
        
        // Refresh data
        refreshData();
    }
    
    private void fixAllButtonColors() {
        // Fix all buttons in the frame
        fixButtonColorsRecursively(this);
    }

    private void fixButtonColorsRecursively(Container container) {
        for (Component comp : container.getComponents()) {
            if (comp instanceof JButton) {
                JButton btn = (JButton) comp;
                Color bg = btn.getBackground();
                
                // Check if background is dark
                if (bg != null) {
                    double brightness = (bg.getRed() * 0.299 + 
                                       bg.getGreen() * 0.587 + 
                                       bg.getBlue() * 0.114);
                    if (brightness > 150) { // Dark background
                        btn.setForeground(Color.WHITE);
                    } else { // Light background
                        btn.setForeground(Color.BLACK);
                    }
                }
            }
            
            if (comp instanceof Container) {
                fixButtonColorsRecursively((Container) comp);
            }
        }
    }
    
    private JPanel createHeaderPanel() {
        JPanel header = new JPanel(new BorderLayout());
        header.setBackground(CARD_BACKGROUND);
        header.setBorder(BorderFactory.createCompoundBorder(
            BorderFactory.createMatteBorder(0, 0, 1, 0, new Color(230, 230, 230)),
            BorderFactory.createEmptyBorder(15, 30, 15, 30)
        ));
        
        // Bank logo/name
        JLabel bankLabel = new JLabel("🏦 NEXUS BANK");
        bankLabel.setFont(new Font("Segoe UI", Font.BOLD, 22));
        bankLabel.setForeground(PRIMARY_COLOR);
        
        // User info on right
        JPanel userPanel = new JPanel(new FlowLayout(FlowLayout.RIGHT, 20, 0));
        userPanel.setBackground(CARD_BACKGROUND);
        
        // User name and account
        JPanel infoPanel = new JPanel(new GridLayout(2, 1, 0, 5));
        infoPanel.setBackground(CARD_BACKGROUND);
        
        JLabel nameLabel = new JLabel(user.getName());
        nameLabel.setFont(new Font("Segoe UI", Font.BOLD, 14));
        nameLabel.setForeground(TEXT_DARK);
        
        accountInfoLabel = new JLabel("Account #" + user.getAccountNo());
        accountInfoLabel.setFont(new Font("Segoe UI", Font.PLAIN, 12));
        accountInfoLabel.setForeground(TEXT_MEDIUM);
        
        infoPanel.add(nameLabel);
        infoPanel.add(accountInfoLabel);
        
        // Notification icon
        JButton notificationBtn = createIconButton("🔔", "Notifications");
        
        // Logout button
        JButton logoutBtn = new JButton("Logout");
        logoutBtn.setFont(new Font("Segoe UI", Font.BOLD, 12));
        logoutBtn.setBackground(PRIMARY_COLOR);
        logoutBtn.setForeground(BUTTON_TEXT_LIGHT);
        logoutBtn.setBorder(BorderFactory.createCompoundBorder(
            BorderFactory.createLineBorder(PRIMARY_COLOR.darker()),
            BorderFactory.createEmptyBorder(8, 20, 8, 20)
        ));
        logoutBtn.setFocusPainted(false);
        logoutBtn.setCursor(new Cursor(Cursor.HAND_CURSOR));
        
        logoutBtn.addActionListener(e -> logout());
        
        userPanel.add(infoPanel);
        userPanel.add(notificationBtn);
        userPanel.add(logoutBtn);
        
        header.add(bankLabel, BorderLayout.WEST);
        header.add(userPanel, BorderLayout.EAST);
        
        return header;
    }
    
    private JButton createIconButton(String icon, String tooltip) {
        JButton button = new JButton(icon);
        button.setFont(new Font("Segoe UI", Font.PLAIN, 18));
        button.setToolTipText(tooltip);
        button.setBorderPainted(false);
        button.setContentAreaFilled(false);
        button.setFocusPainted(false);
        button.setCursor(new Cursor(Cursor.HAND_CURSOR));
        button.setForeground(TEXT_MEDIUM);
        
        button.addMouseListener(new MouseAdapter() {
            @Override
            public void mouseEntered(MouseEvent e) {
                button.setForeground(PRIMARY_COLOR);
            }
            
            @Override
            public void mouseExited(MouseEvent e) {
                button.setForeground(TEXT_MEDIUM);
            }
        });
        
        return button;
    }
    
    private JPanel createSidebarPanel() {
        JPanel sidebar = new JPanel(new BorderLayout());
        sidebar.setBackground(PRIMARY_COLOR);
        sidebar.setPreferredSize(new Dimension(220, 0));
        sidebar.setBorder(BorderFactory.createEmptyBorder(30, 20, 20, 20));
        
        // Navigation items
        String[] navItems = {"📊 Overview", "💳 Accounts", "📋 Transactions", "📄 Statements", "🔄 Transfer", "⚙️ Settings"};
        String[] navIds = {"OVERVIEW", "ACCOUNTS", "TRANSACTIONS", "STATEMENTS", "TRANSFER", "SETTINGS"};
        
        JPanel navPanel = new JPanel(new GridLayout(navItems.length, 1, 0, 10));
        navPanel.setBackground(PRIMARY_COLOR);
        
        for (int i = 0; i < navItems.length; i++) {
            JButton navBtn = createNavButton(navItems[i], navIds[i]);
            navPanel.add(navBtn);
        }
        
        // Balance panel at bottom of sidebar
        JPanel balancePanel = new JPanel(new BorderLayout());
        balancePanel.setBackground(new Color(50, 80, 140));
        balancePanel.setBorder(BorderFactory.createCompoundBorder(
            BorderFactory.createLineBorder(new Color(70, 100, 160), 2),
            BorderFactory.createEmptyBorder(20, 15, 20, 15)
        ));
        
        JLabel balanceTitle = new JLabel("CURRENT BALANCE");
        balanceTitle.setFont(new Font("Segoe UI", Font.BOLD, 11));
        balanceTitle.setForeground(new Color(180, 200, 255));
        
        balanceLabel = new JLabel("$0.00");
        balanceLabel.setFont(new Font("Segoe UI", Font.BOLD, 26));
        balanceLabel.setForeground(Color.WHITE);
        
        JLabel accountType = new JLabel("Savings Account • " + user.getAccountNo());
        accountType.setFont(new Font("Segoe UI", Font.PLAIN, 10));
        accountType.setForeground(new Color(200, 220, 255));
        
        JPanel balanceInfo = new JPanel(new BorderLayout(0, 8));
        balanceInfo.setBackground(new Color(50, 80, 140));
        balanceInfo.add(balanceTitle, BorderLayout.NORTH);
        balanceInfo.add(balanceLabel, BorderLayout.CENTER);
        balanceInfo.add(accountType, BorderLayout.SOUTH);
        
        balancePanel.add(balanceInfo, BorderLayout.CENTER);
        
        sidebar.add(navPanel, BorderLayout.CENTER);
        sidebar.add(balancePanel, BorderLayout.SOUTH);
        
        return sidebar;
    }
    
    private JButton createNavButton(String text, String cardId) {
        JButton button = new JButton(text);
        button.setHorizontalAlignment(SwingConstants.LEFT);
        button.setFont(new Font("Segoe UI", Font.PLAIN, 14));
        button.setForeground(Color.WHITE);
        button.setBackground(PRIMARY_COLOR);
        button.setBorder(BorderFactory.createEmptyBorder(12, 15, 12, 15));
        button.setFocusPainted(false);
        button.setCursor(new Cursor(Cursor.HAND_CURSOR));
        
        button.addActionListener(e -> {
            // Remove highlight from all buttons
            for (Component comp : ((JPanel)button.getParent()).getComponents()) {
                comp.setBackground(PRIMARY_COLOR);
            }
            // Highlight clicked button
            button.setBackground(new Color(50, 90, 164));
            
            // Show corresponding content
            if (!cardId.equals("SETTINGS")) {
                cardLayout.show(mainContentPanel, cardId);
            } else {
                JOptionPane.showMessageDialog(this, "CHAL NIKL!");
            }
        });
        
        return button;
    }
    
    // ✅ YEH OVERVIEW PANEL HAI JO GRAPHS SHOW KAREGA
    private JPanel createOverviewPanel() {
        JPanel panel = new JPanel(new BorderLayout());
        panel.setBackground(BACKGROUND_COLOR);
        panel.setBorder(BorderFactory.createEmptyBorder(30, 30, 30, 30));
        
        // Welcome message
        JPanel welcomePanel = new JPanel(new BorderLayout());
        welcomePanel.setBackground(BACKGROUND_COLOR);
        welcomePanel.setBorder(BorderFactory.createEmptyBorder(0, 0, 30, 0));
        
        JLabel welcomeLabel = new JLabel("Welcome, " + user.getName() + "!");
        welcomeLabel.setFont(new Font("Segoe UI", Font.BOLD, 28));
        welcomeLabel.setForeground(PRIMARY_COLOR);
        
        SimpleDateFormat sdf = new SimpleDateFormat("EEEE, MMMM dd, yyyy");
        JLabel dateLabel = new JLabel(sdf.format(new Date()));
        dateLabel.setFont(new Font("Segoe UI", Font.PLAIN, 14));
        dateLabel.setForeground(TEXT_MEDIUM);
        
        welcomePanel.add(welcomeLabel, BorderLayout.WEST);
        welcomePanel.add(dateLabel, BorderLayout.EAST);
        
        // ✅ QUICK STATS IN 1x2 GRID (DO GRAPHS SIDE BY SIDE)
        JPanel statsPanel = new JPanel(new GridLayout(1, 2, 20, 20));
        statsPanel.setBackground(BACKGROUND_COLOR);
        statsPanel.setBorder(BorderFactory.createEmptyBorder(0, 0, 30, 0));
        
        Calendar cal = Calendar.getInstance();
        Map<String, Object> currentData = StatementService.getMonthlySummary(
            user.getAccountNo(), cal.get(Calendar.YEAR), cal.get(Calendar.MONTH) + 1);
        
        double totalDeposits = (double) currentData.get("TOTAL_DEPOSITS");
        double totalWithdrawals = (double) currentData.get("TOTAL_WITHDRAWALS");
        double savingsRate = (double) currentData.get("SAVINGS_RATE");
        int transactionCount = (int) currentData.get("TRANSACTION_COUNT");
        double currentBalance = user.getAccount().getBalance();
        
        // Graph 1: Income vs Expenses
        statsPanel.add(createIncomeExpenseChart(totalDeposits, totalWithdrawals));
        
        // Graph 2: Balance & Transactions Overview
        statsPanel.add(createBalanceTransactionChart(currentBalance, transactionCount));
        
        // Quick actions
        JPanel actionsPanel = new JPanel(new BorderLayout());
        actionsPanel.setBackground(CARD_BACKGROUND);
        actionsPanel.setBorder(BorderFactory.createCompoundBorder(
            BorderFactory.createLineBorder(new Color(230, 230, 230)),
            BorderFactory.createEmptyBorder(20, 20, 20, 20)
        ));
        
        JLabel actionsTitle = new JLabel("Quick Actions");
        actionsTitle.setFont(new Font("Segoe UI", Font.BOLD, 16));
        actionsTitle.setForeground(PRIMARY_COLOR);
        actionsTitle.setBorder(BorderFactory.createEmptyBorder(0, 0, 15, 0));
        
        JPanel buttonsPanel = new JPanel(new GridLayout(2, 3, 15, 15));
        buttonsPanel.setBackground(CARD_BACKGROUND);
        buttonsPanel.setBorder(BorderFactory.createEmptyBorder(10, 0, 10, 0));
        
        String[] actions = {"💰 Deposit", "💸 Withdraw", "🔄 Transfer", 
                           "📄 Statement", "🏦 Loan", "ℹ️ Support"};
        Color[] colors = {
            new Color(40, 167, 69),    // Brighter Green for Deposit
            new Color(220, 53, 69),    // Brighter Red for Withdraw  
            new Color(0, 123, 255),    // Bright Blue for Transfer
            new Color(255, 153, 0),    // Orange for Statement
            new Color(111, 66, 193),   // Purple for Loan
            new Color(108, 117, 125)   // Gray for Support
        };
        
        for (int i = 0; i < actions.length; i++) {
            JButton actionBtn = createActionButton(actions[i], colors[i]);
            buttonsPanel.add(actionBtn);
        }
        
        actionsPanel.add(actionsTitle, BorderLayout.NORTH);
        actionsPanel.add(buttonsPanel, BorderLayout.CENTER);
        
        panel.add(welcomePanel, BorderLayout.NORTH);
        panel.add(statsPanel, BorderLayout.CENTER);
        panel.add(actionsPanel, BorderLayout.SOUTH);
        
        return panel;
    }
    
    // Graph 1: Income vs Expenses Bar Chart
    private JPanel createIncomeExpenseChart(double income, double expenses) {
        JPanel chartPanel = new JPanel(new BorderLayout()) {
            @Override
            protected void paintComponent(Graphics g) {
                super.paintComponent(g);
                Graphics2D g2d = (Graphics2D) g;
                g2d.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
                
                int width = getWidth();
                int height = getHeight();
                
                // Chart title
                g2d.setFont(new Font("Segoe UI", Font.BOLD, 16));
                g2d.setColor(PRIMARY_COLOR);
                g2d.drawString("Monthly Cash Flow", 10, 25);
                
                // Chart area
                int chartX = 50;
                int chartY = 60;
                int chartWidth = width - 100;
                int chartHeight = height - 120;
                
                // Draw axes
                g2d.setColor(Color.GRAY);
                g2d.drawLine(chartX, chartY + chartHeight, chartX + chartWidth, chartY + chartHeight); // X-axis
                g2d.drawLine(chartX, chartY, chartX, chartY + chartHeight); // Y-axis
                
                // Calculate max value for scaling
                double maxValue = Math.max(income, expenses);
                maxValue = Math.max(maxValue, 1000); // Minimum scale
                
                // Draw bars
                int barWidth = 60;
                int gap = 40;
                
                // Income bar
                int incomeHeight = (int) ((income / maxValue) * chartHeight);
                g2d.setColor(SUCCESS_COLOR);
                g2d.fillRect(chartX + gap, chartY + chartHeight - incomeHeight, barWidth, incomeHeight);
                g2d.setColor(SUCCESS_COLOR.darker());
                g2d.drawRect(chartX + gap, chartY + chartHeight - incomeHeight, barWidth, incomeHeight);
                
                // Expense bar
                int expenseHeight = (int) ((expenses / maxValue) * chartHeight);
                g2d.setColor(DANGER_COLOR);
                g2d.fillRect(chartX + gap + barWidth + gap, chartY + chartHeight - expenseHeight, barWidth, expenseHeight);
                g2d.setColor(DANGER_COLOR.darker());
                g2d.drawRect(chartX + gap + barWidth + gap, chartY + chartHeight - expenseHeight, barWidth, expenseHeight);
                
                // Labels
                g2d.setFont(new Font("Segoe UI", Font.PLAIN, 12));
                g2d.setColor(TEXT_DARK);
                
                // Income label
                g2d.drawString("Income", chartX + gap, chartY + chartHeight + 20);
                g2d.drawString(String.format("$%.2f", income), chartX + gap, chartY + chartHeight - incomeHeight - 5);
                
                // Expense label
                g2d.drawString("Expenses", chartX + gap + barWidth + gap, chartY + chartHeight + 20);
                g2d.drawString(String.format("$%.2f", expenses), chartX + gap + barWidth + gap, chartY + chartHeight - expenseHeight - 5);
                
                // Y-axis labels
                g2d.setColor(TEXT_MEDIUM);
                for (int i = 0; i <= 5; i++) {
                    int y = chartY + chartHeight - (i * chartHeight / 5);
                    String value = String.format("$%.0f", (maxValue / 5) * i);
                    g2d.drawString(value, chartX - 45, y + 5);
                    g2d.drawLine(chartX - 5, y, chartX, y); // Tick marks
                }
            }
        };
        
        chartPanel.setBackground(CARD_BACKGROUND);
        chartPanel.setBorder(BorderFactory.createCompoundBorder(
            BorderFactory.createLineBorder(CARD_BORDER_COLOR, 1),
            BorderFactory.createEmptyBorder(20, 20, 20, 20)
        ));
        chartPanel.setPreferredSize(new Dimension(400, 300));
        
        return chartPanel;
    }

    // ✅ Graph 2: Balance & Transactions Chart (SINGLE COPY)
    private JPanel createBalanceTransactionChart(double balance, int transactions) {
        JPanel chartPanel = new JPanel(new BorderLayout()) {
            @Override
            protected void paintComponent(Graphics g) {
                super.paintComponent(g);
                Graphics2D g2d = (Graphics2D) g;
                g2d.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
                
                int width = getWidth();
                int height = getHeight();
                
                // Chart title
                g2d.setFont(new Font("Segoe UI", Font.BOLD, 16));
                g2d.setColor(PRIMARY_COLOR);
                g2d.drawString("Balance & Activity", 10, 25);
                
                // Draw balance circle
                int centerX = width / 2;
                int centerY = height / 2 - 20;
                int radius = Math.min(width, height) / 3;
                
                // Balance circle
                g2d.setColor(SECONDARY_COLOR);
                g2d.fillOval(centerX - radius, centerY - radius, radius * 2, radius * 2);
                g2d.setColor(SECONDARY_COLOR.darker());
                g2d.drawOval(centerX - radius, centerY - radius, radius * 2, radius * 2);
                
                // Balance text
                g2d.setFont(new Font("Segoe UI", Font.BOLD, 20));
                g2d.setColor(Color.WHITE);
                String balanceText = String.format("$%.2f", balance);
                FontMetrics fm = g2d.getFontMetrics();
                int textWidth = fm.stringWidth(balanceText);
                g2d.drawString(balanceText, centerX - textWidth/2, centerY + 8);
                
                g2d.setFont(new Font("Segoe UI", Font.PLAIN, 12));
                g2d.drawString("Current Balance", centerX - 45, centerY + 30);
                
                // Transaction info
                g2d.setFont(new Font("Segoe UI", Font.BOLD, 14));
                g2d.setColor(TEXT_DARK);
                g2d.drawString("Monthly Transactions", width/2 - 70, centerY + radius + 40);
                
                // Transaction bar
                int barY = centerY + radius + 50;
                int barWidth = 200;
                int barHeight = 20;
                
                // Background bar
                g2d.setColor(new Color(220, 220, 220));
                g2d.fillRect((width - barWidth)/2, barY, barWidth, barHeight);
                
                // Progress bar (max 50 transactions for scaling)
                double progress = Math.min(transactions / 50.0, 1.0);
                int progressWidth = (int)(barWidth * progress);
                
                g2d.setColor(WARNING_COLOR);
                g2d.fillRect((width - barWidth)/2, barY, progressWidth, barHeight);
                
                // Transaction count
                g2d.setFont(new Font("Segoe UI", Font.PLAIN, 12));
                g2d.setColor(TEXT_DARK);
                g2d.drawString(transactions + " transactions", (width - barWidth)/2 + 10, barY + 15);
            }
        };
        
        chartPanel.setBackground(CARD_BACKGROUND);
        chartPanel.setBorder(BorderFactory.createCompoundBorder(
            BorderFactory.createLineBorder(CARD_BORDER_COLOR, 1),
            BorderFactory.createEmptyBorder(20, 20, 20, 20)
        ));
        chartPanel.setPreferredSize(new Dimension(400, 300));
        
        return chartPanel;
    }
    
    // ⬇️ YEH EXTRA METHOD HATA DEIN (DUPLICATE THA)
    // private JPanel createBalanceTransactionChart(double balance, int transactions) { ... }
    
    private JPanel createHistoricalBalanceChart() {
        JPanel chartPanel = new JPanel(new BorderLayout()) {
            @Override
            protected void paintComponent(Graphics g) {
                super.paintComponent(g);
                Graphics2D g2d = (Graphics2D) g;
                g2d.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
                
                // Get last 6 months data
                List<Double> monthlyBalances = getMonthlyBalances(6);
                
                int width = getWidth();
                int height = getHeight();
                
                // Draw line chart
                if (monthlyBalances.size() > 1) {
                    int chartX = 50;
                    int chartY = 60;
                    int chartWidth = width - 80;
                    int chartHeight = height - 120;
                    
                    // Find min and max for scaling
                    double maxBalance = Collections.max(monthlyBalances);
                    double minBalance = Collections.min(monthlyBalances);
                    
                    // Draw line
                    g2d.setColor(SECONDARY_COLOR);
                    g2d.setStroke(new BasicStroke(3));
                    
                    for (int i = 0; i < monthlyBalances.size() - 1; i++) {
                        int x1 = chartX + (i * chartWidth / (monthlyBalances.size() - 1));
                        int y1 = chartY + chartHeight - (int)(((monthlyBalances.get(i) - minBalance) / 
                                (maxBalance - minBalance)) * chartHeight);
                        
                        int x2 = chartX + ((i + 1) * chartWidth / (monthlyBalances.size() - 1));
                        int y2 = chartY + chartHeight - (int)(((monthlyBalances.get(i + 1) - minBalance) / 
                                (maxBalance - minBalance)) * chartHeight);
                        
                        g2d.drawLine(x1, y1, x2, y2);
                        
                        // Draw points
                        g2d.setColor(PRIMARY_COLOR);
                        g2d.fillOval(x1 - 4, y1 - 4, 8, 8);
                    }
                }
            }
        };
        
        return chartPanel;
    }

    private List<Double> getMonthlyBalances(int months) {
        // This is a mock method - you need to implement actual data fetching
        List<Double> balances = new ArrayList<>();
        Calendar cal = Calendar.getInstance();
        
        for (int i = 0; i < months; i++) {
            // Fetch balance for each month from your service
            // For now, using random data
            balances.add(user.getAccount().getBalance() * (0.9 + Math.random() * 0.2));
        }
        
        return balances;
    }
    
    // ✅ YEH BAQI METHODS JAISE PEHLE THI
    
    private JButton createActionButton(String text, Color color) {
        JButton button = new JButton("<html><div style='text-align:center'>" + text + "</div></html>");
        button.setFont(new Font("Segoe UI", Font.BOLD, 14));
        
        // ✅ SET PROPER TEXT COLOR - ALWAYS USE HIGH CONTRAST
        button.setBackground(color);
        
        // Determine if background is dark or light
        double brightness = (color.getRed() * 0.299 + 
                           color.getGreen() * 0.587 + 
                           color.getBlue() * 0.114);
        
        if (brightness > 150) { // Light background
            button.setForeground(Color.BLACK); // Use black text
        } else { // Dark background
            button.setForeground(Color.WHITE); // Use white text
        }
        
        // Rest of your code remains the same...
        button.setBorder(BorderFactory.createCompoundBorder(
            BorderFactory.createLineBorder(color.darker(), 2),
            BorderFactory.createEmptyBorder(12, 20, 12, 20)
        ));
        
        button.setFocusPainted(false);
        button.setCursor(new Cursor(Cursor.HAND_CURSOR));
        
        // Hover effect
        button.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                button.setBackground(color.brighter());
            }
            public void mouseExited(java.awt.event.MouseEvent evt) {
                button.setBackground(color);
            }
        });
        
        button.addActionListener(e -> handleQuickAction(text));
        
        return button;
    }
    
    private JPanel createAccountsPanel() {
        JPanel panel = new JPanel(new BorderLayout());
        panel.setBackground(BACKGROUND_COLOR);
        panel.setBorder(BorderFactory.createEmptyBorder(30, 30, 30, 30));
        
        JLabel title = new JLabel("Account Details");
        title.setFont(new Font("Segoe UI", Font.BOLD, 24));
        title.setForeground(PRIMARY_COLOR);
        title.setBorder(BorderFactory.createEmptyBorder(0, 0, 20, 0));
        
        // Account details card
        JPanel accountCard = new JPanel(new BorderLayout());
        accountCard.setBackground(CARD_BACKGROUND);
        accountCard.setBorder(BorderFactory.createCompoundBorder(
            BorderFactory.createLineBorder(new Color(230, 230, 230)),
            BorderFactory.createEmptyBorder(20, 20, 20, 20)
        ));
        
        JLabel accountTitle = new JLabel("💰 PRIMARY ACCOUNT");
        accountTitle.setFont(new Font("Segoe UI", Font.BOLD, 16));
        accountTitle.setForeground(PRIMARY_COLOR);
        accountTitle.setBorder(BorderFactory.createEmptyBorder(0, 0, 15, 0));
        
        JPanel detailsPanel = new JPanel(new GridLayout(4, 1, 10, 10));
        detailsPanel.setBackground(CARD_BACKGROUND);
        
        detailsPanel.add(createDetailRow("Account Number:", String.valueOf(user.getAccountNo())));
        detailsPanel.add(createDetailRow("Account Type:", user.getAccount() instanceof model.SavingsAccount ? "Savings Account" : "Current Account"));
        detailsPanel.add(createDetailRow("Account Holder:", user.getName()));
        detailsPanel.add(createDetailRow("Status:", "● Active", SUCCESS_COLOR));
        
        // View Full Details button
        JButton detailsBtn = new JButton("View Full Details");
        detailsBtn.setFont(new Font("Segoe UI", Font.BOLD, 12));
        detailsBtn.setBackground(PRIMARY_COLOR);
        detailsBtn.setForeground(BUTTON_TEXT_LIGHT);
        detailsBtn.setBorder(BorderFactory.createCompoundBorder(
            BorderFactory.createLineBorder(PRIMARY_COLOR.darker()),
            BorderFactory.createEmptyBorder(10, 25, 10, 25)
        ));
        detailsBtn.setFocusPainted(false);
        detailsBtn.setCursor(new Cursor(Cursor.HAND_CURSOR));
        
        detailsBtn.addActionListener(e -> {
            JOptionPane.showMessageDialog(this,
                "📋 ACCOUNT DETAILS\n\n" +
                "Account Number: " + user.getAccountNo() + "\n" +
                "Account Type: " + (user.getAccount() instanceof model.SavingsAccount ? "Savings Account" : "Current Account") + "\n" +
                "Balance: $" + String.format("%.2f", user.getAccount().getBalance()) + "\n" +
                "Interest Rate: " + (user.getAccount() instanceof model.SavingsAccount ? "5.0% per annum" : "0%") + "\n" +
                "Account Holder: " + user.getName() + "\n" +
                "Status: Active\n" +
                "Since: " + new SimpleDateFormat("dd-MMM-yyyy").format(new Date()),
                "Account Information",
                JOptionPane.INFORMATION_MESSAGE);
        });
        
        JPanel buttonPanel = new JPanel(new FlowLayout(FlowLayout.RIGHT));
        buttonPanel.setBackground(CARD_BACKGROUND);
        buttonPanel.add(detailsBtn);
        
        accountCard.add(accountTitle, BorderLayout.NORTH);
        accountCard.add(detailsPanel, BorderLayout.CENTER);
        accountCard.add(buttonPanel, BorderLayout.SOUTH);
        
        panel.add(title, BorderLayout.NORTH);
        panel.add(accountCard, BorderLayout.CENTER);
        
        return panel;
    }
    
    private JPanel createDetailRow(String label, String value) {
        return createDetailRow(label, value, TEXT_DARK);
    }
    
    private JPanel createDetailRow(String label, String value, Color valueColor) {
        JPanel row = new JPanel(new BorderLayout());
        row.setBackground(CARD_BACKGROUND);
        
        JLabel labelLbl = new JLabel(label);
        labelLbl.setFont(new Font("Segoe UI", Font.PLAIN, 14));
        labelLbl.setForeground(TEXT_MEDIUM);
        
        JLabel valueLbl = new JLabel(value);
        valueLbl.setFont(new Font("Segoe UI", Font.BOLD, 14));
        valueLbl.setForeground(valueColor);
        valueLbl.setHorizontalAlignment(SwingConstants.RIGHT);
        
        row.add(labelLbl, BorderLayout.WEST);
        row.add(valueLbl, BorderLayout.EAST);
        
        return row;
    }
    
    private JPanel createTransactionsPanel() {
        JPanel panel = new JPanel(new BorderLayout());
        panel.setBackground(BACKGROUND_COLOR);
        panel.setBorder(BorderFactory.createEmptyBorder(30, 30, 30, 30));
        
        JLabel title = new JLabel("Recent Transactions");
        title.setFont(new Font("Segoe UI", Font.BOLD, 24));
        title.setForeground(PRIMARY_COLOR);
        title.setBorder(BorderFactory.createEmptyBorder(0, 0, 20, 0));
        
        // Create table with data
        String[] columns = {"Date", "Description", "Amount", "Status"};
        Object[][] data = {
            {"Jan 04, 2025", "Monthly Deposit", "$1,200.00", "Completed"},
            {"Jan 03, 2025", "Grocery Store", "-$85.50", "Completed"},
            {"Jan 02, 2025", "Online Payment", "-$45.99", "Pending"}
        };

        JTable transactionTable = new JTable(data, columns);
        transactionTable.setFont(new Font("Segoe UI", Font.PLAIN, 13));
        transactionTable.setRowHeight(35);
        transactionTable.setGridColor(new Color(230, 230, 230));
        
        // Customize table header
        JTableHeader header = transactionTable.getTableHeader();
        header.setFont(new Font("Segoe UI", Font.BOLD, 14));
        header.setBackground(new Color(240, 242, 245));
        header.setForeground(TEXT_DARK);
        
        // Custom renderer for amount column
        transactionTable.getColumnModel().getColumn(2).setCellRenderer(new DefaultTableCellRenderer() {
            @Override
            public Component getTableCellRendererComponent(JTable table, Object value,
                    boolean isSelected, boolean hasFocus, int row, int column) {
                Component c = super.getTableCellRendererComponent(table, value, isSelected, hasFocus, row, column);
                c.setBackground(CARD_BACKGROUND);
                
                if (value != null) {
                    String amount = value.toString();
                    if (amount.startsWith("$") && !amount.contains("-")) {
                        c.setForeground(SUCCESS_COLOR);
                        c.setFont(c.getFont().deriveFont(Font.BOLD));
                    } else if (amount.contains("-")) {
                        c.setForeground(DANGER_COLOR);
                        c.setFont(c.getFont().deriveFont(Font.BOLD));
                    } else {
                        c.setForeground(TEXT_DARK);
                    }
                }
                
                return c;
            }
        });
        
        JScrollPane scrollPane = new JScrollPane(transactionTable);
        scrollPane.setBorder(BorderFactory.createLineBorder(new Color(230, 230, 230)));
        scrollPane.getViewport().setBackground(CARD_BACKGROUND);
        
        // View all button
        JButton viewAllBtn = new JButton("View All Transactions");
        viewAllBtn.setFont(new Font("Segoe UI", Font.BOLD, 12));
        viewAllBtn.setBackground(PRIMARY_COLOR);
        viewAllBtn.setForeground(BUTTON_TEXT_LIGHT);
        viewAllBtn.setBorder(BorderFactory.createCompoundBorder(
            BorderFactory.createLineBorder(PRIMARY_COLOR.darker()),
            BorderFactory.createEmptyBorder(10, 25, 10, 25)
        ));
        viewAllBtn.setFocusPainted(false);
        viewAllBtn.setCursor(new Cursor(Cursor.HAND_CURSOR));
        
        viewAllBtn.addActionListener(e -> {
            // Assuming TransactionHistoryFrame exists
            new TransactionHistoryFrame(user.getAccountNo()).setVisible(true);
        });
        
        JPanel buttonPanel = new JPanel(new FlowLayout(FlowLayout.RIGHT));
        buttonPanel.setBackground(BACKGROUND_COLOR);
        buttonPanel.add(viewAllBtn);
        
        panel.add(title, BorderLayout.NORTH);
        panel.add(scrollPane, BorderLayout.CENTER);
        panel.add(buttonPanel, BorderLayout.SOUTH);
        
        return panel;
    }
    
    private JPanel createStatementsPanel() {
        JPanel panel = new JPanel(new BorderLayout());
        panel.setBackground(BACKGROUND_COLOR);
        panel.setBorder(BorderFactory.createEmptyBorder(30, 30, 30, 30));
        
        JLabel title = new JLabel("Account Statements");
        title.setFont(new Font("Segoe UI", Font.BOLD, 24));
        title.setForeground(PRIMARY_COLOR);
        title.setBorder(BorderFactory.createEmptyBorder(0, 0, 20, 0));
        
        JPanel contentPanel = new JPanel(new GridLayout(3, 1, 20, 20));
        contentPanel.setBackground(BACKGROUND_COLOR);
        
        // Last 3 months statements
        Calendar cal = Calendar.getInstance();
        String[] monthNames = {"January", "February", "March", "April", "May", "June",
                              "July", "August", "September", "October", "November", "December"};
        
        for (int i = 0; i < 3; i++) {
            int month = cal.get(Calendar.MONTH) + 1 - i;
            int year = cal.get(Calendar.YEAR);
            
            if (month <= 0) {
                month += 12;
                year -= 1;
            }
            
            JPanel statementCard = createStatementCard(year, month, monthNames[month-1]);
            contentPanel.add(statementCard);
        }
        
        // Download all button
        JButton downloadAllBtn = new JButton("📥 Download All Statements");
        downloadAllBtn.setFont(new Font("Segoe UI", Font.BOLD, 12));
        downloadAllBtn.setBackground(PRIMARY_COLOR);
        downloadAllBtn.setForeground(BUTTON_TEXT_LIGHT);
        downloadAllBtn.setBorder(BorderFactory.createCompoundBorder(
            BorderFactory.createLineBorder(PRIMARY_COLOR.darker()),
            BorderFactory.createEmptyBorder(10, 25, 10, 25)
        ));
        downloadAllBtn.setFocusPainted(false);
        downloadAllBtn.setCursor(new Cursor(Cursor.HAND_CURSOR));
        
        downloadAllBtn.addActionListener(e -> {
            JOptionPane.showMessageDialog(this,
                "All statements have been prepared for download.",
                "Download Started",
                JOptionPane.INFORMATION_MESSAGE);
        });
        
        JPanel buttonPanel = new JPanel(new FlowLayout(FlowLayout.RIGHT));
        buttonPanel.setBackground(BACKGROUND_COLOR);
        buttonPanel.add(downloadAllBtn);
        
        panel.add(title, BorderLayout.NORTH);
        panel.add(contentPanel, BorderLayout.CENTER);
        panel.add(buttonPanel, BorderLayout.SOUTH);
        
        return panel;
    }
    
    private JPanel createStatementCard(int year, int month, String monthName) {
        JPanel card = new JPanel(new BorderLayout());
        card.setBackground(CARD_BACKGROUND);
        card.setBorder(BorderFactory.createCompoundBorder(
            BorderFactory.createLineBorder(new Color(230, 230, 230)),
            BorderFactory.createEmptyBorder(15, 15, 15, 15)
        ));
        
        JLabel periodLabel = new JLabel("📄 " + monthName + " " + year);
        periodLabel.setFont(new Font("Segoe UI", Font.BOLD, 14));
        periodLabel.setForeground(PRIMARY_COLOR);
        
        // Get statement data
        Map<String, Object> data = StatementService.getMonthlySummary(user.getAccountNo(), year, month);
        double balance = (double) data.get("CLOSING_BALANCE");
        int transactions = (int) data.get("TRANSACTION_COUNT");
        
        JLabel detailsLabel = new JLabel("<html>" +
            "Closing Balance: <b style='color:" + rgbToHex(SECONDARY_COLOR) + "'>$" + String.format("%.2f", balance) + "</b><br>" +
            "Transactions: <b>" + transactions + "</b>" +
            "</html>");
        detailsLabel.setFont(new Font("Segoe UI", Font.PLAIN, 12));
        detailsLabel.setForeground(TEXT_MEDIUM);
        
        // View Statement button
        JButton viewBtn = new JButton("View Statement");
        viewBtn.setFont(new Font("Segoe UI", Font.BOLD, 11));
        viewBtn.setBackground(SECONDARY_COLOR);
        viewBtn.setForeground(Color.BLACK);
        viewBtn.setBorder(BorderFactory.createCompoundBorder(
            BorderFactory.createLineBorder(SECONDARY_COLOR.darker()),
            BorderFactory.createEmptyBorder(5, 15, 5, 15)
        ));
        viewBtn.setFocusPainted(false);
        viewBtn.setCursor(new Cursor(Cursor.HAND_CURSOR));
        
        viewBtn.addActionListener(e -> {
            // Assuming SimpleStatementFrame exists
            new SimpleStatementFrame(user.getAccountNo(), user.getName()).setVisible(true);
        });
        
        JPanel buttonPanel = new JPanel(new FlowLayout(FlowLayout.RIGHT));
        buttonPanel.setBackground(CARD_BACKGROUND);
        buttonPanel.add(viewBtn);
        
        card.add(periodLabel, BorderLayout.NORTH);
        card.add(detailsLabel, BorderLayout.CENTER);
        card.add(buttonPanel, BorderLayout.SOUTH);
        
        return card;
    }
    
    private String rgbToHex(Color color) {
        return String.format("#%02x%02x%02x", color.getRed(), color.getGreen(), color.getBlue());
    }
    
    private JPanel createTransferPanel() {
        JPanel panel = new JPanel(new BorderLayout());
        panel.setBackground(BACKGROUND_COLOR);
        panel.setBorder(BorderFactory.createEmptyBorder(30, 30, 30, 30));
        
        JLabel title = new JLabel("Transfer Funds");
        title.setFont(new Font("Segoe UI", Font.BOLD, 24));
        title.setForeground(PRIMARY_COLOR);
        title.setBorder(BorderFactory.createEmptyBorder(0, 0, 20, 0));
        
        // Transfer form card
        JPanel formCard = new JPanel(new BorderLayout());
        formCard.setBackground(CARD_BACKGROUND);
        formCard.setBorder(BorderFactory.createCompoundBorder(
            BorderFactory.createLineBorder(new Color(230, 230, 230)),
            BorderFactory.createEmptyBorder(30, 30, 30, 30)
        ));
        
        JPanel formPanel = new JPanel(new GridBagLayout());
        formPanel.setBackground(CARD_BACKGROUND);
        
        GridBagConstraints gbc = new GridBagConstraints();
        gbc.fill = GridBagConstraints.HORIZONTAL;
        gbc.insets = new Insets(15, 15, 15, 15);
        
        // Beneficiary Account
        gbc.gridx = 0; gbc.gridy = 0;
        gbc.anchor = GridBagConstraints.WEST;
        JLabel accLabel = new JLabel("Beneficiary Account Number:");
        accLabel.setFont(new Font("Segoe UI", Font.BOLD, 14));
        accLabel.setForeground(TEXT_MEDIUM);
        
        formPanel.add(accLabel, gbc);
        
        gbc.gridx = 1;
        JTextField accountField = new JTextField();
        accountField.setPreferredSize(new Dimension(300, 40));
        accountField.setFont(new Font("Segoe UI", Font.PLAIN, 14));
        accountField.setBorder(BorderFactory.createCompoundBorder(
            BorderFactory.createLineBorder(new Color(200, 200, 200)),
            BorderFactory.createEmptyBorder(10, 10, 10, 10)
        ));
        formPanel.add(accountField, gbc);
        
        // Amount
        gbc.gridx = 0; gbc.gridy = 1;
        JLabel amtLabel = new JLabel("Amount ($):");
        amtLabel.setFont(new Font("Segoe UI", Font.BOLD, 14));
        amtLabel.setForeground(TEXT_MEDIUM);
        formPanel.add(amtLabel, gbc);
        
        gbc.gridx = 1;
        JTextField amountField = new JTextField();
        amountField.setPreferredSize(new Dimension(300, 40));
        amountField.setFont(new Font("Segoe UI", Font.PLAIN, 14));
        amountField.setBorder(BorderFactory.createCompoundBorder(
            BorderFactory.createLineBorder(new Color(200, 200, 200)),
            BorderFactory.createEmptyBorder(10, 10, 10, 10)
        ));
        formPanel.add(amountField, gbc);
        
        // Description
        gbc.gridx = 0; gbc.gridy = 2;
        JLabel descLabel = new JLabel("Description (Optional):");
        descLabel.setFont(new Font("Segoe UI", Font.BOLD, 14));
        descLabel.setForeground(TEXT_MEDIUM);
        formPanel.add(descLabel, gbc);
        
        gbc.gridx = 1;
        JTextField descField = new JTextField();
        descField.setPreferredSize(new Dimension(300, 40));
        descField.setFont(new Font("Segoe UI", Font.PLAIN, 14));
        descField.setBorder(BorderFactory.createCompoundBorder(
            BorderFactory.createLineBorder(new Color(200, 200, 200)),
            BorderFactory.createEmptyBorder(10, 10, 10, 10)
        ));
        formPanel.add(descField, gbc);
        
        // Transfer button
        gbc.gridx = 0; gbc.gridy = 3;
        gbc.gridwidth = 2;
        gbc.anchor = GridBagConstraints.CENTER;
        
        JButton transferBtn = new JButton("🚀 Transfer Now");
        transferBtn.setFont(new Font("Segoe UI", Font.BOLD, 16));
        transferBtn.setBackground(SUCCESS_COLOR);
        transferBtn.setForeground(BUTTON_TEXT_LIGHT);
        
        transferBtn.setBorder(BorderFactory.createCompoundBorder(
            BorderFactory.createLineBorder(SUCCESS_COLOR.darker()),
            BorderFactory.createEmptyBorder(15, 50, 15, 50)
        ));
        transferBtn.setFocusPainted(false);
        transferBtn.setCursor(new Cursor(Cursor.HAND_CURSOR));
        
        transferBtn.addActionListener(e -> {
            // Assuming TransferFrame exists
            new TransferFrame(user, this).setVisible(true);
        });
        
        formPanel.add(transferBtn, gbc);
        
        formCard.add(formPanel, BorderLayout.CENTER);
        
        panel.add(title, BorderLayout.NORTH);
        panel.add(formCard, BorderLayout.CENTER);
        
        return panel;
    }
    
    private void handleQuickAction(String action) {
        switch (action) {
            case "💰 Deposit":
                // Assuming DepositFrame exists
                new DepositFrame(user, this).setVisible(true);
                break;
            case "💸 Withdraw":
                // Assuming WithdrawFrame exists
                new WithdrawFrame(user, this).setVisible(true);
                break;
            case "🔄 Transfer":
                // Assuming TransferFrame exists
                new TransferFrame(user, this).setVisible(true);
                break;
            case "📄 Statement":
                // Assuming SimpleStatementFrame exists
                new SimpleStatementFrame(user.getAccountNo(), user.getName()).setVisible(true);
                break;
            case "🏦 Loan":
                // Assuming LoanFrame exists
                new LoanFrame(user, this).setVisible(true);
                break;
            case "ℹ️ Support":
                JOptionPane.showMessageDialog(this, 
                    "For support, please contact:\n\n" +
                    "📞 Phone: 1-800-NEXUS-BANK\n" +
                    "📧 Email: support@nexusbank.com\n" +
                    "🕒 Hours: 24/7",
                    "Customer Support",
                    JOptionPane.INFORMATION_MESSAGE);
                break;
        }
    }
    
    public void refreshData() {
        // Update balance
        double balance = user.getAccount().getBalance();
        balanceLabel.setText(String.format("$%.2f", balance));
        
        // Update time in account info
        SimpleDateFormat sdf = new SimpleDateFormat("MMM dd, yyyy | hh:mm a");
        accountInfoLabel.setText("Account #" + user.getAccountNo() + " | " + sdf.format(new Date()));
    }
    
    private void logout() {
        int confirm = JOptionPane.showConfirmDialog(this,
            "Are you sure you want to logout?",
            "Confirm Logout",
            JOptionPane.YES_NO_OPTION,
            JOptionPane.QUESTION_MESSAGE);
        
        if (confirm == JOptionPane.YES_OPTION) {
            dispose();
            // Assuming LoginFrame exists
            new LoginFrame().setVisible(true);
        }
    }
}