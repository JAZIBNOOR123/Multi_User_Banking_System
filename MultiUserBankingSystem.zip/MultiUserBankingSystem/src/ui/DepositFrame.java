package ui;

import javax.swing.*;
import javax.swing.border.*;
import java.awt.*;
import java.awt.event.*;
import model.User;
import thread.DepositThread;

public class DepositFrame extends JFrame {
    
    private User user;
    private DashboardFrame dashboard;
    
    public DepositFrame(User user, DashboardFrame dashboard) {
        this.user = user;
        this.dashboard = dashboard;
        
        setTitle("Deposit Money - Nexus Bank");
        setSize(450, 520);
        setLocationRelativeTo(null);
        setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        setResizable(false);
        
        initUI();
    }
    
    private void initUI() {
        // Main panel with gradient
        JPanel mainPanel = new JPanel(new BorderLayout()) {
            @Override
            protected void paintComponent(Graphics g) {
                super.paintComponent(g);
                Graphics2D g2d = (Graphics2D) g;
                GradientPaint gradient = new GradientPaint(
                    0, 0, new Color(240, 248, 255),
                    0, getHeight(), new Color(220, 240, 255)
                );
                g2d.setPaint(gradient);
                g2d.fillRect(0, 0, getWidth(), getHeight());
            }
        };
        mainPanel.setBorder(BorderFactory.createEmptyBorder(20, 20, 20, 20));
        
        // Use GridBagLayout for better control
        JPanel formPanel = new JPanel();
        formPanel.setLayout(new GridBagLayout());
        formPanel.setOpaque(false);
        
        GridBagConstraints gbc = new GridBagConstraints();
        gbc.fill = GridBagConstraints.HORIZONTAL;
        gbc.insets = new Insets(10, 10, 10, 10);
        
        // Header
        JLabel titleLabel = new JLabel("💰 Deposit Money");
        titleLabel.setFont(new Font("Segoe UI", Font.BOLD, 24));
        titleLabel.setForeground(new Color(0, 100, 200));
        titleLabel.setHorizontalAlignment(SwingConstants.CENTER);
        gbc.gridx = 0;
        gbc.gridy = 0;
        gbc.gridwidth = 2;
        gbc.insets = new Insets(0, 0, 20, 0);
        formPanel.add(titleLabel, gbc);
        
        // Current balance info
        JPanel balancePanel = new JPanel(new BorderLayout());
        balancePanel.setBackground(new Color(230, 245, 255));
        balancePanel.setBorder(BorderFactory.createCompoundBorder(
            BorderFactory.createLineBorder(new Color(180, 220, 255), 1),
            BorderFactory.createEmptyBorder(15, 20, 15, 20)
        ));
        
        JLabel currentLabel = new JLabel("Current Balance:");
        currentLabel.setFont(new Font("Segoe UI", Font.BOLD, 12));
        currentLabel.setForeground(new Color(80, 80, 80));
        
        JLabel balanceLabel = new JLabel(String.format("$%.2f", user.getAccount().getBalance()));
        balanceLabel.setFont(new Font("Segoe UI", Font.BOLD, 20));
        balanceLabel.setForeground(new Color(0, 150, 0));
        balanceLabel.setHorizontalAlignment(SwingConstants.RIGHT);
        
        balancePanel.add(currentLabel, BorderLayout.WEST);
        balancePanel.add(balanceLabel, BorderLayout.EAST);
        
        gbc.gridx = 0;
        gbc.gridy = 1;
        gbc.gridwidth = 2;
        gbc.insets = new Insets(0, 0, 20, 0);
        formPanel.add(balancePanel, gbc);
        
        // Amount input
        JLabel amountLabel = new JLabel("Deposit Amount ($):");
        amountLabel.setFont(new Font("Segoe UI", Font.BOLD, 14));
        amountLabel.setForeground(new Color(60, 60, 60));
        gbc.gridx = 0;
        gbc.gridy = 2;
        gbc.gridwidth = 2;
        gbc.insets = new Insets(0, 0, 5, 0);
        formPanel.add(amountLabel, gbc);
        
        JTextField amountField = new JTextField();
        amountField.setFont(new Font("Segoe UI", Font.PLAIN, 18));
        amountField.setBorder(BorderFactory.createCompoundBorder(
            BorderFactory.createLineBorder(new Color(180, 180, 180), 1),
            BorderFactory.createEmptyBorder(15, 15, 15, 15)
        ));
        amountField.setHorizontalAlignment(JTextField.CENTER);
        gbc.gridx = 0;
        gbc.gridy = 3;
        gbc.gridwidth = 2;
        gbc.insets = new Insets(0, 0, 20, 0);
        formPanel.add(amountField, gbc);
        
        // Quick amount buttons title
        JLabel quickLabel = new JLabel("Quick Amounts:");
        quickLabel.setFont(new Font("Segoe UI", Font.BOLD, 12));
        quickLabel.setForeground(new Color(60, 60, 60));
        gbc.gridx = 0;
        gbc.gridy = 4;
        gbc.gridwidth = 2;
        gbc.insets = new Insets(0, 0, 10, 0);
        formPanel.add(quickLabel, gbc);
        
        // Quick amount buttons - using GridLayout in a panel
        JPanel quickPanel = new JPanel(new GridLayout(2, 4, 8, 8));
        quickPanel.setBackground(new Color(240, 248, 255));
        quickPanel.setBorder(BorderFactory.createEmptyBorder(5, 0, 5, 0));
        
        double[] amounts = {50, 100, 200, 500, 1000, 2000, 5000, 10000};
        for (double amt : amounts) {
            JButton quickBtn = new JButton(String.format("$%.0f", amt));
            quickBtn.setFont(new Font("Segoe UI", Font.BOLD, 12));
            quickBtn.setBackground(new Color(240, 240, 240));
            quickBtn.setForeground(new Color(0, 100, 200));
            quickBtn.setBorder(BorderFactory.createCompoundBorder(
                BorderFactory.createLineBorder(new Color(180, 200, 220), 1),
                BorderFactory.createEmptyBorder(8, 0, 8, 0)
            ));
            quickBtn.setFocusPainted(false);
            quickBtn.setCursor(new Cursor(Cursor.HAND_CURSOR));
            
            // Hover effect for quick buttons
            quickBtn.addMouseListener(new MouseAdapter() {
                @Override
                public void mouseEntered(MouseEvent e) {
                    quickBtn.setBackground(new Color(210, 230, 240));
                }
                
                @Override
                public void mouseExited(MouseEvent e) {
                    quickBtn.setBackground(new Color(240, 240, 240));
                }
            });
            
            quickBtn.addActionListener(e -> amountField.setText(String.valueOf(amt)));
            quickPanel.add(quickBtn);
        }
        
        gbc.gridx = 0;
        gbc.gridy = 5;
        gbc.gridwidth = 2;
        gbc.insets = new Insets(0, 0, 20, 0);
        formPanel.add(quickPanel, gbc);
        
        // Deposit button
        JButton depositBtn = new JButton("💵 Confirm Deposit");
        depositBtn.setFont(new Font("Segoe UI", Font.BOLD, 16));
        depositBtn.setBackground(new Color(60, 179, 113)); // Green
        depositBtn.setForeground(Color.BLACK);
        depositBtn.setFocusPainted(false);
        depositBtn.setBorder(BorderFactory.createCompoundBorder(
            BorderFactory.createLineBorder(new Color(40, 159, 93), 2),
            BorderFactory.createEmptyBorder(15, 0, 15, 0)
        ));
        depositBtn.setCursor(new Cursor(Cursor.HAND_CURSOR));
        
        // Make button full width
        gbc.gridx = 0;
        gbc.gridy = 6;
        gbc.gridwidth = 2;
        gbc.insets = new Insets(10, 0, 0, 0);
        formPanel.add(depositBtn, gbc);
        
        // Hover effect
        depositBtn.addMouseListener(new MouseAdapter() {
            @Override
            public void mouseEntered(MouseEvent e) {
                depositBtn.setBackground(new Color(50, 169, 103));
            }
            
            @Override
            public void mouseExited(MouseEvent e) {
                depositBtn.setBackground(new Color(60, 179, 113));
            }
        });
        
        // Deposit action
        depositBtn.addActionListener(e -> {
            try {
                String amountText = amountField.getText().trim();
                
                if (amountText.isEmpty()) {
                    showError("Please enter amount");
                    return;
                }

                double amount = Double.parseDouble(amountText);
                
                if (amount <= 0) {
                    showError("Please enter positive amount");
                    return;
                }
                
                if (amount > 10000) {
                    showError("Maximum deposit limit is $10,000");
                    return;
                }

                // Create and start deposit thread
                Thread depositThread = new DepositThread(user.getAccount(), amount);
                depositThread.start();
                depositThread.join(); // Wait for thread to complete

                // ✅ REFRESH DASHBOARD DATA
                dashboard.refreshData();

                showSuccess(String.format("Successfully deposited $%.2f", amount));
                dispose(); // Close window

            } catch (NumberFormatException ex) {
                showError("Please enter valid amount");
            } catch (InterruptedException ex) {
                showError("Transaction was interrupted");
            } catch (Exception ex) {
                showError("Error: " + ex.getMessage());
            }
        });
        
        mainPanel.add(formPanel, BorderLayout.CENTER);
        add(mainPanel);
        
        // Set focus to amount field
        amountField.requestFocus();
        
        // Add keyboard shortcut (Enter key to deposit)
        amountField.addKeyListener(new KeyAdapter() {
            @Override
            public void keyPressed(KeyEvent e) {
                if (e.getKeyCode() == KeyEvent.VK_ENTER) {
                    depositBtn.doClick();
                }
            }
        });
    }
    
    private void showError(String message) {
        JOptionPane.showMessageDialog(this, 
            "❌ " + message,
            "Deposit Failed",
            JOptionPane.ERROR_MESSAGE);
    }
    
    private void showSuccess(String message) {
        JOptionPane.showMessageDialog(this, 
            "✅ " + message,
            "Deposit Complete",
            JOptionPane.INFORMATION_MESSAGE);
    }
}