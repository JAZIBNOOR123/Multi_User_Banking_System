package ui;

import javax.swing.*;
import javax.swing.table.*;
import java.awt.*;
import java.text.SimpleDateFormat;
import java.util.List;
import service.TransactionService;

public class TransactionHistoryFrame extends JFrame {
    
    private int accountNo;
    private JTable transactionTable;
    private DefaultTableModel tableModel;
    private SimpleDateFormat sdf = new SimpleDateFormat("dd-MM-yyyy HH:mm:ss");
    
    public TransactionHistoryFrame(int accountNo) {
        this.accountNo = accountNo;
        
        setTitle("Transaction History - Account: " + accountNo);
        setSize(700, 500);
        setLocationRelativeTo(null);
        setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        
        initUI();
        loadTransactions();
    }
    
    private void initUI() {
        setLayout(new BorderLayout());
        
        // ========== HEADER ==========
        JLabel headerLabel = new JLabel("Transaction History for Account: " + accountNo);
        headerLabel.setFont(new Font("Arial", Font.BOLD, 16));
        headerLabel.setHorizontalAlignment(SwingConstants.CENTER);
        headerLabel.setBorder(BorderFactory.createEmptyBorder(10, 0, 10, 0));
        
        // ========== SIMPLE FILTERS ==========
        JPanel filterPanel = new JPanel(new FlowLayout(FlowLayout.LEFT));
        filterPanel.setBorder(BorderFactory.createTitledBorder("Quick Filter"));
        
        JLabel typeLabel = new JLabel("Filter by Type:");
        String[] types = {"All", "DEPOSIT", "WITHDRAW"};
        JComboBox<String> typeCombo = new JComboBox<>(types);
        JButton filterBtn = new JButton("Apply");
        
        filterPanel.add(typeLabel);
        filterPanel.add(typeCombo);
        filterPanel.add(filterBtn);
        
        // ========== TABLE ==========
        String[] columns = {"Transaction ID", "Date & Time", "Type", "Amount", "Description"};
        tableModel = new DefaultTableModel(columns, 0) {
            @Override
            public boolean isCellEditable(int row, int column) {
                return false;
            }
        };
        
        transactionTable = new JTable(tableModel);
        transactionTable.setRowHeight(30);
        transactionTable.setFont(new Font("Arial", Font.PLAIN, 12));
        
        // Column widths
        transactionTable.getColumnModel().getColumn(0).setPreferredWidth(120);
        transactionTable.getColumnModel().getColumn(1).setPreferredWidth(150);
        transactionTable.getColumnModel().getColumn(2).setPreferredWidth(80);
        transactionTable.getColumnModel().getColumn(3).setPreferredWidth(100);
        transactionTable.getColumnModel().getColumn(4).setPreferredWidth(250);
        
        // Color coding
        transactionTable.setDefaultRenderer(Object.class, new DefaultTableCellRenderer() {
            @Override
            public Component getTableCellRendererComponent(JTable table, Object value,
                    boolean isSelected, boolean hasFocus, int row, int column) {
                Component c = super.getTableCellRendererComponent(table, value, 
                        isSelected, hasFocus, row, column);
                
                // Color amount column (column 3)
                if (column == 3 && value != null) {
                    String amountStr = value.toString();
                    if (!amountStr.startsWith("-")) {
                        c.setForeground(new Color(0, 150, 0)); // Green for positive/deposit
                        c.setFont(c.getFont().deriveFont(Font.BOLD));
                    } else {
                        c.setForeground(Color.RED); // Red for negative/withdrawal
                        c.setFont(c.getFont().deriveFont(Font.BOLD));
                    }
                }
                
                // Color type column (column 2)
                if (column == 2 && value != null) {
                    String type = value.toString();
                    if (type.contains("DEPOSIT")) {
                        c.setForeground(new Color(0, 100, 0));
                    } else if (type.contains("WITHDRAW")) {
                        c.setForeground(new Color(200, 0, 0));
                    }
                }
                
                return c;
            }
        });
        
        JScrollPane scrollPane = new JScrollPane(transactionTable);
        
        // ========== BOTTOM PANEL ==========
        JPanel bottomPanel = new JPanel(new BorderLayout());
        
        // Summary
        JPanel summaryPanel = new JPanel(new FlowLayout(FlowLayout.LEFT));
        JLabel totalLabel = new JLabel("Total Transactions: 0");
        JLabel netLabel = new JLabel("Net Amount: $0.00");
        
        summaryPanel.add(totalLabel);
        summaryPanel.add(Box.createHorizontalStrut(20));
        summaryPanel.add(netLabel);
        
        // Buttons
        JPanel buttonPanel = new JPanel(new FlowLayout(FlowLayout.RIGHT));
        JButton refreshBtn = new JButton("🔄 Refresh");
        JButton closeBtn = new JButton("Close");
        
        buttonPanel.add(refreshBtn);
        buttonPanel.add(closeBtn);
        
        bottomPanel.add(summaryPanel, BorderLayout.WEST);
        bottomPanel.add(buttonPanel, BorderLayout.EAST);
        
        // ========== ASSEMBLE ==========
        add(headerLabel, BorderLayout.NORTH);
        add(filterPanel, BorderLayout.CENTER); // Temporarily replace with filter
        add(scrollPane, BorderLayout.CENTER);
        add(bottomPanel, BorderLayout.SOUTH);
        
        // ========== EVENT HANDLERS ==========
        filterBtn.addActionListener(e -> {
            String selectedType = (String) typeCombo.getSelectedItem();
            if (selectedType.equals("All")) {
                loadTransactions();
            } else {
                filterByType(selectedType);
            }
        });
        
        refreshBtn.addActionListener(e -> loadTransactions());
        
        closeBtn.addActionListener(e -> dispose());
    }
    
    private void loadTransactions() {
        // Clear table
        tableModel.setRowCount(0);
        
        try {
            // Get transactions from TransactionService
            List<String[]> transactions = TransactionService.getTransactionsForAccount(accountNo);
            
            if (transactions == null || transactions.isEmpty()) {
                // Add sample data for testing
                addSampleData();
                transactions = TransactionService.getTransactionsForAccount(accountNo);
            }
            
            // Add to table
            for (String[] txn : transactions) {
                tableModel.addRow(txn);
            }
            
            // Update summary
            updateSummary(transactions);
            
        } catch (Exception e) {
            JOptionPane.showMessageDialog(this,
                "Error loading transactions: " + e.getMessage(),
                "Error",
                JOptionPane.ERROR_MESSAGE);
            e.printStackTrace();
        }
    }
    
    private void filterByType(String type) {
        // Clear table
        tableModel.setRowCount(0);
        
        try {
            // Get all transactions
            List<String[]> allTransactions = TransactionService.getTransactionsForAccount(accountNo);
            
            if (allTransactions == null) return;
            
            // Filter by type
            int count = 0;
            for (String[] txn : allTransactions) {
                if (txn.length > 2 && txn[2].equalsIgnoreCase(type)) {
                    tableModel.addRow(txn);
                    count++;
                }
            }
            
            // Update summary with filtered results
            updateSummaryForFiltered(type, count);
            
        } catch (Exception e) {
            JOptionPane.showMessageDialog(this,
                "Error filtering transactions: " + e.getMessage(),
                "Error",
                JOptionPane.ERROR_MESSAGE);
        }
    }
    
    private void updateSummary(List<String[]> transactions) {
        int count = transactions.size();
        double netAmount = 0;
        
        // Calculate net amount
        for (String[] txn : transactions) {
            if (txn.length >= 4) {
                String amountStr = txn[3]; // Amount is at index 3
                try {
                    // Remove $ sign and parse
                    amountStr = amountStr.replace("$", "").replace(",", "");
                    double amount = Double.parseDouble(amountStr);
                    netAmount += amount;
                } catch (NumberFormatException e) {
                    // Skip if can't parse
                }
            }
        }
        
        // Update labels
        JPanel bottomPanel = (JPanel) getContentPane().getComponent(2);
        JPanel summaryPanel = (JPanel) bottomPanel.getComponent(0);
        
        Component[] components = summaryPanel.getComponents();
        ((JLabel)components[0]).setText("Total Transactions: " + count);
        ((JLabel)components[2]).setText(String.format("Net Amount: $%.2f", netAmount));
    }
    
    private void updateSummaryForFiltered(String type, int count) {
        JPanel bottomPanel = (JPanel) getContentPane().getComponent(2);
        JPanel summaryPanel = (JPanel) bottomPanel.getComponent(0);
        
        Component[] components = summaryPanel.getComponents();
        ((JLabel)components[0]).setText(type + " Transactions: " + count);
        ((JLabel)components[2]).setText("Filtered View");
    }
    
    // Add sample data if no transactions exist
    private void addSampleData() {
        // Add some sample transactions for demonstration
        TransactionService.addTransaction(accountNo, "DEPOSIT", 1000.00, "Initial deposit");
        TransactionService.addTransaction(accountNo, "DEPOSIT", 500.00, "Salary credit");
        TransactionService.addTransaction(accountNo, "WITHDRAW", 200.00, "ATM withdrawal");
        TransactionService.addTransaction(accountNo, "WITHDRAW", 150.00, "Shopping");
        TransactionService.addTransaction(accountNo, "DEPOSIT", 300.00, "Cash deposit");
        
        JOptionPane.showMessageDialog(this,
            "Sample transactions added for demonstration.",
            "Info",
            JOptionPane.INFORMATION_MESSAGE);
    }
}