package ui;

import javax.swing.*;
import javax.swing.Timer;
import javax.swing.table.*;
import java.awt.*;
import java.text.SimpleDateFormat;
import java.util.*;
import java.util.List; // ✅ ADD THIS IMPORT
import service.StatementService;
import service.ChartService;
import service.TransactionService; // ✅ ADD THIS IMPORT
import util.TextChartUtils;

public class DynamicStatementFrame extends JFrame {
    
    private int accountNo;
    private String userName;
    private Timer refreshTimer;
    private DefaultTableModel tableModel; // ✅ ADD TABLE MODEL
    
    public DynamicStatementFrame(int accountNo, String userName) {
        this.accountNo = accountNo;
        this.userName = userName;
        
        setTitle("Financial Dashboard - " + userName);
        setSize(1100, 750);
        setLocationRelativeTo(null);
        setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        
        initUI();
        startAutoRefresh();
    }
    
    private void initUI() {
        // Main panel with nice gradient background
        JPanel mainPanel = new JPanel(new BorderLayout()) {
            @Override
            protected void paintComponent(Graphics g) {
                super.paintComponent(g);
                Graphics2D g2d = (Graphics2D) g;
                GradientPaint gradient = new GradientPaint(
                    0, 0, new Color(240, 248, 255),
                    0, getHeight(), new Color(230, 240, 250)
                );
                g2d.setPaint(gradient);
                g2d.fillRect(0, 0, getWidth(), getHeight());
            }
        };
        
        // Header with user info
        JPanel headerPanel = createHeaderPanel();
        
        // Tabbed content
        JTabbedPane tabbedPane = new JTabbedPane(JTabbedPane.TOP, JTabbedPane.SCROLL_TAB_LAYOUT);
        tabbedPane.setFont(new Font("Segoe UI", Font.PLAIN, 12));
        
        // Load current data
        Calendar cal = Calendar.getInstance();
        Map<String, Object> currentMonthData = StatementService.getMonthlySummary(
            accountNo, cal.get(Calendar.YEAR), cal.get(Calendar.MONTH) + 1);

        Map<String, Object> trends = StatementService.getMonthlyTrends(accountNo); // ✅ CHANGE TYPE

        @SuppressWarnings("unchecked")
        Map<String, Double> categories = (Map<String, Double>) currentMonthData.get("CATEGORIES");
        
        // Create tabs
        tabbedPane.addTab("🏠 Dashboard", 
            createDashboardTab(currentMonthData, trends));
        
        tabbedPane.addTab("📊 Analytics", 
            createAnalyticsTab(trends, categories));
        
        tabbedPane.addTab("📋 Statement", 
            createStatementTab(currentMonthData));
        
        tabbedPane.addTab("💳 Transactions", 
            createTransactionsTab());
        
        tabbedPane.addTab("🎯 Insights", 
            createInsightsTab(currentMonthData));
        
        // Status bar
        JPanel statusBar = new JPanel(new BorderLayout());
        statusBar.setBackground(new Color(240, 240, 240));
        statusBar.setBorder(BorderFactory.createMatteBorder(1, 0, 0, 0, Color.GRAY));
        
        JLabel statusLabel = new JLabel(" Last updated: " + new Date());
        statusLabel.setFont(new Font("Arial", Font.PLAIN, 11));
        
        JButton refreshBtn = new JButton("🔄 Refresh");
        refreshBtn.setFont(new Font("Arial", Font.PLAIN, 11));
        refreshBtn.setMargin(new Insets(2, 10, 2, 10));
        refreshBtn.addActionListener(e -> refreshData());
        
        statusBar.add(statusLabel, BorderLayout.WEST);
        statusBar.add(refreshBtn, BorderLayout.EAST);
        
        // Assemble main panel
        mainPanel.add(headerPanel, BorderLayout.NORTH);
        mainPanel.add(tabbedPane, BorderLayout.CENTER);
        mainPanel.add(statusBar, BorderLayout.SOUTH);
        
        add(mainPanel);
        
        // Set initial tab
        tabbedPane.setSelectedIndex(0);
    }
    
    private JPanel createHeaderPanel() {
        JPanel header = new JPanel(new BorderLayout());
        header.setBackground(new Color(30, 60, 114));
        header.setBorder(BorderFactory.createEmptyBorder(15, 20, 15, 20));
        
        // User info
        JPanel userPanel = new JPanel(new BorderLayout());
        userPanel.setBackground(new Color(30, 60, 114));
        
        JLabel welcomeLabel = new JLabel("Welcome, " + userName);
        welcomeLabel.setFont(new Font("Segoe UI", Font.BOLD, 24));
        welcomeLabel.setForeground(Color.WHITE);
        
        JLabel accountLabel = new JLabel("Account #" + accountNo + " | " + 
            new SimpleDateFormat("dd MMM yyyy, hh:mm a").format(new Date()));
        accountLabel.setFont(new Font("Segoe UI", Font.PLAIN, 12));
        accountLabel.setForeground(new Color(200, 220, 255));
        
        userPanel.add(welcomeLabel, BorderLayout.NORTH);
        userPanel.add(accountLabel, BorderLayout.SOUTH);
        
        // Quick stats
        JPanel statsPanel = new JPanel(new FlowLayout(FlowLayout.RIGHT, 20, 0));
        statsPanel.setBackground(new Color(30, 60, 114));
        
        Calendar cal = Calendar.getInstance();
        Map<String, Object> currentData = StatementService.getMonthlySummary(
            accountNo, cal.get(Calendar.YEAR), cal.get(Calendar.MONTH) + 1);
        
        double balance = (double) currentData.get("CLOSING_BALANCE");
        double savingsRate = (double) currentData.get("SAVINGS_RATE");
        
        JLabel balanceLabel = new JLabel(String.format("Balance: $%.2f", balance));
        balanceLabel.setFont(new Font("Segoe UI", Font.BOLD, 16));
        balanceLabel.setForeground(Color.WHITE);
        balanceLabel.setBorder(BorderFactory.createEmptyBorder(5, 15, 5, 15));
        balanceLabel.setBackground(new Color(0, 150, 136));
        balanceLabel.setOpaque(true);
        
        JLabel savingsLabel = new JLabel(String.format("Savings: %.1f%%", savingsRate));
        savingsLabel.setFont(new Font("Segoe UI", Font.BOLD, 16));
        savingsLabel.setForeground(Color.WHITE);
        savingsLabel.setBorder(BorderFactory.createEmptyBorder(5, 15, 5, 15));
        savingsLabel.setBackground(savingsRate >= 20 ? 
            new Color(76, 175, 80) : new Color(255, 152, 0));
        savingsLabel.setOpaque(true);
        
        statsPanel.add(balanceLabel);
        statsPanel.add(savingsLabel);
        
        header.add(userPanel, BorderLayout.WEST);
        header.add(statsPanel, BorderLayout.EAST);
        
        return header;
    }
    
    // ✅ FIXED METHOD SIGNATURE
    private JPanel createDashboardTab(Map<String, Object> currentData, Map<String, Object> trends) {
        JPanel panel = new JPanel(new BorderLayout());
        panel.setBackground(Color.WHITE);
        panel.setBorder(BorderFactory.createEmptyBorder(20, 20, 20, 20));
        
        // Top metrics row
        JPanel metricsRow = new JPanel(new GridLayout(1, 4, 15, 15));
        metricsRow.setBackground(Color.WHITE);
        metricsRow.setBorder(BorderFactory.createEmptyBorder(0, 0, 20, 0));
        
        metricsRow.add(TextChartUtils.createMetricCard(
            "💰 Current Balance",
            String.format("$%.2f", (double)currentData.get("CLOSING_BALANCE")),
            new Color(0, 150, 136),
            "💰"
        ));
        
        metricsRow.add(TextChartUtils.createMetricCard(
            "📥 Monthly Income",
            String.format("$%.2f", (double)currentData.get("TOTAL_DEPOSITS")),
            new Color(76, 175, 80),
            "📥"
        ));
        
        metricsRow.add(TextChartUtils.createMetricCard(
            "📤 Monthly Expenses",
            String.format("$%.2f", (double)currentData.get("TOTAL_WITHDRAWALS")),
            new Color(244, 67, 54),
            "📤"
        ));
        
        metricsRow.add(TextChartUtils.createMetricCard(
            "🎯 Savings Rate",
            String.format("%.1f%%", (double)currentData.get("SAVINGS_RATE")),
            (double)currentData.get("SAVINGS_RATE") >= 20 ? 
                new Color(76, 175, 80) : new Color(255, 152, 0),
            "🎯"
        ));
        
        // Charts row (2x2 grid)
        JPanel chartsRow = new JPanel(new GridLayout(2, 2, 15, 15));
        chartsRow.setBackground(Color.WHITE);
        
        chartsRow.add(ChartService.createBalanceTrendChart(trends));
        
        @SuppressWarnings("unchecked")
        Map<String, Double> categories = (Map<String, Double>) currentData.get("CATEGORIES");
        if (categories != null && !categories.isEmpty()) {
            chartsRow.add(ChartService.createExpensePieChart(categories));
        } else {
            chartsRow.add(createPlaceholderPanel("Expense Chart", 
                "No expense data available for current month"));
        }
        
        chartsRow.add(ChartService.createIncomeExpenseChart(trends));
        chartsRow.add(ChartService.createFinancialHealthPanel(currentData));
        
        panel.add(metricsRow, BorderLayout.NORTH);
        panel.add(chartsRow, BorderLayout.CENTER);
        
        return panel;
    }
    
    // ✅ FIXED METHOD SIGNATURE
    private JPanel createAnalyticsTab(Map<String, Object> trends, Map<String, Double> categories) {
        JPanel panel = new JPanel(new BorderLayout());
        panel.setBackground(Color.WHITE);
        
        JTabbedPane analyticsTabs = new JTabbedPane();
        
        // Tab 1: Trends Analysis
        JPanel trendsPanel = new JPanel(new GridLayout(2, 1, 10, 10));
        trendsPanel.setBorder(BorderFactory.createEmptyBorder(20, 20, 20, 20));
        trendsPanel.setBackground(Color.WHITE);
        
        trendsPanel.add(ChartService.createBalanceTrendChart(trends));
        trendsPanel.add(ChartService.createIncomeExpenseChart(trends));
        
        analyticsTabs.addTab("📈 Trends", trendsPanel);
        
        // Tab 2: Category Analysis
        if (categories != null && !categories.isEmpty()) {
            JPanel categoryPanel = new JPanel(new BorderLayout());
            categoryPanel.setBorder(BorderFactory.createEmptyBorder(20, 20, 20, 20));
            categoryPanel.setBackground(Color.WHITE);
            
            categoryPanel.add(ChartService.createExpensePieChart(categories), BorderLayout.CENTER);
            analyticsTabs.addTab("🍕 Categories", categoryPanel);
        }
        
        // Tab 3: Savings Analysis
        JPanel savingsPanel = new JPanel(new BorderLayout());
        savingsPanel.setBorder(BorderFactory.createEmptyBorder(20, 20, 20, 20));
        savingsPanel.setBackground(Color.WHITE);
        
        savingsPanel.add(ChartService.createSavingsRateChart(trends), BorderLayout.CENTER);
        analyticsTabs.addTab("💰 Savings", savingsPanel);
        
        panel.add(analyticsTabs, BorderLayout.CENTER);
        return panel;
    }
    
    private JPanel createStatementTab(Map<String, Object> currentData) {
        JPanel panel = new JPanel(new BorderLayout());
        panel.setBackground(Color.WHITE);
        panel.setBorder(BorderFactory.createEmptyBorder(20, 20, 20, 20));
        
        // Month selector
        JPanel controlPanel = new JPanel(new FlowLayout(FlowLayout.LEFT));
        controlPanel.setBackground(Color.WHITE);
        
        Calendar cal = Calendar.getInstance();
        int currentYear = cal.get(Calendar.YEAR);
        
        JLabel yearLabel = new JLabel("Year:");
        JComboBox<Integer> yearCombo = new JComboBox<>();
        for (int year = currentYear - 2; year <= currentYear; year++) {
            yearCombo.addItem(year);
        }
        yearCombo.setSelectedItem(currentYear);
        
        JLabel monthLabel = new JLabel("Month:");
        JComboBox<String> monthCombo = new JComboBox<>();
        String[] monthNames = {"January", "February", "March", "April", "May", "June",
                              "July", "August", "September", "October", "November", "December"};
        for (String month : monthNames) {
            monthCombo.addItem(month);
        }
        monthCombo.setSelectedIndex(cal.get(Calendar.MONTH));
        
        JButton loadBtn = new JButton("📄 Load Statement");
        JButton printBtn = new JButton("🖨️ Print Preview");
        
        controlPanel.add(yearLabel);
        controlPanel.add(yearCombo);
        controlPanel.add(monthLabel);
        controlPanel.add(monthCombo);
        controlPanel.add(loadBtn);
        controlPanel.add(printBtn);
        
        // Statement display
        JTextArea statementArea = new JTextArea();
        statementArea.setFont(new Font("Monospaced", Font.PLAIN, 12));
        statementArea.setEditable(false);
        statementArea.setBackground(new Color(248, 248, 255));
        
        loadBtn.addActionListener(e -> {
            int selectedYear = (int) yearCombo.getSelectedItem();
            int selectedMonth = monthCombo.getSelectedIndex() + 1;
            
            Map<String, Object> monthlyData = 
                StatementService.getMonthlySummary(accountNo, selectedYear, selectedMonth);
            
            statementArea.setText(generateStatementText(monthlyData, selectedYear, selectedMonth));
        });
        
        printBtn.addActionListener(e -> {
            JOptionPane.showMessageDialog(this,
                "Print feature will be available in the next update.",
                "Coming Soon",
                JOptionPane.INFORMATION_MESSAGE);
        });
        
        // Load initial data
        loadBtn.doClick();
        
        panel.add(controlPanel, BorderLayout.NORTH);
        panel.add(new JScrollPane(statementArea), BorderLayout.CENTER);
        
        return panel;
    }
    
    private String generateStatementText(Map<String, Object> data, int year, int month) {
        StringBuilder sb = new StringBuilder();
        
        String monthName = new String[]{"January", "February", "March", "April", "May", "June",
                                       "July", "August", "September", "October", "November", "December"}[month-1];
        
        sb.append("╔══════════════════════════════════════════════════════════════╗\n");
        sb.append("║                    MONTHLY BANK STATEMENT                    ║\n");
        sb.append("╚══════════════════════════════════════════════════════════════╝\n\n");
        
        sb.append("  Account Holder: ").append(userName).append("\n");
        sb.append("  Account Number: ").append(accountNo).append("\n");
        sb.append("  Statement Period: ").append(monthName).append(" ").append(year).append("\n");
        sb.append("  Generated: ").append(new Date()).append("\n\n");
        
        sb.append("  ┌────────────────────────────────────────────────────────────┐\n");
        sb.append("  │                       SUMMARY                             │\n");
        sb.append("  ├────────────────────────────────────────────────────────────┤\n");
        
        String[] labels = {"Opening Balance", "Total Deposits", "Total Withdrawals", 
                          "Net Flow", "Closing Balance", "Savings Rate", "Transactions"};
        Object[] values = {
            String.format("$%.2f", (double)data.get("OPENING_BALANCE")),
            String.format("$%.2f", (double)data.get("TOTAL_DEPOSITS")),
            String.format("$%.2f", (double)data.get("TOTAL_WITHDRAWALS")),
            String.format("$%.2f", (double)data.get("NET_FLOW")),
            String.format("$%.2f", (double)data.get("CLOSING_BALANCE")),
            String.format("%.1f%%", (double)data.get("SAVINGS_RATE")),
            data.get("TRANSACTION_COUNT")
        };
        
        for (int i = 0; i < labels.length; i++) {
            sb.append(String.format("  │ %-25s %25s │\n", labels[i] + ":", values[i]));
        }
        
        sb.append("  └────────────────────────────────────────────────────────────┘\n\n");
        
        // Expense categories
        @SuppressWarnings("unchecked")
        Map<String, Double> categories = (Map<String, Double>) data.get("CATEGORIES");
        
        if (categories != null && !categories.isEmpty()) {
            sb.append("  EXPENSE CATEGORIES:\n");
            sb.append("  ┌───────────────┬──────────────┬──────────────┬──────────────┐\n");
            sb.append("  │ Category      │ Amount       │ Percentage   │ Bar Chart    │\n");
            sb.append("  ├───────────────┼──────────────┼──────────────┼──────────────┤\n");
            
            double totalExpenses = (double) data.get("TOTAL_WITHDRAWALS");
            
            for (Map.Entry<String, Double> entry : categories.entrySet()) {
                double percentage = totalExpenses > 0 ? (entry.getValue() / totalExpenses) * 100 : 0;
                int barLength = (int) (percentage / 2);
                
                sb.append(String.format("  │ %-13s │ $%-11.2f │ %-12.1f%% │ %-12s │\n",
                    entry.getKey().length() > 13 ? entry.getKey().substring(0, 10) + "..." : entry.getKey(),
                    entry.getValue(),
                    percentage,
                    "█".repeat(Math.min(barLength, 12))
                ));
            }
            
            sb.append("  └───────────────┴──────────────┴──────────────┴──────────────┘\n");
        }
        
        sb.append("\n╔══════════════════════════════════════════════════════════════╗\n");
        sb.append("║                    END OF STATEMENT                         ║\n");
        sb.append("╚══════════════════════════════════════════════════════════════╝\n");
        
        return sb.toString();
    }
    
    private JPanel createTransactionsTab() {
        JPanel panel = new JPanel(new BorderLayout());
        panel.setBackground(Color.WHITE);
        panel.setBorder(BorderFactory.createEmptyBorder(20, 20, 20, 20));
        
        // ✅ FIXED: Use imported TransactionService
        List<String[]> allTransactions = TransactionService.getTransactionsForAccount(accountNo);
        
        // Create table
        String[] columns = {"ID", "Date", "Type", "Amount", "Category", "Description"};
        tableModel = new DefaultTableModel(columns, 0) { // ✅ USE INSTANCE VARIABLE
            @Override
            public Class<?> getColumnClass(int column) {
                return String.class;
            }
            
            @Override
            public boolean isCellEditable(int row, int column) {
                return false;
            }
        };
        
        // Add data
        for (String[] txn : allTransactions) {
            if (txn.length >= 4) {
                String category = categorizeTransaction(txn);
                String typeIcon = "";
                
                switch(txn[2]) {
                    case "DEPOSIT": typeIcon = "📥 "; break;
                    case "WITHDRAW": typeIcon = "📤 "; break;
                    case "TRANSFER": typeIcon = "🔄 "; break;
                    case "LOAN": typeIcon = "🏦 "; break;
                }
                
                tableModel.addRow(new Object[]{
                    txn[0], // ID
                    txn[1], // Date
                    typeIcon + txn[2], // Type with icon
                    txn[3], // Amount
                    category,
                    txn.length > 4 ? txn[4] : ""
                });
            }
        }
        
        JTable table = new JTable(tableModel);
        table.setRowHeight(35);
        table.setFont(new Font("Segoe UI", Font.PLAIN, 12));
        table.setIntercellSpacing(new Dimension(10, 5));
        
        // Column widths
        table.getColumnModel().getColumn(0).setPreferredWidth(80);
        table.getColumnModel().getColumn(1).setPreferredWidth(120);
        table.getColumnModel().getColumn(2).setPreferredWidth(80);
        table.getColumnModel().getColumn(3).setPreferredWidth(100);
        table.getColumnModel().getColumn(4).setPreferredWidth(100);
        table.getColumnModel().getColumn(5).setPreferredWidth(250);
        
        // Custom renderer for coloring
        table.setDefaultRenderer(Object.class, new DefaultTableCellRenderer() {
            @Override
            public Component getTableCellRendererComponent(JTable table, Object value,
                    boolean isSelected, boolean hasFocus, int row, int column) {
                Component c = super.getTableCellRendererComponent(table, value, 
                        isSelected, hasFocus, row, column);
                
                if (!isSelected) {
                    if (column == 2) { // Type column
                        String type = value.toString();
                        if (type.contains("DEPOSIT")) {
                            c.setBackground(new Color(220, 255, 220));
                            c.setForeground(new Color(0, 100, 0));
                        } else if (type.contains("WITHDRAW")) {
                            c.setBackground(new Color(255, 220, 220));
                            c.setForeground(new Color(180, 0, 0));
                        } else {
                            c.setBackground(Color.WHITE);
                        }
                    } else if (column == 3) { // Amount column
                        String amount = value.toString();
                        if (!amount.startsWith("-")) {
                            c.setForeground(new Color(0, 150, 0));
                            c.setFont(c.getFont().deriveFont(Font.BOLD));
                        } else {
                            c.setForeground(new Color(200, 0, 0));
                            c.setFont(c.getFont().deriveFont(Font.BOLD));
                        }
                        c.setBackground(Color.WHITE);
                    } else {
                        c.setBackground(Color.WHITE);
                        c.setForeground(Color.BLACK);
                    }
                }
                
                return c;
            }
        });
        
        JScrollPane scrollPane = new JScrollPane(table);
        scrollPane.getViewport().setBackground(Color.WHITE);
        
        // Summary
        JLabel summaryLabel = new JLabel(
            String.format("📊 Total Transactions: %d | Last Transaction: %s",
                allTransactions.size(),
                allTransactions.isEmpty() ? "None" : allTransactions.get(0)[1]));
        summaryLabel.setFont(new Font("Arial", Font.BOLD, 12));
        summaryLabel.setBorder(BorderFactory.createEmptyBorder(0, 0, 10, 0));
        
        panel.add(summaryLabel, BorderLayout.NORTH);
        panel.add(scrollPane, BorderLayout.CENTER);
        
        return panel;
    }
    
    private JPanel createInsightsTab(Map<String, Object> currentData) {
        JPanel panel = new JPanel(new BorderLayout());
        panel.setBackground(Color.WHITE);
        panel.setBorder(BorderFactory.createEmptyBorder(20, 20, 20, 20));
        
        JTextArea insightsArea = new JTextArea();
        insightsArea.setFont(new Font("Segoe UI", Font.PLAIN, 13));
        insightsArea.setEditable(false);
        insightsArea.setLineWrap(true);
        insightsArea.setWrapStyleWord(true);
        insightsArea.setBackground(new Color(248, 248, 255));
        insightsArea.setBorder(BorderFactory.createEmptyBorder(15, 15, 15, 15));
        
        // Generate insights
        double savingsRate = (double) currentData.get("SAVINGS_RATE");
        double netFlow = (double) currentData.get("NET_FLOW");
        double totalDeposits = (double) currentData.get("TOTAL_DEPOSITS");
        double totalWithdrawals = (double) currentData.get("TOTAL_WITHDRAWALS");
        int transactionCount = (int) currentData.get("TRANSACTION_COUNT");
        
        @SuppressWarnings("unchecked")
        Map<String, Double> categories = (Map<String, Double>) currentData.get("CATEGORIES");
        
        StringBuilder insights = new StringBuilder();
        insights.append("💡 FINANCIAL INSIGHTS & RECOMMENDATIONS\n");
        insights.append("═".repeat(50)).append("\n\n");
        
        insights.append("📈 MONTHLY PERFORMANCE:\n");
        insights.append(String.format("• Savings Rate: %.1f%%\n", savingsRate));
        insights.append(String.format("• Net Flow: $%.2f\n", netFlow));
        insights.append(String.format("• Income: $%.2f | Expenses: $%.2f\n", totalDeposits, totalWithdrawals));
        insights.append(String.format("• Transactions: %d\n\n", transactionCount));
        
        insights.append("🏆 ACHIEVEMENTS:\n");
        if (savingsRate >= 30) {
            insights.append("✅ Excellent savings rate! You're saving more than 30% of your income.\n");
        }
        if (netFlow > 0) {
            insights.append("✅ Positive cash flow! You're earning more than you spend.\n");
        }
        if (transactionCount >= 10) {
            insights.append("✅ Active account management with frequent transactions.\n");
        }
        insights.append("\n");
        
        insights.append("🎯 RECOMMENDATIONS:\n");
        if (savingsRate < 20) {
            insights.append("⚠️ Consider increasing your savings rate to at least 20%\n");
            insights.append("   → Set up automatic transfers to savings account\n");
        }
        if (netFlow < 0) {
            insights.append("⚠️ You're spending more than you earn this month\n");
            insights.append("   → Review non-essential expenses\n");
            insights.append("   → Create a budget for next month\n");
        }
        
        if (categories != null && !categories.isEmpty()) {
            // Find largest expense category
            Map.Entry<String, Double> largestExpense = null;
            for (Map.Entry<String, Double> entry : categories.entrySet()) {
                if (largestExpense == null || entry.getValue() > largestExpense.getValue()) {
                    largestExpense = entry;
                }
            }
            
            if (largestExpense != null) {
                insights.append(String.format("\n💸 TOP EXPENSE CATEGORY: %s ($%.2f)\n", 
                    largestExpense.getKey(), largestExpense.getValue()));
                insights.append("   Consider ways to reduce spending in this category\n");
            }
        }
        
        if (savingsRate >= 25 && netFlow > 0) {
            insights.append("\n🚀 NEXT STEPS:\n");
            insights.append("• Consider opening an investment account\n");
            insights.append("• Set up an emergency fund (3-6 months of expenses)\n");
            insights.append("• Explore high-yield savings accounts\n");
        }
        
        insights.append("\n📅 UPCOMING:\n");
        insights.append("• Next month's goal: Increase savings rate by 5%\n");
        insights.append("• Review subscriptions and recurring payments\n");
        insights.append("• Plan for upcoming large expenses\n");
        
        insightsArea.setText(insights.toString());
        
        panel.add(new JScrollPane(insightsArea), BorderLayout.CENTER);
        
        return panel;
    }
    
    private String categorizeTransaction(String[] transaction) {
        if (transaction.length < 5) return "Other";
        
        String desc = transaction[4].toLowerCase();
        
        if (desc.contains("food") || desc.contains("restaurant") || desc.contains("dinner")) 
            return "Food";
        if (desc.contains("shop") || desc.contains("store") || desc.contains("mall")) 
            return "Shopping";
        if (desc.contains("bill") || desc.contains("utility") || desc.contains("electric")) 
            return "Bills";
        if (desc.contains("movie") || desc.contains("entertain") || desc.contains("game")) 
            return "Entertainment";
        if (desc.contains("travel") || desc.contains("fuel") || desc.contains("uber")) 
            return "Travel";
        if (desc.contains("medical") || desc.contains("hospital") || desc.contains("doctor")) 
            return "Healthcare";
        if (desc.contains("salary") || desc.contains("income") || desc.contains("deposit")) 
            return "Income";
        
        return "Other";
    }
    
    private JPanel createPlaceholderPanel(String title, String message) {
        JPanel panel = new JPanel(new BorderLayout());
        panel.setBackground(Color.WHITE);
        panel.setBorder(BorderFactory.createTitledBorder(title));
        
        JLabel label = new JLabel("<html><center><h3 style='color:#666;'>" + title + "</h3>" +
                                 "<p>" + message + "</p>" +
                                 "<p style='margin-top:20px;'>📊 Charts will appear when data is available</p></center></html>");
        label.setHorizontalAlignment(SwingConstants.CENTER);
        label.setBorder(BorderFactory.createEmptyBorder(40, 20, 40, 20));
        
        panel.add(label, BorderLayout.CENTER);
        return panel;
    }
    
    private void startAutoRefresh() {
        refreshTimer = new Timer(30000, e -> refreshData()); // Refresh every 30 seconds
        refreshTimer.start();
    }
    
    private void refreshData() {
        // In a real app, this would refresh from database
        // For now, just update the UI
        dispose();
        new DynamicStatementFrame(accountNo, userName).setVisible(true);
    }
    
    @Override
    public void dispose() {
        if (refreshTimer != null) {
            refreshTimer.stop();
        }
        super.dispose();
    }
    
    // ✅ FIXED: loadTransactions() method
    private void loadTransactions() {
        if (tableModel == null) return;
        
        tableModel.setRowCount(0);
        
        List<String[]> transactions = TransactionService.getTransactionsForAccount(accountNo);
        
        if (transactions.isEmpty()) {
            // ✅ SHOW REAL EMPTY STATE (not add fake data)
            tableModel.addRow(new Object[]{
                "No Data", 
                new Date().toString(), 
                "INFO", 
                "$0.00", 
                "No transactions yet. Make a deposit or withdrawal."
            });
        } else {
            // ✅ SHOW REAL TRANSACTIONS
            for (String[] txn : transactions) {
                tableModel.addRow(txn);
            }
        }
    }
}