package ui;

import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import exception.InvalidCredentialsException;
import model.User;
import service.AuthService;

public class LoginFrame extends JFrame {
    
    public LoginFrame() {
        // Modern frame settings
        setTitle("Banking System - Login");
        setSize(400, 450);
        setLocationRelativeTo(null);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setResizable(false);
        
        // Set modern look
        try {
            UIManager.setLookAndFeel(UIManager.getSystemLookAndFeelClassName());
        } catch (Exception e) {
            e.printStackTrace();
        }
        
        initUI();
    }
    
    private void initUI() {
        // Main panel with gradient
        JPanel mainPanel = new JPanel(new BorderLayout()) {
            @Override
            protected void paintComponent(Graphics g) {
                super.paintComponent(g);
                Graphics2D g2d = (Graphics2D) g;
                GradientPaint gradient = new GradientPaint(
                    0, 0, new Color(30, 60, 114),
                    0, getHeight(), new Color(70, 130, 180)
                );
                g2d.setPaint(gradient);
                g2d.fillRect(0, 0, getWidth(), getHeight());
            }
        };
        
        // Center form panel
        JPanel formPanel = new JPanel();
        formPanel.setLayout(null);
        formPanel.setOpaque(false);
        
        // Title
        JLabel titleLabel = new JLabel("🏦 Banking System");
        titleLabel.setFont(new Font("Segoe UI", Font.BOLD, 28));
        titleLabel.setForeground(Color.WHITE);
        titleLabel.setBounds(0, 40, 400, 40);
        titleLabel.setHorizontalAlignment(SwingConstants.CENTER);
        
        // Subtitle
        JLabel subtitleLabel = new JLabel("Secure Login to Your Account");
        subtitleLabel.setFont(new Font("Segoe UI", Font.PLAIN, 14));
        subtitleLabel.setForeground(new Color(200, 220, 255));
        subtitleLabel.setBounds(0, 85, 400, 20);
        subtitleLabel.setHorizontalAlignment(SwingConstants.CENTER);
        
        // Account number field
        JLabel accLabel = new JLabel("Account Number");
        accLabel.setFont(new Font("Segoe UI", Font.BOLD, 12));
        accLabel.setForeground(Color.WHITE);
        accLabel.setBounds(50, 130, 300, 20);
        
        JTextField accField = new JTextField();
        accField.setBounds(50, 155, 300, 40);
        accField.setFont(new Font("Segoe UI", Font.PLAIN, 14));
        accField.setBorder(BorderFactory.createCompoundBorder(
            BorderFactory.createLineBorder(new Color(180, 200, 255), 1),
            BorderFactory.createEmptyBorder(0, 10, 0, 10)
        ));
        
        // Password field
        JLabel passLabel = new JLabel("Password");
        passLabel.setFont(new Font("Segoe UI", Font.BOLD, 12));
        passLabel.setForeground(Color.WHITE);
        passLabel.setBounds(50, 210, 300, 20);
        
        JPasswordField passField = new JPasswordField();
        passField.setBounds(50, 235, 300, 40);
        passField.setFont(new Font("Segoe UI", Font.PLAIN, 14));
        passField.setBorder(BorderFactory.createCompoundBorder(
            BorderFactory.createLineBorder(new Color(180, 200, 255), 1),
            BorderFactory.createEmptyBorder(0, 10, 0, 10)
        ));
        
        // Login button
        JButton loginBtn = new JButton("Login");
        loginBtn.setBounds(50, 300, 300, 45);
        loginBtn.setFont(new Font("Segoe UI", Font.BOLD, 14));
        loginBtn.setBackground(new Color(255, 255, 255));
        loginBtn.setForeground(new Color(30, 60, 114));
        loginBtn.setFocusPainted(false);
        loginBtn.setBorder(BorderFactory.createEmptyBorder(10, 0, 10, 0));
        loginBtn.setCursor(new Cursor(Cursor.HAND_CURSOR));
        
        // Rounded button
        loginBtn.setUI(new javax.swing.plaf.basic.BasicButtonUI() {
            @Override
            public void paint(Graphics g, JComponent c) {
                Graphics2D g2d = (Graphics2D) g;
                g2d.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
                
                AbstractButton b = (AbstractButton) c;
                ButtonModel model = b.getModel();
                
                if (model.isPressed()) {
                    g2d.setColor(new Color(240, 240, 240));
                } else if (model.isRollover()) {
                    g2d.setColor(new Color(255, 255, 255));
                } else {
                    g2d.setColor(new Color(255, 255, 255));
                }
                
                g2d.fillRoundRect(0, 0, c.getWidth(), c.getHeight(), 25, 25);
                super.paint(g, c);
            }
        });
        
        // Signup link
        JLabel signupLabel = new JLabel("Don't have an account? Sign Up");
        signupLabel.setFont(new Font("Segoe UI", Font.PLAIN, 12));
        signupLabel.setForeground(Color.WHITE);
        signupLabel.setBounds(0, 360, 400, 20);
        signupLabel.setHorizontalAlignment(SwingConstants.CENTER);
        signupLabel.setCursor(new Cursor(Cursor.HAND_CURSOR));
        
        // Add components to form panel
        formPanel.add(titleLabel);
        formPanel.add(subtitleLabel);
        formPanel.add(accLabel);
        formPanel.add(accField);
        formPanel.add(passLabel);
        formPanel.add(passField);
        formPanel.add(loginBtn);
        formPanel.add(signupLabel);
        
        // Event handlers
        loginBtn.addActionListener(e -> {
            try {
                String accountText = accField.getText().trim();
                if (accountText.isEmpty()) {
                    JOptionPane.showMessageDialog(this, "Please enter account number");
                    return;
                }
                
                User user = AuthService.login(
                    Integer.parseInt(accountText),
                    new String(passField.getPassword())
                );

                JOptionPane.showMessageDialog(this, 
                    "Welcome " + user.getName() + "!",
                    "Login Successful",
                    JOptionPane.INFORMATION_MESSAGE);
                
                new DashboardFrame(user).setVisible(true);
                dispose();

            } catch (InvalidCredentialsException ex) {
                JOptionPane.showMessageDialog(this, 
                    ex.getMessage(),
                    "Login Failed",
                    JOptionPane.ERROR_MESSAGE);
            } catch (NumberFormatException ex) {
                JOptionPane.showMessageDialog(this,
                    "Please enter a valid account number",
                    "Invalid Input",
                    JOptionPane.WARNING_MESSAGE);
            }
        });
        
        signupLabel.addMouseListener(new MouseAdapter() {
            @Override
            public void mouseClicked(MouseEvent e) {
                new SignupFrame().setVisible(true);
                dispose();
            }
            
            @Override
            public void mouseEntered(MouseEvent e) {
                signupLabel.setForeground(new Color(144, 238, 144));
            }
            
            @Override
            public void mouseExited(MouseEvent e) {
                signupLabel.setForeground(Color.WHITE);
            }
        });
        
        mainPanel.add(formPanel, BorderLayout.CENTER);
        add(mainPanel);
    }
}