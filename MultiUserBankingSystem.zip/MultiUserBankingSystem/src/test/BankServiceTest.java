package test;

import model.Account;
import model.SavingsAccount;
import service.BankService;
import exception.InsufficientBalanceException;

public class BankServiceTest {
    
    public static void main(String[] args) {
        System.out.println("=== Bank Service Test ===");
        
        // Create test account
        Account testAccount = new SavingsAccount(9999, 1000.0);
        
        // Test 1: Deposit
        System.out.println("Test 1: Deposit $500");
        System.out.println("Before: $" + testAccount.getBalance());
        BankService.deposit(testAccount, 500);
        System.out.println("After: $" + testAccount.getBalance());
        
        // Test 2: Withdraw valid amount
        System.out.println("\nTest 2: Withdraw $300");
        try {
            BankService.withdraw(testAccount, 300);
            System.out.println("Success! Balance: $" + testAccount.getBalance());
        } catch (InsufficientBalanceException e) {
            System.out.println("Failed: " + e.getMessage());
        }
        
        // Test 3: Withdraw insufficient balance
        System.out.println("\nTest 3: Attempt to withdraw $2000");
        try {
            BankService.withdraw(testAccount, 2000);
            System.out.println("Success! Balance: $" + testAccount.getBalance());
        } catch (InsufficientBalanceException e) {
            System.out.println("Failed (expected): " + e.getMessage());
        }
        
        // Test 4: Invalid amount
        System.out.println("\nTest 4: Attempt to withdraw -$100");
        try {
            BankService.withdraw(testAccount, -100);
            System.out.println("Success! Balance: $" + testAccount.getBalance());
        } catch (InsufficientBalanceException e) {
            System.out.println("Failed (expected): " + e.getMessage());
        }
        
        System.out.println("\n=== All Tests Completed ===");
    }
}