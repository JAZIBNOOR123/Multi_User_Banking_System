package test;

//TestStatementSystem.java
import service.StatementService;
import service.TransactionService;
import java.util.Map;
import java.util.Calendar;

public class TestStatementSystem {
 public static void main(String[] args) {
     System.out.println("🧪 Testing Dynamic Statement System...\n");
     
     int testAccountNo = 1001;
     
     // Test current month summary
     Calendar cal = Calendar.getInstance();
     Map<String, Object> currentMonth = StatementService.getMonthlySummary(
         testAccountNo, cal.get(Calendar.YEAR), cal.get(Calendar.MONTH) + 1);
     
     System.out.println("📊 Current Month Summary:");
     System.out.println("Deposits: $" + currentMonth.get("TOTAL_DEPOSITS"));
     System.out.println("Withdrawals: $" + currentMonth.get("TOTAL_WITHDRAWALS"));
     System.out.println("Net Flow: $" + currentMonth.get("NET_FLOW"));
     System.out.println("Savings Rate: " + currentMonth.get("SAVINGS_RATE") + "%");
     System.out.println("Transactions: " + currentMonth.get("TRANSACTION_COUNT"));
     
     // Test trends
     Map<String, Object> trends = StatementService.getMonthlyTrends(testAccountNo);
     System.out.println("\n📈 Trends Data Structure:");
     System.out.println("Balances array length: " + ((double[])trends.get("BALANCES")).length);
     System.out.println("Month labels: " + String.join(", ", (String[])trends.get("MONTH_LABELS")));
     
     System.out.println("\n✅ All tests passed! Statement system is working.");
 }
}
