package service;
import model.Account;
import model.SavingsAccount;
import model.CurrentAccount;

import java.util.HashMap;
import java.util.Map;

import exception.InvalidCredentialsException;
import model.*;
import util.IDGenerator;

public class AuthService {

    // In-memory database
    private static Map<Integer, User> users = new HashMap<>();

    // SIGNUP
    public static User signup(String name, String password, String accountType) {
        int accNo = IDGenerator.generateAccountNo();

        Account account;

        if (accountType.equalsIgnoreCase("Savings")) {
            account = new SavingsAccount(accNo, 0.0);
        } else {
            account = new CurrentAccount(accNo, 0.0);
        }

        User user = new User(accNo, name, password, account);
        users.put(accNo, user);

        return user;
    }

    // LOGIN
    public static User login(int accountNo, String password) throws InvalidCredentialsException {
        User user = users.get(accountNo);

        if (user == null || !user.getPassword().equals(password)) {
            throw new InvalidCredentialsException("❌ Invalid Account Number or Password");
        }
        return user;
    }
}
