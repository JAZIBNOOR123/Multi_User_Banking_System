package service;

import exception.InsufficientBalanceException;
import model.Account;
import util.AccountLock;
import service.TransactionService;

public class BankService {

    public static void deposit(Account account, double amount) {
        AccountLock.lock.lock();
        try {
            // Get account number safely
            int accountNo = account.getAccountNo();
            double oldBalance = account.getBalance();
            
            // Perform deposit synchronize way mein chalyga
            account.deposit(amount);
            
            // TRANSACTION 
            System.out.println("🏦 Deposit: A/C " + accountNo + 
                             " | Amount: $" + amount + 
                             " | Old Balance: $" + oldBalance + 
                             " | New Balance: $" + account.getBalance());
            
            // Record transaction
            TransactionService.addTransaction(
                accountNo, 
                "DEPOSIT", 
                amount, 
                "Cash deposit. Balance: $" + account.getBalance()
            );
            
        } catch (Exception e) {
            System.out.println("❌ Error in deposit: " + e.getMessage());
            e.printStackTrace();
        } finally {
            AccountLock.lock.unlock();
        }
    }

    public static void withdraw(Account account, double amount)
            throws InsufficientBalanceException {

        AccountLock.lock.lock();// yaha lock lag giya........................................
        try {
            if (amount <= 0) {
                throw new InsufficientBalanceException("❌ Invalid amount");
            }

            if (account.getBalance() < amount) {
                throw new InsufficientBalanceException("❌ Insufficient Balance");
            }
            
            // Get account number
            int accountNo = account.getAccountNo();
            double oldBalance = account.getBalance();
            
            // Perform withdrawal synchronize way mein chalyga
            account.withdraw(amount);
        
            System.out.println("🏦 Withdraw: A/C " + accountNo + 
                             " | Amount: $" + amount + 
                             " | Old Balance: $" + oldBalance + 
                             " | New Balance: $" + account.getBalance());
            
            TransactionService.addTransaction(
                accountNo, 
                "WITHDRAW", 
                -amount, 
                "Cash withdrawal. Balance: $" + account.getBalance()
            );

        } catch (InsufficientBalanceException e) {
            throw e; // Re-throw the exception
        } catch (Exception e) {
            System.out.println("❌ Error in withdraw: " + e.getMessage());
            e.printStackTrace();
        } finally {
            AccountLock.lock.unlock();// yaha lock khul giya ...............................
        }
    }
}