package service;

import java.util.ArrayList;
import java.util.List;
import java.util.Date;
import java.text.SimpleDateFormat;

public class TransactionService {
    
    private static final List<String[]> transactionRecords = new ArrayList<>();
    private static int transactionCounter = 1;
    private static final SimpleDateFormat sdf = new SimpleDateFormat("dd-MM-yyyy HH:mm:ss");
    
    // Add transaction
    public static void addTransaction(int accountNo, String type, 
                                     double amount, String description) {
        String timestamp = sdf.format(new Date());
        String amountStr = String.format("$%.2f", amount);
        
        // Format: negative for withdrawals, positive for deposits
        if (type.equalsIgnoreCase("WITHDRAW")) {
            amountStr = "-" + amountStr;
        }
        
        String[] record = {
            "TXN-" + String.format("%04d", transactionCounter++),
            timestamp,
            type,
            amountStr,
            description
        };
        
        transactionRecords.add(record);
        System.out.println("💾 Transaction recorded: " + record[0] + " for A/C " + accountNo);
    }
    
    // Get transactions for account
    public static List<String[]> getTransactionsForAccount(int accountNo) {
        List<String[]> result = new ArrayList<>();
        
        // Note: In current implementation, we need to track account numbers differently
        // For now, return all transactions (demo purpose)
        // In real app, you'd filter by accountNo
        
        System.out.println("📋 Loading transactions... Total: " + transactionRecords.size());
        		
        return new ArrayList<>(transactionRecords);
    }
    
    // Helper method for demo
 // TransactionService.java mein REAL data collection:
    public static List<String[]> getRealTransactionsForAccount(int accountNo) {
        List<String[]> allTransactions = getTransactionsForAccount(accountNo);
        
        if (allTransactions.isEmpty()) {
            // ❌ NO SAMPLE DATA
            System.out.println("⚠️ No transactions found for account: " + accountNo);
            return new ArrayList<>();
        }
        
        return allTransactions;
    }
    // Get total deposits (simplified)
    public static double getTotalDeposits(int accountNo) {
        double total = 0;
        for (String[] record : transactionRecords) {
            if (record[2].equalsIgnoreCase("DEPOSIT")) {
                try {
                    String amountStr = record[3].replace("$", "");
                    total += Double.parseDouble(amountStr);
                } catch (Exception e) {
                    // Skip if can't parse
                }
            }
        }
        return total;
    }
    
    // Get total withdrawals (simplified)
    public static double getTotalWithdrawals(int accountNo) {
        double total = 0;
        for (String[] record : transactionRecords) {
            if (record[2].equalsIgnoreCase("WITHDRAW")) {
                try {
                    String amountStr = record[3].replace("$", "").replace("-", "");
                    total += Double.parseDouble(amountStr);
                } catch (Exception e) {
                    // Skip if can't parse
                }
            }
        }
        return total;
    }
}