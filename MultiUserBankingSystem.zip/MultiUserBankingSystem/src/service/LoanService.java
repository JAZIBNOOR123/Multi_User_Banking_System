package service;

import model.LoanAccount;
import model.User;
import exception.InsufficientBalanceException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class LoanService {
    private static Map<Integer, LoanAccount> activeLoans = new HashMap<>();
    private static List<LoanAccount> loanHistory = new ArrayList<>();
    
    // Bank Policy: Fixed interest rates by loan type
    private static final double HOME_LOAN_RATE = 0.085;      // 8.5%
    private static final double CAR_LOAN_RATE = 0.095;       // 9.5%
    private static final double PERSONAL_LOAN_RATE = 0.125;  // 12.5%
    private static final double EDUCATION_LOAN_RATE = 0.075; // 7.5%
    
    // Bank Policy: Loan limits
    private static final double MIN_LOAN_AMOUNT = 1000.0;
    private static final double MAX_LOAN_AMOUNT = 100000.0;
    private static final int MIN_LOAN_MONTHS = 6;
    private static final int MAX_LOAN_MONTHS = 360;
    
    /**
     * Apply for a loan (Bank decides rate based on type)
     */
    public static LoanAccount applyForLoan(User user, double amount, 
                                          int months, double interestRate) 
            throws InsufficientBalanceException {
        
        // ✅ BANK POLICY VALIDATION
        if (amount < MIN_LOAN_AMOUNT) {
            throw new IllegalArgumentException(
                String.format("❌ Minimum loan amount is $%.2f", MIN_LOAN_AMOUNT));
        }
        
        if (amount > MAX_LOAN_AMOUNT) {
            throw new IllegalArgumentException(
                String.format("❌ Maximum loan amount is $%.2f", MAX_LOAN_AMOUNT));
        }
        
        if (months < MIN_LOAN_MONTHS) {
            throw new IllegalArgumentException(
                String.format("❌ Minimum loan duration is %d months", MIN_LOAN_MONTHS));
        }
        
        if (months > MAX_LOAN_MONTHS) {
            throw new IllegalArgumentException(
                String.format("❌ Maximum loan duration is %d months", MAX_LOAN_MONTHS));
        }
        
        // ✅ BANK POLICY: Validate interest rate is from approved list
        if (!isApprovedRate(interestRate)) {
            throw new IllegalArgumentException(
                "❌ Invalid interest rate. Must be one of: 7.5%, 8.5%, 9.5%, 12.5%");
        }
        
        // ✅ Check if user already has active loan
        if (activeLoans.containsKey(user.getAccountNo())) {
            throw new IllegalStateException("❌ You already have an active loan");
        }
        
        // ✅ Check user's eligibility (simple check)
        if (!isUserEligible(user, amount)) {
            throw new IllegalStateException(
                "❌ Loan application rejected. Insufficient banking history.");
        }
        
        // Create loan account with BANK APPROVED rate
        LoanAccount loanAccount = new LoanAccount(
            user.getAccountNo(), 
            amount, 
            interestRate, // Bank's approved rate
            months
        );
        
        // Deposit loan amount to user's main account (Thread-safe)
        synchronized (user.getAccount()) {
            user.getAccount().deposit(amount);
        }
        
        // Track loan
        activeLoans.put(user.getAccountNo(), loanAccount);
        loanHistory.add(loanAccount);
        
        // Add transaction for loan disbursement
        TransactionService.addTransaction(
            user.getAccountNo(), 
            "LOAN_DISBURSED", 
            amount, 
            String.format("%s at %.1f%% for %d months | EMI: $%.2f", 
                         getLoanTypeFromRate(interestRate),
                         interestRate * 100, 
                         months,
                         calculateEMI(amount, interestRate, months))
        );
        
        // Add processing fee transaction (1%)
        double processingFee = amount * 0.01;
        synchronized (user.getAccount()) {
            if (user.getAccount().getBalance() >= processingFee) {
                user.getAccount().withdraw(processingFee);
                TransactionService.addTransaction(
                    user.getAccountNo(),
                    "LOAN_PROCESSING_FEE",
                    -processingFee,
                    String.format("1%% processing fee for %s", getLoanTypeFromRate(interestRate))
                );
            }
        }
        
        return loanAccount;
    }
    
    /**
     * Pay loan installment
     */
    public static void payLoanInstallment(User user, double amount) 
            throws InsufficientBalanceException {
        
        LoanAccount loanAccount = activeLoans.get(user.getAccountNo());
        if (loanAccount == null) {
            throw new IllegalStateException("❌ No active loan found");
        }
        
        // Check if user has enough balance to pay
        if (user.getAccount().getBalance() < amount) {
            throw new InsufficientBalanceException("❌ Insufficient balance to pay loan");
        }
        
        // Minimum payment check (at least 10% of EMI)
        double emi = calculateEMI(
            loanAccount.getBorrowedAmount(),
            loanAccount.getInterestRate(),
            loanAccount.getLoanDurationMonths()
        );
        
        if (amount < emi * 0.1) {
            throw new IllegalArgumentException(
                String.format("❌ Minimum payment is $%.2f (10%% of EMI)", emi * 0.1));
        }
        
        // Withdraw from main account (Thread-safe)
        synchronized (user.getAccount()) {
            user.getAccount().withdraw(amount);
        }
        
        // Apply to loan
        loanAccount.makePayment(amount);
        
        // Check if loan paid off
        if (loanAccount.getRemainingBalance() <= 0) {
            activeLoans.remove(user.getAccountNo());
            TransactionService.addTransaction(
                user.getAccountNo(), 
                "LOAN_PAID_OFF", 
                -amount, 
                String.format("Loan fully paid off | Type: %s", 
                            getLoanTypeFromRate(loanAccount.getInterestRate()))
            );
            
            // Add congratulations transaction
            TransactionService.addTransaction(
                user.getAccountNo(),
                "LOAN_CLOSED",
                0,
                "Congratulations! Loan successfully paid off."
            );
        } else {
            TransactionService.addTransaction(
                user.getAccountNo(), 
                "LOAN_PAYMENT", 
                -amount, 
                String.format("%s payment | Remaining: $%.2f | Next EMI: $%.2f", 
                            getLoanTypeFromRate(loanAccount.getInterestRate()),
                            loanAccount.getRemainingBalance(),
                            emi)
            );
        }
    }
    
    /**
     * Calculate EMI using standard formula
     */
    public static double calculateEMI(double principal, double annualRate, int months) {
        if (principal <= 0 || annualRate <= 0 || months <= 0) {
            return 0;
        }
        
        double monthlyRate = annualRate / 12;
        return (principal * monthlyRate * Math.pow(1 + monthlyRate, months)) 
                / (Math.pow(1 + monthlyRate, months) - 1);
    }
    
    /**
     * Get active loan for account
     */
    public static LoanAccount getActiveLoan(int accountNo) {
        return activeLoans.get(accountNo);
    }
    
    /**
     * Get loan history for account
     */
    public static List<LoanAccount> getLoanHistory(int accountNo) {
        List<LoanAccount> userLoans = new ArrayList<>();
        for (LoanAccount loan : loanHistory) {
            if (loan.getAccountNo() == accountNo) {
                userLoans.add(loan);
            }
        }
        return userLoans;
    }
    
    /**
     * Get loan type from interest rate (Bank Policy)
     */
    public static String getLoanTypeFromRate(double rate) {
        if (Math.abs(rate - HOME_LOAN_RATE) < 0.001) {
            return "Home Loan";
        } else if (Math.abs(rate - CAR_LOAN_RATE) < 0.001) {
            return "Car Loan";
        } else if (Math.abs(rate - PERSONAL_LOAN_RATE) < 0.001) {
            return "Personal Loan";
        } else if (Math.abs(rate - EDUCATION_LOAN_RATE) < 0.001) {
            return "Education Loan";
        } else {
            return "Personal Loan";
        }
    }
    
    /**
     * Get rate for loan type (Bank Policy)
     */
    public static double getRateForType(String loanType) {
        switch (loanType.toLowerCase()) {
            case "home":
            case "home loan":
                return HOME_LOAN_RATE;
            case "car":
            case "car loan":
                return CAR_LOAN_RATE;
            case "personal":
            case "personal loan":
                return PERSONAL_LOAN_RATE;
            case "education":
            case "education loan":
                return EDUCATION_LOAN_RATE;
            default:
                return PERSONAL_LOAN_RATE;
        }
    }
    
    /**
     * Check if rate is approved by bank policy
     */
    private static boolean isApprovedRate(double rate) {
        return Math.abs(rate - HOME_LOAN_RATE) < 0.001 ||
               Math.abs(rate - CAR_LOAN_RATE) < 0.001 ||
               Math.abs(rate - PERSONAL_LOAN_RATE) < 0.001 ||
               Math.abs(rate - EDUCATION_LOAN_RATE) < 0.001;
    }
    
    /**
     * Simple eligibility check (Bank Policy)
     */
    private static boolean isUserEligible(User user, double requestedAmount) {
        // Rule 1: Minimum balance should be 10% of loan amount
        if (user.getAccount().getBalance() < requestedAmount * 0.1) {
            return false;
        }
        
        // Rule 2: Should have at least 3 transactions
        List<String[]> transactions = TransactionService.getTransactionsForAccount(user.getAccountNo());
        if (transactions.size() < 3) {
            return false;
        }
        
        // Rule 3: No negative balance history (simplified)
        for (String[] txn : transactions) {
            if (txn.length >= 3 && txn[2].equals("WITHDRAW")) {
                String amountStr = txn[3].replace("$", "").replace("-", "");
                try {
                    double amount = Double.parseDouble(amountStr);
                    // Check for large withdrawals (simplified risk check)
                    if (amount > user.getAccount().getBalance() * 0.5) {
                        return false;
                    }
                } catch (NumberFormatException e) {
                    // Skip invalid amounts
                }
            }
        }
        
        return true;
    }
    
    /**
     * Get all active loans (for admin purposes)
     */
    public static List<LoanAccount> getAllActiveLoans() {
        return new ArrayList<>(activeLoans.values());
    }
    
    /**
     * Get total outstanding loans amount
     */
    public static double getTotalOutstanding() {
        double total = 0;
        for (LoanAccount loan : activeLoans.values()) {
            total += loan.getRemainingBalance();
        }
        return total;
    }
    
    /**
     * Get bank's loan policy summary
     */
    public static String getBankPolicySummary() {
        return String.format(
            "🏦 Bank Loan Policy\n" +
            "════════════════════════════\n" +
            "Home Loan:       %.1f%%\n" +
            "Car Loan:        %.1f%%\n" +
            "Personal Loan:   %.1f%%\n" +
            "Education Loan:  %.1f%%\n" +
            "════════════════════════════\n" +
            "Min Amount: $%.2f\n" +
            "Max Amount: $%.2f\n" +
            "Min Duration: %d months\n" +
            "Max Duration: %d months\n" +
            "Processing Fee: 1%%",
            HOME_LOAN_RATE * 100,
            CAR_LOAN_RATE * 100,
            PERSONAL_LOAN_RATE * 100,
            EDUCATION_LOAN_RATE * 100,
            MIN_LOAN_AMOUNT,
            MAX_LOAN_AMOUNT,
            MIN_LOAN_MONTHS,
            MAX_LOAN_MONTHS
        );
    }
}