package service;

import java.util.*;
import java.text.SimpleDateFormat;

public class StatementService {
    private static final SimpleDateFormat DATE_FORMAT = new SimpleDateFormat("dd-MM-yyyy HH:mm:ss");
    
    // Get transactions for specific month
    public static List<String[]> getTransactionsForMonth(int accountNo, int year, int month) {
        List<String[]> allTransactions = TransactionService.getTransactionsForAccount(accountNo);
        List<String[]> monthlyTransactions = new ArrayList<>();
        
        for (String[] txn : allTransactions) {
            if (txn.length >= 2 && isInMonth(txn[1], year, month)) {
                monthlyTransactions.add(txn);
            }
        }
        
        // Sort by date (newest first)
        monthlyTransactions.sort((t1, t2) -> t2[1].compareTo(t1[1]));
        
        return monthlyTransactions;
    }
    
    // Get monthly summary - COMPLETE & FIXED VERSION
    public static Map<String, Object> getMonthlySummary(int accountNo, int year, int month) {
        List<String[]> transactions = getTransactionsForMonth(accountNo, year, month);
        
        // ✅ VARIABLE DECLARATIONS ADDED
        double totalDeposits = 0;
        double totalWithdrawals = 0;
        double openingBalance = 0;
        double closingBalance = 0;
        Map<String, Double> categories = new HashMap<>();
        
        if (transactions.isEmpty()) {
            // Return empty/zero values, NOT sample data
            Map<String, Object> emptySummary = new HashMap<>();
            emptySummary.put("OPENING_BALANCE", 0.0);
            emptySummary.put("CLOSING_BALANCE", 0.0);
            emptySummary.put("TOTAL_DEPOSITS", 0.0);
            emptySummary.put("TOTAL_WITHDRAWALS", 0.0);
            emptySummary.put("NET_FLOW", 0.0);
            emptySummary.put("SAVINGS_RATE", 0.0);
            emptySummary.put("TRANSACTION_COUNT", 0);
            emptySummary.put("CATEGORIES", new HashMap<String, Double>());
            emptySummary.put("TRANSACTIONS", transactions);
            return emptySummary;
        }
        
        // ✅ FIXED: Calculate totals and categorize
        for (String[] txn : transactions) {
            if (txn.length >= 4) {
                try {
                    String amountStr = txn[3].replace("$", "").replace(",", "").replace("+", "");
                    double amount = Double.parseDouble(amountStr);
                    
                    if (txn[2].equalsIgnoreCase("DEPOSIT")) {
                        totalDeposits += Math.abs(amount);
                        closingBalance += Math.abs(amount);
                    } else if (txn[2].equalsIgnoreCase("WITHDRAW")) {
                        totalWithdrawals += Math.abs(amount);
                        closingBalance -= Math.abs(amount);
                        
                        // Categorize expense
                        String category = categorizeTransaction(txn);
                        categories.put(category, categories.getOrDefault(category, 0.0) + Math.abs(amount));
                    }
                } catch (NumberFormatException e) {
                    // Skip invalid amounts
                }
            }
        }
        
        // Opening balance (closing - net flow)
        openingBalance = closingBalance - (totalDeposits - totalWithdrawals);
        
        // Calculate savings rate
        double savingsRate = totalDeposits > 0 ? 
            ((totalDeposits - totalWithdrawals) / totalDeposits) * 100 : 0;
        
        // ✅ FIXED: Create summary map
        Map<String, Object> summary = new HashMap<>();
        summary.put("OPENING_BALANCE", openingBalance);
        summary.put("CLOSING_BALANCE", closingBalance);
        summary.put("TOTAL_DEPOSITS", totalDeposits);
        summary.put("TOTAL_WITHDRAWALS", totalWithdrawals);
        summary.put("NET_FLOW", totalDeposits - totalWithdrawals);
        summary.put("SAVINGS_RATE", savingsRate);
        summary.put("TRANSACTION_COUNT", transactions.size());
        summary.put("CATEGORIES", categories);
        summary.put("TRANSACTIONS", transactions);
        
        return summary;
    }
    
    // Get trends for last 6 months - FIXED VERSION
    public static Map<String, Object> getMonthlyTrends(int accountNo) {
        Map<String, Object> trends = new HashMap<>();
        
        Calendar cal = Calendar.getInstance();
        int currentYear = cal.get(Calendar.YEAR);
        int currentMonth = cal.get(Calendar.MONTH) + 1;
        
        double[] balances = new double[6];
        double[] deposits = new double[6];
        double[] withdrawals = new double[6];
        String[] monthLabels = new String[6];
        
        // Calculate for last 6 months
        for (int i = 0; i < 6; i++) {
            int monthOffset = 5 - i;
            int targetMonth = currentMonth - monthOffset;
            int targetYear = currentYear;
            
            if (targetMonth <= 0) {
                targetMonth += 12;
                targetYear -= 1;
            }
            
            Map<String, Object> monthlyData = getMonthlySummary(accountNo, targetYear, targetMonth);
            
            balances[i] = (double) monthlyData.get("NET_FLOW");
            deposits[i] = (double) monthlyData.get("TOTAL_DEPOSITS");
            withdrawals[i] = (double) monthlyData.get("TOTAL_WITHDRAWALS");
            monthLabels[i] = getMonthName(targetMonth) + " '" + (targetYear % 100);
        }
        
        trends.put("BALANCES", balances);
        trends.put("DEPOSITS", deposits);
        trends.put("WITHDRAWALS", withdrawals);
        trends.put("MONTH_LABELS", monthLabels);
        
        return trends;
    }
    
    // Get financial insights
    public static Map<String, Object> getFinancialInsights(int accountNo) {
        Map<String, Object> insights = new HashMap<>();
        Calendar cal = Calendar.getInstance();
        Map<String, Object> currentMonth = getMonthlySummary(
            accountNo, cal.get(Calendar.YEAR), cal.get(Calendar.MONTH) + 1);
        
        double savingsRate = (double) currentMonth.get("SAVINGS_RATE");
        double netFlow = (double) currentMonth.get("NET_FLOW");
        int transactionCount = (int) currentMonth.get("TRANSACTION_COUNT");
        
        // Calculate health score
        int healthScore = calculateHealthScore(savingsRate, netFlow, transactionCount);
        
        // Generate recommendations
        List<String> recommendations = generateRecommendations(savingsRate, netFlow, transactionCount);
        
        insights.put("HEALTH_SCORE", healthScore);
        insights.put("RECOMMENDATIONS", recommendations);
        insights.put("SAVINGS_RATE", savingsRate);
        insights.put("NET_FLOW", netFlow);
        insights.put("MONTHLY_DATA", currentMonth);
        
        return insights;
    }
    
    // Calculate financial health score (0-100)
    private static int calculateHealthScore(double savingsRate, double netFlow, int transactionCount) {
        int score = 0;
        
        // Savings rate contributes 50 points
        score += (int) Math.min(savingsRate * 1.5, 50);
        
        // Positive net flow contributes 30 points
        if (netFlow > 0) score += 30;
        else if (netFlow == 0) score += 15;
        
        // Sufficient transactions contribute 20 points
        if (transactionCount >= 5) score += 20;
        else if (transactionCount >= 2) score += 10;
        
        return Math.min(score, 100);
    }
    
    // Generate personalized recommendations
    private static List<String> generateRecommendations(double savingsRate, double netFlow, int transactionCount) {
        List<String> recommendations = new ArrayList<>();
        
        if (savingsRate < 20) {
            recommendations.add("Increase your savings rate (currently " + String.format("%.1f%%", savingsRate) + ")");
            recommendations.add("Set up automatic transfers to savings account");
        }
        
        if (netFlow < 0) {
            recommendations.add("You're spending more than you earn");
            recommendations.add("Review and reduce non-essential expenses");
        }
        
        if (transactionCount < 3) {
            recommendations.add("Consider more frequent transactions for better tracking");
        }
        
        if (savingsRate >= 30 && netFlow > 0) {
            recommendations.add("Great job! Consider investing some savings");
        }
        
        if (recommendations.isEmpty()) {
            recommendations.add("You're doing great! Keep up the good financial habits");
            recommendations.add("Consider setting financial goals for next quarter");
        }
        
        return recommendations;
    }
    
    // Categorize transaction
    private static String categorizeTransaction(String[] transaction) {
        if (transaction.length < 5) return "Other";
        
        String description = transaction[4].toLowerCase();
        
        if (description.contains("food") || description.contains("restaurant") || 
            description.contains("dinner") || description.contains("lunch") ||
            description.contains("cafe") || description.contains("coffee")) {
            return "Food & Dining";
        } else if (description.contains("shop") || description.contains("mall") || 
                  description.contains("amazon") || description.contains("store") ||
                  description.contains("clothes") || description.contains("fashion")) {
            return "Shopping";
        } else if (description.contains("bill") || description.contains("electric") || 
                  description.contains("water") || description.contains("utility") ||
                  description.contains("internet") || description.contains("mobile")) {
            return "Bills & Utilities";
        } else if (description.contains("movie") || description.contains("entertain") || 
                  description.contains("netflix") || description.contains("game") ||
                  description.contains("music") || description.contains("concert")) {
            return "Entertainment";
        } else if (description.contains("travel") || description.contains("fuel") || 
                  description.contains("uber") || description.contains("taxi") ||
                  description.contains("bus") || description.contains("train") ||
                  description.contains("flight")) {
            return "Travel";
        } else if (description.contains("medical") || description.contains("hospital") || 
                  description.contains("doctor") || description.contains("medicine") ||
                  description.contains("pharmacy")) {
            return "Healthcare";
        } else if (description.contains("loan") || description.contains("emi") ||
                  description.contains("interest")) {
            return "Loan & EMI";
        } else if (description.contains("salary") || description.contains("income") ||
                  description.contains("deposit")) {
            return "Income";
        } else {
            return "Other";
        }
    }
    
    // Check if transaction is in specific month
    private static boolean isInMonth(String dateStr, int year, int month) {
        try {
            // Format: "dd-MM-yyyy HH:mm:ss"
            String datePart = dateStr.split(" ")[0];
            String[] parts = datePart.split("-");
            
            if (parts.length >= 3) {
                int txDay = Integer.parseInt(parts[0]);
                int txMonth = Integer.parseInt(parts[1]);
                int txYear = Integer.parseInt(parts[2]);
                
                return txYear == year && txMonth == month;
            }
        } catch (Exception e) {
            // Ignore parsing errors
        }
        return false;
    }
    
    private static String getMonthName(int month) {
        String[] months = {"Jan", "Feb", "Mar", "Apr", "May", "Jun", 
                          "Jul", "Aug", "Sep", "Oct", "Nov", "Dec"};
        return months[month - 1];
    }
    
    // Get current month name
    public static String getCurrentMonthName() {
        Calendar cal = Calendar.getInstance();
        return getMonthName(cal.get(Calendar.MONTH) + 1);
    }
    
    // Get current year
    public static int getCurrentYear() {
        Calendar cal = Calendar.getInstance();
        return cal.get(Calendar.YEAR);
    }
    
    // Get current month number
    public static int getCurrentMonth() {
        Calendar cal = Calendar.getInstance();
        return cal.get(Calendar.MONTH) + 1;
    }
}