package service;

import javax.swing.*;

import util.TextChartUtils;

import java.awt.*;
import java.util.Map;

public class ChartService {
    
    // ✅ UPDATE METHOD SIGNATURE
    public static JPanel createBalanceTrendChart(Map<String, Object> trends) {
        double[] balances = (double[]) trends.get("BALANCES");
        String[] months = (String[]) trends.get("MONTH_LABELS");
        
        if (balances != null && months != null && balances.length > 0) {
            return TextChartUtils.createTrendChart(
                "Balance Trend - Last 6 Months",
                months, balances, new Color(0, 150, 200)
            );
        }
        
        return createNoDataPanel("Balance Trend", "No balance data available");
    }
    
    // ✅ UPDATE METHOD SIGNATURE
    public static JPanel createIncomeExpenseChart(Map<String, Object> trends) {
        double[] deposits = (double[]) trends.get("DEPOSITS");
        double[] withdrawals = (double[]) trends.get("WITHDRAWALS");
        String[] months = (String[]) trends.get("MONTH_LABELS");
        
        if (deposits != null && withdrawals != null && months != null) {
            // Create combined bar chart
            JPanel panel = new JPanel(new BorderLayout());
            panel.setBackground(Color.WHITE);
            panel.setBorder(BorderFactory.createTitledBorder("Income vs Expense"));
            
            JTabbedPane tabbedPane = new JTabbedPane();
            
            // Tab 1: Side-by-side bars
            JPanel sideBySidePanel = new JPanel(new BorderLayout());
            sideBySidePanel.setBackground(Color.WHITE);
            
            String[] combinedLabels = new String[months.length];
            double[] incomeData = new double[months.length];
            double[] expenseData = new double[months.length];
            
            for (int i = 0; i < months.length; i++) {
                combinedLabels[i] = months[i];
                incomeData[i] = deposits[i];
                expenseData[i] = withdrawals[i];
            }
            
            JPanel incomeChart = TextChartUtils.createBarChart(
                "Monthly Income", combinedLabels, incomeData, new Color(50, 205, 50)
            );
            
            JPanel expenseChart = TextChartUtils.createBarChart(
                "Monthly Expenses", combinedLabels, expenseData, new Color(255, 69, 0)
            );
            
            JPanel chartsPanel = new JPanel(new GridLayout(2, 1, 10, 10));
            chartsPanel.add(incomeChart);
            chartsPanel.add(expenseChart);
            
            sideBySidePanel.add(chartsPanel, BorderLayout.CENTER);
            tabbedPane.addTab("Side by Side", sideBySidePanel);
            
            // Tab 2: Net flow chart
            JPanel netFlowPanel = new JPanel(new BorderLayout());
            double[] netFlow = new double[months.length];
            for (int i = 0; i < months.length; i++) {
                netFlow[i] = deposits[i] - withdrawals[i];
            }
            
            JPanel netFlowChart = TextChartUtils.createTrendChart(
                "Net Flow Trend", months, netFlow, 
                netFlow[netFlow.length-1] >= 0 ? 
                    new Color(50, 205, 50) : new Color(255, 69, 0)
            );
            
            netFlowPanel.add(netFlowChart, BorderLayout.CENTER);
            tabbedPane.addTab("Net Flow", netFlowPanel);
            
            panel.add(tabbedPane, BorderLayout.CENTER);
            return panel;
        }
        
        return createNoDataPanel("Income vs Expense", "No financial data available");
    }
    
    // ✅ UPDATE METHOD SIGNATURE
    public static JPanel createSavingsRateChart(Map<String, Object> trends) {
        double[] deposits = (double[]) trends.get("DEPOSITS");
        double[] withdrawals = (double[]) trends.get("WITHDRAWALS");
        String[] months = (String[]) trends.get("MONTH_LABELS");
        
        if (deposits != null && withdrawals != null && months != null) {
            double[] savingsRates = new double[months.length];
            
            for (int i = 0; i < months.length; i++) {
                if (deposits[i] > 0) {
                    savingsRates[i] = ((deposits[i] - withdrawals[i]) / deposits[i]) * 100;
                } else {
                    savingsRates[i] = 0;
                }
            }
            
            JPanel panel = new JPanel(new BorderLayout());
            panel.setBackground(Color.WHITE);
            panel.setBorder(BorderFactory.createTitledBorder("Savings Rate Analysis"));
            
            // Create main chart
            JPanel chartPanel = TextChartUtils.createTrendChart(
                "Savings Rate (%)", months, savingsRates, new Color(148, 0, 211)
            );
            
            // Add progress bars for each month
            JPanel progressPanel = new JPanel(new GridLayout(months.length, 1, 5, 5));
            progressPanel.setBackground(Color.WHITE);
            progressPanel.setBorder(BorderFactory.createEmptyBorder(10, 20, 10, 20));
            
            for (int i = 0; i < months.length; i++) {
                Color barColor;
                if (savingsRates[i] >= 30) {
                    barColor = new Color(50, 205, 50); // Green (Excellent)
                } else if (savingsRates[i] >= 20) {
                    barColor = new Color(154, 205, 50); // Lime (Good)
                } else if (savingsRates[i] >= 10) {
                    barColor = new Color(255, 215, 0); // Yellow (Average)
                } else if (savingsRates[i] >= 0) {
                    barColor = new Color(255, 140, 0); // Orange (Poor)
                } else {
                    barColor = new Color(255, 69, 0); // Red (Negative)
                }
                
                JProgressBar progressBar = TextChartUtils.createProgressBar(
                    Math.max(savingsRates[i], 0), 50, barColor, 
                    months[i] + ": " + String.format("%.1f%%", savingsRates[i])
                );
                progressPanel.add(progressBar);
            }
            
            panel.add(chartPanel, BorderLayout.CENTER);
            panel.add(progressPanel, BorderLayout.SOUTH);
            
            return panel;
        }
        
        return createNoDataPanel("Savings Rate", "No savings data available");
    }
    
    // ✅ COMPLETE METHOD - Financial Health Panel
    public static JPanel createFinancialHealthPanel(Map<String, Object> monthlyData) {
        JPanel panel = new JPanel(new BorderLayout());
        panel.setBackground(Color.WHITE);
        panel.setBorder(BorderFactory.createTitledBorder("Financial Health Score"));
        
        // Get data from monthly summary
        double savingsRate = (double) monthlyData.getOrDefault("SAVINGS_RATE", 0.0);
        double netFlow = (double) monthlyData.getOrDefault("NET_FLOW", 0.0);
        int transactionCount = (int) monthlyData.getOrDefault("TRANSACTION_COUNT", 0);
        
        // Calculate health score (0-100)
        int healthScore = calculateHealthScore(savingsRate, netFlow, transactionCount);
        
        // Create main health score display
        JPanel scorePanel = new JPanel(new BorderLayout());
        scorePanel.setBackground(Color.WHITE);
        
        // Circular progress bar effect
        JLabel scoreLabel = new JLabel(String.valueOf(healthScore), JLabel.CENTER);
        scoreLabel.setFont(new Font("Segoe UI", Font.BOLD, 48));
        
        // Set color based on score
        Color scoreColor;
        if (healthScore >= 80) {
            scoreColor = new Color(50, 205, 50); // Excellent
        } else if (healthScore >= 60) {
            scoreColor = new Color(154, 205, 50); // Good
        } else if (healthScore >= 40) {
            scoreColor = new Color(255, 215, 0); // Average
        } else if (healthScore >= 20) {
            scoreColor = new Color(255, 140, 0); // Poor
        } else {
            scoreColor = new Color(255, 69, 0); // Very Poor
        }
        
        scoreLabel.setForeground(scoreColor);
        
        // Create circular border
        JPanel circlePanel = new JPanel() {
            @Override
            protected void paintComponent(Graphics g) {
                super.paintComponent(g);
                Graphics2D g2d = (Graphics2D) g;
                g2d.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
                
                // Draw outer circle
                int diameter = Math.min(getWidth(), getHeight()) - 10;
                int x = (getWidth() - diameter) / 2;
                int y = (getHeight() - diameter) / 2;
                
                // Background circle
                g2d.setColor(new Color(240, 240, 240));
                g2d.fillOval(x, y, diameter, diameter);
                
                // Progress arc
                g2d.setColor(scoreColor);
                g2d.setStroke(new BasicStroke(8));
                int arcAngle = (int) (healthScore * 3.6); // Convert to degrees (0-360)
                g2d.drawArc(x + 4, y + 4, diameter - 8, diameter - 8, 90, -arcAngle);
                
                // Border
                g2d.setColor(Color.GRAY);
                g2d.setStroke(new BasicStroke(2));
                g2d.drawOval(x, y, diameter, diameter);
            }
        };
        
        circlePanel.setBackground(Color.WHITE);
        circlePanel.setLayout(new BorderLayout());
        circlePanel.add(scoreLabel, BorderLayout.CENTER);
        
        // Status label
        String status;
        if (healthScore >= 80) status = "Excellent";
        else if (healthScore >= 60) status = "Good";
        else if (healthScore >= 40) status = "Average";
        else if (healthScore >= 20) status = "Needs Improvement";
        else status = "Critical";
        
        JLabel statusLabel = new JLabel(status + " • " + healthScore + "/100", JLabel.CENTER);
        statusLabel.setFont(new Font("Segoe UI", Font.BOLD, 14));
        statusLabel.setForeground(scoreColor);
        
        // Details panel
        JPanel detailsPanel = new JPanel(new GridLayout(4, 1, 5, 5));
        detailsPanel.setBackground(Color.WHITE);
        detailsPanel.setBorder(BorderFactory.createEmptyBorder(10, 20, 10, 20));
        
        // Add metrics
        detailsPanel.add(createMetricRow("Savings Rate:", String.format("%.1f%%", savingsRate), 
            savingsRate >= 20 ? Color.GREEN : Color.ORANGE));
        detailsPanel.add(createMetricRow("Net Cash Flow:", String.format("$%.2f", netFlow),
            netFlow >= 0 ? Color.GREEN : Color.RED));
        detailsPanel.add(createMetricRow("Transactions:", String.valueOf(transactionCount),
            transactionCount >= 5 ? Color.GREEN : Color.ORANGE));
        detailsPanel.add(createMetricRow("Financial Status:", status, scoreColor));
        
        scorePanel.add(circlePanel, BorderLayout.CENTER);
        scorePanel.add(statusLabel, BorderLayout.SOUTH);
        
        panel.add(scorePanel, BorderLayout.CENTER);
        panel.add(detailsPanel, BorderLayout.SOUTH);
        
        return panel;
    }
    
    // ✅ COMPLETE METHOD - No Data Panel
    private static JPanel createNoDataPanel(String title, String message) {
        JPanel panel = new JPanel(new BorderLayout());
        panel.setBackground(Color.WHITE);
        panel.setBorder(BorderFactory.createTitledBorder(title));
        
        JLabel label = new JLabel("<html><center><h3 style='color:#666;'>📊 " + title + "</h3>" +
                                 "<p style='color:#888; margin-top:10px;'>" + message + "</p>" +
                                 "<p style='color:#aaa; margin-top:20px;'>" +
                                 "Make some transactions to see your financial data here.</p></center></html>");
        label.setHorizontalAlignment(SwingConstants.CENTER);
        label.setBorder(BorderFactory.createEmptyBorder(40, 20, 40, 20));
        
        panel.add(label, BorderLayout.CENTER);
        return panel;
    }
    
    // ✅ HELPER METHOD - Create metric row
    private static JPanel createMetricRow(String label, String value, Color color) {
        JPanel row = new JPanel(new BorderLayout());
        row.setBackground(Color.WHITE);
        
        JLabel labelLbl = new JLabel(label);
        labelLbl.setFont(new Font("Segoe UI", Font.PLAIN, 12));
        
        JLabel valueLbl = new JLabel(value);
        valueLbl.setFont(new Font("Segoe UI", Font.BOLD, 12));
        valueLbl.setForeground(color);
        valueLbl.setHorizontalAlignment(SwingConstants.RIGHT);
        
        row.add(labelLbl, BorderLayout.WEST);
        row.add(valueLbl, BorderLayout.EAST);
        
        return row;
    }
    
    // ✅ HELPER METHOD - Calculate health score
    private static int calculateHealthScore(double savingsRate, double netFlow, int transactionCount) {
        int score = 0;
        
        // Savings rate contributes 50 points
        score += (int) Math.min(savingsRate * 1.5, 50);
        
        // Positive net flow contributes 30 points
        if (netFlow > 0) score += 30;
        else if (netFlow == 0) score += 15;
        
        // Sufficient transactions contribute 20 points
        if (transactionCount >= 5) score += 20;
        else if (transactionCount >= 2) score += 10;
        
        return Math.min(score, 100);
    }
    
    // ✅ ADD THIS METHOD - Expense Pie Chart (missing in original)
    public static JPanel createExpensePieChart(Map<String, Double> categories) {
        if (categories == null || categories.isEmpty()) {
            return createNoDataPanel("Expense Categories", "No expense data available");
        }
        
        JPanel panel = new JPanel(new BorderLayout());
        panel.setBackground(Color.WHITE);
        panel.setBorder(BorderFactory.createTitledBorder("Expense Distribution"));
        
        // Create pie chart using TextChartUtils
        JPanel pieChartPanel = TextChartUtils.createPieChartVisual("Expense Categories", categories);
        
        // Summary stats
        double totalExpenses = 0;
        for (Double value : categories.values()) {
            totalExpenses += value;
        }
        
        JLabel summaryLabel = new JLabel(
            String.format("Total Expenses: $%.2f | Categories: %d", 
                totalExpenses, categories.size()),
            JLabel.CENTER);
        summaryLabel.setFont(new Font("Arial", Font.BOLD, 12));
        summaryLabel.setBorder(BorderFactory.createEmptyBorder(5, 0, 5, 0));
        
        panel.add(pieChartPanel, BorderLayout.CENTER);
        panel.add(summaryLabel, BorderLayout.SOUTH);
        
        return panel;
    }
}